-- Lynd Deobfuscator & Dumper | https://discord.gg/SRvRc2XF6s
-- Rexm Lularphed
-- Deobf by lynd

local t1 = {}
local v2 = unpack or table.unpack
t1.value1 = game:GetService("Players")
t1.value2 = game:GetService("RunService")
t1.value3 = loadstring(game:HttpGet("https://pastefy.app/gbasFc5V/raw"))()
t1.value4 = t1.value3:MakeWindow({
	Title = "REXM HUB",
	SubTitle = "by : MA7AMD"
})
local value4 = t1.value4
local uDim2 = UDim2.new(0, 35, 0, 35)
local t2 = {
	Image = "rbxassetid://76144975356652",
	BackgroundTransparency = 0,
	Size = uDim2
}
local AddMinimizeButton = value4.AddMinimizeButton
local uDim = UDim.new(0, 100)

AddMinimizeButton(value4, {
	Button = t2,
	Corner = {
		CornerRadius = uDim
	}
})
local v8 = t1.value4:MakeTab({
	Title = "الحقوق",
	Icon = "rbxassetid://15309138473"
})
v8:AddInfoBruton("بموت في العسل المشغل سكربتي")
v8:AddSection("مطورين")
v8:AddParagraph({
	"المطور:",
	"محمد"
})
v8:AddParagraph({
	"المطور:",
	" واجهه 8n"
})
v8:AddParagraph({
	"المطور:",
	" واجهه رافكس"
})
v8:AddParagraph({
	"يوزر المطور روب:",
	"youssef3423samyt"
})
v8:AddParagraph({
	"الهاك المستخدم:",
	identifyexecutor and identifyexecutor() or "غير معروف"
})
v8:AddSection({ "للتواصل مع المطور" })
v8:AddButton({
	Name = "حسابي التيك توك",
	Callback = function()
    setclipboard("@nazr7r")

    local s1 = "REX-M HUB"
    local s2 = "تم نسخ رابط التيك توك ✅"

    pcall(function()
        t1.value3:Notify({
				Title = s1,
				Content = s2,
				Duration = 3
			})
    end)
end
})
v8:AddButton({
	Name = "حسابي الانستقرام",
	Callback = function()
    setclipboard("mohamd2142_75158")

    local s3 = "REX-M HUB"
    local s4 = "تم نسخ رابط الانستقرام ✅"

    pcall(function()
        t1.value3:Notify({
				Title = s3,
				Content = s4,
				Duration = 3
			})
    end)
end
})
v8:AddButton({
	Name = "حسابي روب",
	Callback = function()
    setclipboard("https://www.roblox.com/users/5330629837/profile")

    local s5 = "REX-M HUB"
    local s6 = "تم نسخ رابط حسابي روبلوكس ✅"

    pcall(function()
        t1.value3:Notify({
				Title = s5,
				Content = s6,
				Duration = 3
			})
    end)
end
})
v8:AddSection({ "السرفر" })
v8:AddButton({
	Name = "إعادة الانضمام ",
	Callback = function()
    game:GetService("TeleportService"):TeleportToPlaceInstance(game.PlaceId, game.JobId, t1.value1.LocalPlayer)
end
})
v8:AddButton({
	Name = "نسخ رابط السيرفر ",
	Callback = function()
    setclipboard("https://www.roblox.com/games/" .. game.PlaceId .. "?privateServerLinkCode=" .. game.JobId)

    local s7 = "REX-M HUB"
    local s8 = "تم نسخ رابط السيرفر ✅"

    pcall(function()
        t1.value3:Notify({
				Title = s7,
				Content = s8,
				Duration = 3
			})
    end)
end
})
v8:AddButton({
	Name = "نسخ آيدي السيرفر ",
	Callback = function()
    setclipboard((tostring(game.JobId)))

    local s9 = "REX-M HUB"
    local s10 = "تم نسخ الآيدي ✅"

    pcall(function()
        t1.value3:Notify({
				Title = s9,
				Content = s10,
				Duration = 3
			})
    end)
end
})
t1.value5 = t1.value4:MakeTab({
	Title = "الأدوات",
	Icon = "rbxassetid://76144975356652"
})
t1.value6 = nil
t1.value7 = 20
t1.value8 = 5
t1.value9 = 0
t1.value10 = 0
t1.value11 = 1
t1.value12 = 0
t1.value13 = nil
t1.value14 = workspace:WaitForChild("WorkspaceCom"):WaitForChild("001_TrafficCones")
t1.value15 = "Prop" .. t1.value1.LocalPlayer.Name
function t1.value16()
    local t3 = { "علي نفسك" }

    for _, player in pairs(t1.value1:GetPlayers()) do
        if player.Name ~= t1.value1.LocalPlayer.Name then
            table.insert(t3, player.Name)
        end
    end

    return t3
end
t1.value5:AddSection({ "اختر اللاعب" })
t1.value5:AddTextBox({
	Name = "اكتب تلات  حروف من اسم الاعب",
	Default = "",
	Placeholder = "مثال: moh أو نفسي",
	Callback = function(p1)
    if p1 == "" then
        return
    end
    local v106 = string.lower(p1)
    if v106 == "نفسي" or (v106 == "علي نفسي" or v106 == "self") then
        t1.value6 = t1.value1.LocalPlayer.Name

        local s11 = "الأدوات"
        local s12 = "تم اختيار: علي نفسك"

        pcall(function()
            t1.value3:Notify({
					Title = s11,
					Content = s12,
					Duration = 3
				})
        end)

        return
    end
    local playerName
    for _, player in pairs(t1.value1:GetPlayers()) do
        local v112 = string.lower(player.Name)
        local v113 = string.lower(player.DisplayName)
        local v114 = string.find(v112, v106)

        if not v114 then
            v114 = string.find(v113, v106)
        end

        if v114 then
            playerName = player.Name

            break
        end
    end
    if playerName then
        t1.value6 = playerName

        local v115 = "تم العثور واختيار: " .. t1.value6
        local s13 = "الأدوات"

        pcall(function()
            t1.value3:Notify({
					Title = s13,
					Content = v115,
					Duration = 3
				})
        end)

        return
    end
    local s14 = "خطأ"
    local s15 = "لم يتم العثور على لاعب!"
    pcall(function()
        t1.value3:Notify({
				Title = s14,
				Content = s15,
				Duration = 3
			})
    end)
end
})
local value5 = t1.value5
local v10 = t1.value16()
t1.value17 = value5:AddDropdown({
	Name = "اختيار الاعب",
	Options = v10,
	Callback = function(p2)
    t1.value6 = p2 == "علي نفسك" and t1.value1.LocalPlayer.Name or p2

    local v120 = "تم اختيار: " .. t1.value6
    local s16 = "الأدوات"

    pcall(function()
        t1.value3:Notify({
				Title = s16,
				Content = v120,
				Duration = 3
			})
    end)
end
})
t1.value5:AddButton({
	Name = "تحديث القائمة",
	Callback = function()
    t1.value17:Refresh(t1.value16(), true)
end
})
t1.value5:AddSection({ "إعدادات الدوران" })
pcall(function()
    local LocalPlayer = game.Players.LocalPlayer
    local v123 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()
    local Backpack = LocalPlayer:WaitForChild("Backpack")

    local function v125()
        pcall(function()
            game:GetService("ReplicatedStorage"):WaitForChild("RE"):FindFirstChild("1Too1l"):InvokeServer("PickingTools", "PropMaker")
        end)
    end
    local function v126()
        local PropMaker = Backpack:FindFirstChild("PropMaker")

        if not PropMaker then
            PropMaker = v123:FindFirstChild("PropMaker")
        end

        if not PropMaker then
            for _, descendant in pairs(game:GetDescendants()) do
                if descendant.Name == "PropMaker" and descendant:IsA("Tool") then
                    PropMaker = descendant:Clone()
                    PropMaker.Parent = Backpack

                    break
                end
            end
        end

        if PropMaker then
            task.wait(0.1)
            PropMaker.Parent = v123

            local s17 = "PropMaker"
            local s18 = " الأداة جاهزة في يدك!"

            pcall(function()
                t1.value3:Notify({
					Title = s17,
					Content = s18,
					Duration = 3
				})
            end)

            return true
        end

        return false
    end

    t1.value5:AddButton({
		Name = "خذ الصندوق",
		Callback = function()
        local s19 = "PropMaker"
        local s20 = "استني اجيبلك الصندوق"

        pcall(function()
            t1.value3:Notify({
					Title = s19,
					Content = s20,
					Duration = 3
				})
        end)
        v125()
        task.wait(0.5)

        if not v126() then
            local s21 = "PropMaker"
            local s22 = "جرب مرا كمان"

            pcall(function()
                t1.value3:Notify({
						Title = s21,
						Content = s22,
						Duration = 3
					})
            end)
        end
    end
	})
end)
t1.value5:AddSlider({
	Name = "السرعة",
	Min = 1,
	Max = 50,
	Default = 20,
	Increment = 1,
	Callback = function(p3)
    t1.value7 = p3
end
})
t1.value5:AddSlider({
	Name = "المسافة الجانبية",
	Min = 0,
	Max = 20,
	Default = 5,
	Increment = 1,
	Callback = function(p4)
    t1.value8 = p4
end
})
t1.value5:AddSlider({
	Name = "الارتفاع فوق",
	Min = 0,
	Max = 30,
	Default = 0,
	Increment = 1,
	Callback = function(p5)
    t1.value9 = p5
end
})
t1.value5:AddSlider({
	Name = "النزول تحت",
	Min = 0,
	Max = 30,
	Default = 0,
	Increment = 1,
	Callback = function(p6)
    t1.value9 = -p6
end
})
t1.value5:AddSlider({
	Name = "تشقلب",
	Min = 0,
	Max = 360,
	Default = 0,
	Increment = 1,
	Callback = function(p7)
    t1.value10 = math.rad(p7)
end
})
t1.value5:AddSlider({
	Name = "حجم الدائرة",
	Min = 1,
	Max = 10,
	Default = 1,
	Increment = 1,
	Callback = function(p8)
    t1.value11 = p8
end
})
t1.value5:AddSection({ "التحكم" })
t1.value5:AddToggle({
	Name = "تشغيل / إيقاف",
	Default = false,
	Callback = function(p9)
    if p9 then
        if not t1.value6 then
            t1.value6 = t1.value1.LocalPlayer.Name
        end

        if t1.value13 then
            t1.value13:Disconnect()
        end

        t1.value13 = t1.value2.Heartbeat:Connect(function(dt)
            pcall(function()
                local t1value6 = t1.value1:FindFirstChild(t1.value6)
                if not t1value6 or not t1value6.Character then
                    return
                end
                local HumanoidRootPart = t1value6.Character:FindFirstChild("HumanoidRootPart")
                if not HumanoidRootPart then
                    return
                end
                local t4 = {}
                for v1352, v1353 in ipairs(t1.value14:GetChildren()) do

                    if string.find(v1353.Name, t1.value15) and v1353:FindFirstChild("SetCurrentCFrame") then
                        table.insert(t4, v1353)
                    end
                end
                if #t4 == 0 then
                    return
                end
                t1.value12 = t1.value12 + t1.value7 * dt
                local HumanoidRootPartPosition = HumanoidRootPart.Position
                for i, v in ipairs(t4) do
                    local SetCurrentCFrame = v:FindFirstChild("SetCurrentCFrame")

                    if SetCurrentCFrame then
                        local v1358 = t1.value12 + 6.283185307179586 / #t4 * i
                        local v1359 = HumanoidRootPartPosition.X + t1.value8 * t1.value11 * math.cos(v1358)
                        local v1360 = HumanoidRootPartPosition.Z + t1.value8 * t1.value11 * math.sin(v1358)
                        local v1361 = HumanoidRootPartPosition.Y + t1.value9

                        SetCurrentCFrame:InvokeServer(CFrame.new(v1359, v1361, v1360) * CFrame.Angles(t1.value10, -v1358, 0))
                    end
                end
            end)
        end)

        local s23 = "الأدوات"
        local s24 = "تم التشغيل "

        pcall(function()
            t1.value3:Notify({
					Title = s23,
					Content = s24,
					Duration = 3
				})
        end)

        return
    end

    if t1.value13 then
        t1.value13:Disconnect()
    end

    local s25 = "الأدوات"
    local s26 = "تم الإيقاف "

    pcall(function()
        t1.value3:Notify({
				Title = s25,
				Content = s26,
				Duration = 3
			})
    end)
end
})
local v11 = t1.value4:MakeTab({
	Title = "التخريب",
	Icon = "rbxassetid://76144975356652"
})
t1.value18 = t1.value1.LocalPlayer
t1.value19 = nil
v11:AddSection({
	Name = "التخريب"
})
local v12 = (function()
    local players = t1.value1:GetPlayers()
    local t5 = {}

    for _, v in ipairs(players) do
        if v ~= t1.value18 then
            table.insert(t5, v.Name)
        end
    end

    return t5
end)()
t1.value20 = v11:AddDropdown({
	Name = "اختار الاعب",
	Options = v12,
	Default = "",
	Callback = function(p10)
    t1.value19 = p10
    getgenv().Target = p10
    print("Jogador selecionado: " .. tostring(p10))
end
})
v11:AddButton({
	Name = "تحديث القايمه",
	Callback = function()
    local t6 = {}
    local players = t1.value1:GetPlayers()

    if t1.value20 and #players > 0 then
        for _, v in ipairs(players) do
            if v.Name ~= t1.value18.Name then
                table.insert(t6, v.Name)
            end
        end

        t1.value20:Set(t6)
        print("Lista de jogadores atualizada: ", table.concat(t6, ", "))

        local value19 = t1.value19

        if value19 then
            value19 = not t1.value1:FindFirstChild(t1.value19)
        end

        if value19 then
            t1.value19 = nil
            getgenv().Target = nil
            t1.value20:SetValue("")
            print("Seleção resetada, jogador não está mais no servidor.")

            return
        end
    else
        print("Erro: Dropdown não encontrado ou nenhum jogador disponível.")
    end
end
})
v11:AddButton({
	Name = "انتقل لي الاعب",
	Callback = function()
    if not t1.value19 or not t1.value1:FindFirstChild(t1.value19) then
        print("Erro: Player não selecionado ou não existe")

        return
    end

    local Character = t1.value18.Character
    local v149 = Character and Character:FindFirstChild("HumanoidRootPart")

    if not v149 then
        warn("Erro: HumanoidRootPart do jogador local não encontrado")

        return
    end

    local t1value19 = t1.value1:FindFirstChild(t1.value19)

    if t1value19 and (t1value19.Character and t1value19.Character:FindFirstChild("HumanoidRootPart")) then
        v149.CFrame = t1value19.Character.HumanoidRootPart.CFrame

        return
    end

    print("Erro: Player alvo não encontrado ou sem HumanoidRootPart")
end
})
v11:AddToggle({
	Name = "راقب الاعب",
	Default = false,
	Callback = function(p11)
    local CurrentCamera = workspace.CurrentCamera

    local function v153()
        if p11 then
            local t1value19 = t1.value1:FindFirstChild(t1.value19)

            if t1value19 and t1value19.Character then
                local Humanoid = t1value19.Character:FindFirstChild("Humanoid")

                if Humanoid then
                    CurrentCamera.CameraSubject = Humanoid

                    return
                end
            end
        elseif t1.value18.Character then
            local Humanoid = t1.value18.Character:FindFirstChild("Humanoid")

            if Humanoid then
                CurrentCamera.CameraSubject = Humanoid
            end
        end
    end

    if p11 then
        if not getgenv().CameraConnection then
            getgenv().CameraConnection = t1.value2.Heartbeat:Connect(v153)

            return
        end
    else
        if getgenv().CameraConnection then
            getgenv().CameraConnection:Disconnect()
            getgenv().CameraConnection = nil
        end

        v153()
    end
end
})
v11:AddSection({
	Name = "تخريب ادوات"
})
v11:AddSection({
	Name = "احيانا بتعلق انشالله هصلحها بي تحديث جاي"
})
v11:AddSection({
	Name = "لو حاجه مااشتغلتش دوس عليها مرا كمان"
})
t1.value21 = game:GetService("ReplicatedStorage")
game:GetService("TweenService")

local StarterGui = game:GetService("StarterGui")

t1.value22 = nil
t1.value22 = StarterGui
function t1.value23(p12, p13)
    pcall(function()
        t1.value22:SetCore("SendNotification", {
			Title = p12,
			Text = p13,
			Duration = 3
		})
    end)
end
function t1.value24()
    local v154 = "Prop" .. t1.value18.Name
    local t7 = {
		workspace:FindFirstChild("Model") and (workspace.Model:FindFirstChild("Street") and workspace.Model.Street:FindFirstChild("Street")),
		workspace:FindFirstChild("WorkspaceCom") and workspace.WorkspaceCom:FindFirstChild("001_TrafficCones"),
		workspace:FindFirstChild("WorkspaceCom"),
		workspace:FindFirstChild("Props"),
		workspace
	}

    for _, v in ipairs(t7) do
        if v then
            local GetChildren = v.GetChildren

            for _, v3 in ipairs(GetChildren(v)) do
                if v154 == v3.Name and not v3:GetAttribute("TrackedBySystem") then
                    v3:SetAttribute("TrackedBySystem", true)

                    return v3
                end
            end
        end
    end

    return nil
end
function t1.value25()
    pcall(function()
        local Character = t1.value18.Character
        local v882 = Character and Character:FindFirstChildOfClass("Humanoid")

        if v882 then
            workspace.CurrentCamera.CameraType = Enum.CameraType.Custom
            workspace.CurrentCamera.CameraSubject = v882
        end
    end)
end
v11:AddButton({
	Name = "احبس كل الاعبين الفي سرفر",
	Callback = function()
    local v163 = t1.value21:FindFirstChild("RE") or workspace
    local v164 = v163:FindFirstChild("1Too1l")
    local v165 = v163:FindFirstChild("1Clea1rTool1s")
    local cFrame = CFrame.new(501.8, -25.9, 307.8)

    task.spawn(function()
        local players = t1.value1:GetPlayers()
        local t8 = {}
        for v887, v888 in ipairs(players) do

            if v888 ~= t1.value18 then
                table.insert(t8, v888)
            end
        end
        if #t8 == 0 then
            t1.value23("REXM HUB", "مفيش الاعبين في سرفر.")

            return
        end
        t1.value23("REXM SYSTEM", "تم بدا حبس الاعبين الفي سرفر يا اسطي " .. #t8 .. " لاعب!")
        local function v889(p14)
            if not p14 or not p14.Character then
                return false
            end
            local Character = p14.Character
            local Humanoid = Character:FindFirstChildOfClass("Humanoid")
            local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")
            if not Humanoid or not HumanoidRootPart then
                return false
            end
            pcall(function()
                local Character2 = t1.value18.Character

                if Character2 then
                    local Humanoid2 = Character2:FindFirstChildOfClass("Humanoid")
                    local v1690 = t1.value18.Backpack:FindFirstChild("PropMaker") or Character2:FindFirstChild("PropMaker")

                    if not v1690 and v164 then
                        v164:InvokeServer("PickingTools", "PropMaker")
                        v1690 = t1.value18.Backpack:WaitForChild("PropMaker", 3)
                    end

                    if v1690 and Humanoid2 then
                        Humanoid2:EquipTool(v1690)
                        task.wait(0.15)

                        if v165 then
                            v165:FireServer("RequestingPropName", "FurnitureBleachers", "Furniture")
                        end

                        task.wait(0.1)

                        local Tool_PropMake = v1690:FindFirstChild("Tool_PropMake")

                        if Tool_PropMake then
                            Tool_PropMake:FireServer(workspace:FindFirstChild("Model") and (not not workspace.Model:FindFirstChild("Street") and workspace.Model.Street:FindFirstChild("Street")) or workspace, HumanoidRootPart.Position + Vector3.new(0, 2, 0))
                            v1690:Activate()
                        end
                    end
                end
            end)
            task.wait(0.25)
            local v1366 = t1.value24()
            if not v1366 then
                return false
            end
            local SetCurrentCFrame = v1366:WaitForChild("SetCurrentCFrame", 3)
            local DeleteProp = v1366:FindFirstChild("DeleteProp")
            if not SetCurrentCFrame then
                return false
            end
            pcall(function()
                workspace.CurrentCamera.CameraType = Enum.CameraType.Follow
                workspace.CurrentCamera.CameraSubject = v1366
            end)
            local u1369 = false
            local n1 = 0
            local n2 = 0
            local t9 = {}
            local function v1373()
                t1.value25()

                for _, v in ipairs(t9) do
                    if v and v.Connected then
                        v:Disconnect()
                    end
                end

                u1369 = true
            end
            table.insert(t9, Humanoid.Seated:Connect(function(isSeated)
                if not isSeated then
                    isSeated = Humanoid.Sit
                end

                if isSeated then
                    t1.value25()
                    task.spawn(function()
                        for _ = 1, 4 do
                            pcall(function()
                                SetCurrentCFrame:InvokeServer(cFrame)
                            end)
                            task.wait(0.05)
                        end

                        task.wait(0.3)

                        if DeleteProp then
                            pcall(function()
                                DeleteProp:InvokeServer()
                            end)
                        end

                        v1373()
                    end)
                end
            end))
            table.insert(t9, Humanoid:GetPropertyChangedSignal("Sit"):Connect(function()
                local Sit = Humanoid.Sit

                if not Sit then
                    Sit = Humanoid.Sit
                end

                if Sit then
                    t1.value25()
                    task.spawn(function()
                        for _ = 1, 4 do
                            pcall(function()
                                SetCurrentCFrame:InvokeServer(cFrame)
                            end)
                            task.wait(0.05)
                        end

                        task.wait(0.3)

                        if DeleteProp then
                            pcall(function()
                                DeleteProp:InvokeServer()
                            end)
                        end

                        v1373()
                    end)
                end
            end))
            local connection
            connection = t1.value2.Heartbeat:Connect(function(dt)
                n1 += dt

                if n1 >= 8 or (not v1366.Parent or not Character.Parent) then
                    if connection.Connected then
                        connection:Disconnect()
                    end

                    v1373()

                    return
                end

                if not Humanoid.Sit then
                    n2 += dt * 8.5

                    local v1697 = -1.2 + math.sin(n2) * 1.8
                    local HumanoidRootPartPosition = HumanoidRootPart.Position

                    pcall(function()
                        SetCurrentCFrame:InvokeServer(CFrame.new(HumanoidRootPartPosition.X, HumanoidRootPartPosition.Y + v1697, HumanoidRootPartPosition.Z))
                    end)

                    return
                end

                if connection.Connected then
                    connection:Disconnect()
                end
            end)
            table.insert(t9, connection)
            local timestamp = tick()
            local g1376
            repeat
                if u1369 then
                    g1376 = true
                end

                if g1376 then
                    break
                end

                task.wait(0.05)
            until tick() - timestamp > 4
            if not g1376 then
                v1373()
            end
            g1376 = false

            return true
        end
        for _, v in ipairs(t8) do
            local v892 = v

            if v892 and v892.Parent then
                if v165 then
                    v165:FireServer("ClearAllTools")
                    v165:FireServer("ClearAllProps")
                end

                task.wait(0.15)
                pcall(function()
                    v889(v892)
                end)
                task.wait(0.2)
            end
        end
        t1.value23("REX HUB", "تم حبس الاعبين يسطا!")
    end)
end
})
v11:AddButton({
	Name = "احبس الاعب التختاره من قايمه",
	Callback = function()
    local v167 = t1.value21:FindFirstChild("RE") or workspace
    local v168 = v167:FindFirstChild("1Too1l")
    local v169 = v167:FindFirstChild("1Clea1rTool1s")
    local cFrame = CFrame.new(501.8, -25.9, 307.8)
    local value19 = t1.value19

    if value19 then
        value19 = t1.value1:FindFirstChild(t1.value19)
    end

    local v172 = value19

    if not v172 then
        t1.value23("REXM HUB", "الاعب مو موجود!")

        return
    end

    task.spawn(function()
        local g906
        if v169 then
            v169:FireServer("ClearAllTools")
            v169:FireServer("ClearAllProps")
        end
        task.wait(0.2)
        if not v172 or not v172.Parent then
            return
        end
        local Character = v172.Character
        if not Character then
            return
        end
        local Humanoid = Character:FindFirstChildOfClass("Humanoid")
        local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")
        if not Humanoid or not HumanoidRootPart then
            return
        end
        pcall(function()
            local Character3 = t1.value18.Character

            if Character3 then
                local Humanoid3 = Character3:FindFirstChildOfClass("Humanoid")
                local v1379 = t1.value18.Backpack:FindFirstChild("PropMaker") or Character3:FindFirstChild("PropMaker")

                if not v1379 and v168 then
                    v168:InvokeServer("PickingTools", "PropMaker")
                    v1379 = t1.value18.Backpack:WaitForChild("PropMaker", 4)
                end

                if v1379 and Humanoid3 then
                    Humanoid3:EquipTool(v1379)
                    task.wait(0.2)

                    if v169 then
                        v169:FireServer("RequestingPropName", "FurnitureBleachers", "Furniture")
                    end

                    task.wait(0.15)

                    local Tool_PropMake = v1379:FindFirstChild("Tool_PropMake")

                    if Tool_PropMake then
                        Tool_PropMake:FireServer(workspace:FindFirstChild("Model") and (not not workspace.Model:FindFirstChild("Street") and workspace.Model.Street:FindFirstChild("Street")) or workspace, HumanoidRootPart.Position + Vector3.new(0, 2, 0))
                        v1379:Activate()
                    end
                end
            end
        end)
        task.wait(0.3)
        local v896 = t1.value24()
        if not v896 then
            return
        end
        local SetCurrentCFrame = v896:WaitForChild("SetCurrentCFrame", 4)
        local DeleteProp = v896:FindFirstChild("DeleteProp")
        if not SetCurrentCFrame then
            return
        end
        pcall(function()
            workspace.CurrentCamera.CameraType = Enum.CameraType.Follow
            workspace.CurrentCamera.CameraSubject = v896
        end)
        local u899 = false
        local n3 = 0
        local n4 = 0
        local t10 = {}
        local function v903()
            t1.value25()

            for _, v in ipairs(t10) do
                if v and v.Connected then
                    v:Disconnect()
                end
            end

            u899 = true
        end
        table.insert(t10, Humanoid.Seated:Connect(function(isSeated)
            if not isSeated then
                isSeated = Humanoid.Sit
            end

            if isSeated then
                t1.value25()
                task.spawn(function()
                    for _ = 1, 4 do
                        pcall(function()
                            SetCurrentCFrame:InvokeServer(cFrame)
                        end)
                        task.wait(0.06)
                    end

                    task.wait(0.4)

                    if DeleteProp then
                        pcall(function()
                            DeleteProp:InvokeServer()
                        end)
                    end

                    v903()
                end)
            end
        end))
        table.insert(t10, Humanoid:GetPropertyChangedSignal("Sit"):Connect(function()
            local Sit = Humanoid.Sit

            if not Sit then
                Sit = Humanoid.Sit
            end

            if Sit then
                t1.value25()
                task.spawn(function()
                    for _ = 1, 4 do
                        pcall(function()
                            SetCurrentCFrame:InvokeServer(cFrame)
                        end)
                        task.wait(0.06)
                    end

                    task.wait(0.4)

                    if DeleteProp then
                        pcall(function()
                            DeleteProp:InvokeServer()
                        end)
                    end

                    v903()
                end)
            end
        end))
        local connection
        connection = t1.value2.Heartbeat:Connect(function(dt)
            n3 += dt

            if n3 >= 10 or (not v896.Parent or not Character.Parent) then
                if connection.Connected then
                    connection:Disconnect()
                end

                v903()

                return
            end

            if not Humanoid.Sit then
                n4 += dt * 7.5

                local v1386 = -1.2 + math.sin(n4) * 1.8
                local HumanoidRootPartPosition = HumanoidRootPart.Position

                pcall(function()
                    SetCurrentCFrame:InvokeServer(CFrame.new(HumanoidRootPartPosition.X, HumanoidRootPartPosition.Y + v1386, HumanoidRootPartPosition.Z))
                end)

                return
            end

            if connection.Connected then
                connection:Disconnect()
            end
        end)
        table.insert(t10, connection)
        local timestamp = tick()
        repeat
            if u899 then
                g906 = true
            end

            if g906 then
                break
            end

            task.wait(0.05)
        until tick() - timestamp > 5
        if not g906 then
            v903()
        end
    end)
end
})
v11:AddButton({
	Name = "اسحب الاعب لعندك",
	Callback = function()
    local v173 = t1.value21:FindFirstChild("RE") or workspace
    local v174 = v173:FindFirstChild("1Too1l")
    local v175 = v173:FindFirstChild("1Clea1rTool1s")
    local v176 = t1.value19 and t1.value1:FindFirstChild(t1.value19)

    if not v176 then
        t1.value23("REXM HUB", "لاعب مش موجود!")

        return
    end

    task.spawn(function()
        local g920
        if v175 then
            v175:FireServer("ClearAllTools")
            v175:FireServer("ClearAllProps")
        end
        task.wait(0.15)
        if not v176 or not v176.Parent then
            return
        end
        local Character = v176.Character
        if not Character then
            return
        end
        local Humanoid = Character:FindFirstChildOfClass("Humanoid")
        local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")
        if not Humanoid or not HumanoidRootPart then
            return
        end
        pcall(function()
            local Character4 = t1.value18.Character

            if Character4 then
                local Humanoid4 = Character4:FindFirstChildOfClass("Humanoid")
                local v1390 = t1.value18.Backpack:FindFirstChild("PropMaker") or Character4:FindFirstChild("PropMaker")

                if not v1390 and v174 then
                    v174:InvokeServer("PickingTools", "PropMaker")
                    v1390 = t1.value18.Backpack:WaitForChild("PropMaker", 3)
                end

                if v1390 and Humanoid4 then
                    Humanoid4:EquipTool(v1390)
                    task.wait(0.15)

                    if v175 then
                        v175:FireServer("RequestingPropName", "FurnitureBleachers", "Furniture")
                    end

                    task.wait(0.1)

                    local Tool_PropMake = v1390:FindFirstChild("Tool_PropMake")

                    if Tool_PropMake then
                        Tool_PropMake:FireServer(workspace:FindFirstChild("Model") and (not not workspace.Model:FindFirstChild("Street") and workspace.Model.Street:FindFirstChild("Street")) or workspace, HumanoidRootPart.Position + Vector3.new(0, 2, 0))
                        v1390:Activate()
                    end
                end
            end
        end)
        task.wait(0.25)
        local v910 = t1.value24()
        if not v910 then
            return
        end
        local SetCurrentCFrame = v910:WaitForChild("SetCurrentCFrame", 3)
        local DeleteProp = v910:FindFirstChild("DeleteProp")
        if not SetCurrentCFrame then
            return
        end
        pcall(function()
            workspace.CurrentCamera.CameraType = Enum.CameraType.Follow
            workspace.CurrentCamera.CameraSubject = v910
        end)
        local u913 = false
        local n5 = 0
        local n6 = 0
        local t11 = {}
        local function v917()
            t1.value25()

            for _, v in ipairs(t11) do
                if v and v.Connected then
                    v:Disconnect()
                end
            end

            u913 = true
        end
        table.insert(t11, Humanoid.Seated:Connect(function(isSeated)
            if not isSeated then
                isSeated = Humanoid.Sit
            end

            if isSeated then
                t1.value25()
                task.spawn(function()
                    local Character5 = t1.value18.Character
                    local v1702 = Character5 and Character5:FindFirstChild("HumanoidRootPart")
                    local v1703 = v1702 and v1702.CFrame or CFrame.new(0, 10, 0)

                    for _ = 1, 4 do
                        pcall(function()
                            SetCurrentCFrame:InvokeServer(v1703 + Vector3.new(0, 2, 0))
                        end)
                        task.wait(0.05)
                    end

                    task.wait(0.3)

                    if DeleteProp then
                        pcall(function()
                            DeleteProp:InvokeServer()
                        end)
                    end

                    v917()
                end)
            end
        end))
        table.insert(t11, Humanoid:GetPropertyChangedSignal("Sit"):Connect(function()
            local Sit = Humanoid.Sit

            if not Sit then
                Sit = Humanoid.Sit
            end

            if Sit then
                t1.value25()
                task.spawn(function()
                    local Character6 = t1.value18.Character
                    local v1706 = Character6 and Character6:FindFirstChild("HumanoidRootPart")
                    local v1707 = v1706 and v1706.CFrame or CFrame.new(0, 10, 0)

                    for _ = 1, 4 do
                        pcall(function()
                            SetCurrentCFrame:InvokeServer(v1707 + Vector3.new(0, 2, 0))
                        end)
                        task.wait(0.05)
                    end

                    task.wait(0.3)

                    if DeleteProp then
                        pcall(function()
                            DeleteProp:InvokeServer()
                        end)
                    end

                    v917()
                end)
            end
        end))
        local connection
        connection = t1.value2.Heartbeat:Connect(function(dt)
            n5 += dt

            if n5 >= 8 or (not v910.Parent or not Character.Parent) then
                if connection.Connected then
                    connection:Disconnect()
                end

                v917()

                return
            end

            if not Humanoid.Sit then
                n6 += dt * 8.5

                local v1397 = -1.2 + math.sin(n6) * 1.8
                local HumanoidRootPartPosition = HumanoidRootPart.Position

                pcall(function()
                    SetCurrentCFrame:InvokeServer(CFrame.new(HumanoidRootPartPosition.X, HumanoidRootPartPosition.Y + v1397, HumanoidRootPartPosition.Z))
                end)

                return
            end

            if connection.Connected then
                connection:Disconnect()
            end
        end)
        table.insert(t11, connection)
        local timestamp = tick()
        repeat
            if u913 then
                g920 = true
            end

            if g920 then
                break
            end

            task.wait(0.05)
        until tick() - timestamp > 4
        if not g920 then
            v917()
        end
    end)
end
})
v11:AddButton({
	Name = "اقتل الاعب ال اختارته من قايمه",
	Callback = function()
    if not t1.value19 then
        t1.value23("REXM HUB", "ولك اختار الاعب ليه مااخترته!")

        return
    end

    local t1value19 = t1.value1:FindFirstChild(t1.value19)

    if not t1value19 or not t1value19.Character then
        t1.value23("REXM HUB", "لاعب مش موجود!")

        return
    end

    local function v178()
        local v921 = "Prop" .. t1.value18.Name
        local v922 = workspace:FindFirstChild("Model") and (workspace.Model:FindFirstChild("Street") and workspace.Model.Street:FindFirstChild("Street"))

        if v922 then
            local GetChildren = v922.GetChildren

            for _, v in ipairs(GetChildren(v922)) do
                if v921 == v.Name then
                    return v
                end
            end
        end

        local t12 = {
				workspace:FindFirstChild("WorkspaceCom") and workspace.WorkspaceCom:FindFirstChild("001_TrafficCones"),
				workspace:FindFirstChild("WorkspaceCom"),
				workspace:FindFirstChild("Props"),
				workspace
			}

        for _, v in ipairs(t12) do
            if v then
                local GetChildren = v.GetChildren

                for _, v4 in ipairs(GetChildren(v)) do
                    if v921 == v4.Name then
                        return v4
                    end

                    if v4:IsA("Folder") or v4:IsA("Model") then
                        for _, child in ipairs(v4:GetChildren()) do
                            if v921 == child.Name then
                                return child
                            end
                        end
                    end
                end
            end
        end

        return nil
    end

    task.spawn(function()
        pcall(function()
            local v1399 = game:GetService("ReplicatedStorage"):FindFirstChild("RE") or workspace
            local v1400 = v1399:FindFirstChild("1Clea1rTool1s")

            if v1400 then
                v1400:FireServer("ClearAllTools")
                v1400:FireServer("ClearAllProps")
            end

            task.wait(0.2)

            local LocalPlayer = game:GetService("Players").LocalPlayer
            local Character = LocalPlayer.Character

            if Character then
                Character:WaitForChild("HumanoidRootPart")

                local Humanoid = Character:WaitForChild("Humanoid")
                local v1404 = v1399:FindFirstChild("1Too1l")

                if v1404 then
                    v1404:InvokeServer("PickingTools", "PropMaker")
                end

                local PropMaker = LocalPlayer.Backpack:WaitForChild("PropMaker", 5)

                if PropMaker then
                    Humanoid:EquipTool(PropMaker)
                    task.wait(0.4)

                    if v1400 then
                        v1400:FireServer("RequestingPropName", "FurnitureBleachers", "Furniture")
                    end

                    task.wait(0.6)

                    local Tool_PropMake = PropMaker:FindFirstChild("Tool_PropMake")

                    if Tool_PropMake then
                        local v1407 = LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("HumanoidRootPart")

                        if v1407 then
                            local v1408 = v1407.Position + v1407.CFrame.LookVector * 5
                            local vector3 = Vector3.new(v1408.X, v1407.Position.Y - 3, v1408.Z)

                            Tool_PropMake:FireServer(workspace:FindFirstChild("Model") and (workspace.Model:FindFirstChild("Street") and workspace.Model.Street:FindFirstChild("Street")) or workspace, vector3)
                        end
                    end

                    local VirtualUser = game:GetService("VirtualUser")

                    VirtualUser:Button1Down(Vector2.new(0, 500), workspace.CurrentCamera.CFrame)
                    task.wait(0.1)
                    VirtualUser:Button1Up(Vector2.new(0, 500), workspace.CurrentCamera.CFrame)
                end
            end
        end)
        task.wait(2)
        local u934 = v178()
        if not u934 then
            task.wait(1)
            u934 = v178()
        end
        if not u934 then
            t1.value23(".", ".")

            return
        end
        t1.value23("REXM HUB", "تم لقيت الاعب لعيونك ...")
        local SetCurrentCFrame = u934:FindFirstChild("SetCurrentCFrame")
        local DeleteProp = u934:FindFirstChild("DeleteProp")
        if not SetCurrentCFrame then
            t1.value23(".", ". SetCurrentCFrame، .")

            return
        end
        local u937 = false
        local n7 = 0
        local n8 = 0
        local Character = t1value19.Character
        Character:WaitForChild("Humanoid").Seated:Connect(function(isSeated)
            u937 = isSeated
        end)
        local connection
        connection = t1.value2.Heartbeat:Connect(function(dt)
            if false or not u934.Parent then
                connection:Disconnect()

                return
            end

            local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

            if not HumanoidRootPart then
                return
            end

            local HumanoidRootPartPosition = HumanoidRootPart.Position

            if not u937 then
                n8 += dt * 5
                n7 = math.sin(n8) * 2.5 + 2.5 - 2
                pcall(function()
                    SetCurrentCFrame:InvokeServer(CFrame.new(HumanoidRootPartPosition.X, HumanoidRootPartPosition.Y + n7, HumanoidRootPartPosition.Z))
                end)

                return
            end

            n7 -= 80
            pcall(function()
                SetCurrentCFrame:InvokeServer(CFrame.new(HumanoidRootPartPosition.X, HumanoidRootPartPosition.Y + n7, HumanoidRootPartPosition.Z))
            end)

            if n7 < -500 and true then
                if DeleteProp then
                    pcall(function()
                        DeleteProp:InvokeServer()
                    end)
                end

                t1.value23("تم قتله", "تم قتلو لعيونك " .. t1value19.Name .. " لعيونك")
            end
        end)
        t1.value23("REXM HUB", "تم قتل الاعب لعيونك" .. t1value19.Name)
    end)
end
})
v11:AddButton({
	Name = "اقتل الاعبين الفي سرفر",
	Callback = function()
    local v179 = game:GetService("ReplicatedStorage"):FindFirstChild("RE") or workspace
    local v180 = v179:FindFirstChild("1Too1l")
    local v181 = v179:FindFirstChild("1Clea1rTool1s")

    local function v182()
        local v957 = "Prop" .. t1.value18.Name
        local v958 = workspace:FindFirstChild("Model") and (workspace.Model:FindFirstChild("Street") and workspace.Model.Street:FindFirstChild("Street"))

        if v958 then
            for _, child in ipairs(v958:GetChildren()) do
                if v957 == child.Name and not child:GetAttribute("Tracked") then
                    child:SetAttribute("Tracked", true)

                    return child
                end
            end
        end

        local t13 = {
				workspace:FindFirstChild("WorkspaceCom") and workspace.WorkspaceCom:FindFirstChild("001_TrafficCones"),
				workspace:FindFirstChild("WorkspaceCom"),
				workspace:FindFirstChild("Props"),
				workspace
			}

        for _, v in ipairs(t13) do
            if v then
                for _, child in ipairs(v:GetChildren()) do
                    if v957 == child.Name and not child:GetAttribute("Tracked") then
                        child:SetAttribute("Tracked", true)

                        return child
                    end
                end
            end
        end

        return nil
    end
    local function v183(p15)
        pcall(function()
            if v181 then
                v181:FireServer("ClearAllTools")
                v181:FireServer("ClearAllProps")
            end

            task.wait(0.1)

            local Character = t1.value18.Character

            if Character then
                Character:WaitForChild("HumanoidRootPart")

                local Humanoid = Character:WaitForChild("Humanoid")

                if v180 then
                    v180:InvokeServer("PickingTools", "PropMaker")
                end

                local PropMaker = t1.value18.Backpack:WaitForChild("PropMaker", 4)

                if PropMaker then
                    Humanoid:EquipTool(PropMaker)
                    task.wait(0.2)

                    if v181 then
                        v181:FireServer("RequestingPropName", "FurnitureBleachers", "Furniture")
                    end

                    task.wait(0.4)

                    local Tool_PropMake = PropMaker:FindFirstChild("Tool_PropMake")

                    if Tool_PropMake then
                        local v1419 = t1.value18.Character and t1.value18.Character:FindFirstChild("HumanoidRootPart")

                        if v1419 then
                            local v1420 = v1419.Position + v1419.CFrame.LookVector * 5
                            local vector3 = Vector3.new(v1420.X, v1419.Position.Y - 3, v1420.Z)

                            Tool_PropMake:FireServer(workspace:FindFirstChild("Model") and (not not workspace.Model:FindFirstChild("Street") and workspace.Model.Street:FindFirstChild("Street")) or workspace, vector3)
                        end
                    end

                    local VirtualUser = game:GetService("VirtualUser")

                    VirtualUser:Button1Down(Vector2.new(0, 500), workspace.CurrentCamera.CFrame)
                    task.wait(0.05)
                    VirtualUser:Button1Up(Vector2.new(0, 500), workspace.CurrentCamera.CFrame)
                end
            end
        end)
        task.wait(1)
        local v967 = v182()
        if not v967 then
            return true
        end
        local SetCurrentCFrame = v967:FindFirstChild("SetCurrentCFrame")
        local DeleteProp = v967:FindFirstChild("DeleteProp")
        if not SetCurrentCFrame then
            return true
        end
        local u970 = false
        local n9 = 0
        local n10 = 0
        local u973 = false
        local Character = p15.Character
        if not Character then
            return true
        end
        local Humanoid = Character:FindFirstChild("Humanoid")
        if not Humanoid then
            return true
        end
        local connection = Humanoid.Seated:Connect(function(isSeated)
            u970 = isSeated
        end)
        local connection2
        connection2 = t1.value2.Heartbeat:Connect(function(dt)
            local v1425 = false

            if not v1425 then
                v1425 = not v967.Parent

                if not v1425 then
                    v1425 = not p15 or (not p15.Character or not p15.Character:FindFirstChild("HumanoidRootPart"))
                end
            end

            if v1425 then
                if connection then
                    connection:Disconnect()
                end

                connection2:Disconnect()
                u973 = true

                return
            end

            local HumanoidRootPartPosition = p15.Character.HumanoidRootPart.Position

            if not u970 then
                n10 += dt * 7
                n9 = -1.2 + 1.8 * math.sin(n10)
                pcall(function()
                    SetCurrentCFrame:InvokeServer(CFrame.new(HumanoidRootPartPosition.X, HumanoidRootPartPosition.Y + n9, HumanoidRootPartPosition.Z))
                end)

                return
            end

            n9 -= dt * 400
            pcall(function()
                SetCurrentCFrame:InvokeServer(CFrame.new(HumanoidRootPartPosition.X, HumanoidRootPartPosition.Y + n9, HumanoidRootPartPosition.Z))
            end)

            if n9 < -450 and true then
                if DeleteProp then
                    pcall(function()
                        DeleteProp:InvokeServer()
                    end)
                end

                if connection then
                    connection:Disconnect()
                end

                connection2:Disconnect()
                u973 = true
            end
        end)
        local timestamp = tick()
        local g979
        repeat
            if u973 then
                g979 = true
            end

            if g979 then
                break
            end

            task.wait(0.1)
        until tick() - timestamp > 30
        if not g979 then
            if DeleteProp then
                pcall(function()
                    DeleteProp:InvokeServer()
                end)
            end

            if connection then
                connection:Disconnect()
            end

            if connection2 then
                connection2:Disconnect()
            end
        end
        g979 = false

        return true
    end

    local v184 = (function(p16)
        local t14 = {}
        for v946, v947 in ipairs(t1.value1:GetPlayers()) do

            if v947 ~= t1.value18 and (v947.Character and v947.Character:FindFirstChild("HumanoidRootPart")) then
                table.insert(t14, v947)
            end
        end
        if #t14 == 0 then
            return {}
        end
        local t15 = {}
        local t16 = {}
        for i, v in ipairs(t14) do
            t16[i] = v
        end
        for i = #t16, 2, -1 do
            local v953 = math.random(i)
            local v954 = t16[v953]
            local v955 = t16[i]

            t16[i] = v954
            t16[v953] = v955
        end
        for i = 1, math.min(p16, #t16) do
            table.insert(t15, t16[i])
        end

        return t15
    end)(15)

    if #v184 == 0 then
        t1.value23("REXM HUB", "مفيش لاعبين في سرفر!")

        return
    end

    task.spawn(function()
        for _, v in ipairs(v184) do
            if v and v.Parent then
                v183(v)
                task.wait(1)
            end
        end

        t1.value23("REX HUB", "تم قتل كل الاعبين الفي سرفر لعيونك")
    end)
end
})
v11:AddSection({
	Name = "تخريب بي اشياء ثانيه"
})
t1.value26 = "Bus"
v11:AddDropdown({
	Name = "اختار الطريقه التبيها",
	Options = {
		"Bus",
		"Couch",
		"Couch Sem ir até o alvo [BETA]"
	},
	Default = "",
	Callback = function(p17)
    t1.value26 = p17
end
})
function t1.value27()
end
function t1.value28()
end
function t1.value29()
end
function t1.value30()
end
v11:AddButton({
	Name = "تفعيل علي الاعب",
	Callback = function()
    local v186 = not t1.value19

    if not v186 then
        v186 = not t1.value1:FindFirstChild(t1.value19)
    end

    if v186 then
        return
    end

    if t1.value26 == "Couch" then
        t1.value27()

        return
    end

    if t1.value26 == "Couch Sem ir até o alvo [BETA]" then
        t1.value28()

        return
    end

    local Character = t1.value18.Character
    local v188 = Character and Character:FindFirstChild("HumanoidRootPart")

    if not v188 then
        return
    end

    local CFrame2 = v188.CFrame

    local function v190()
        local Vehicles = game.Workspace:FindFirstChild("Vehicles")

        if Vehicles then
            return Vehicles:FindFirstChild(t1.value18.Name .. "Car")
        end

        return nil
    end

    local u191 = v190()

    if not u191 then
        v188.CFrame = CFrame.new(1118.81, 75.998, -1138.61)
        task.wait(0.5)

        local RE = t1.value21:FindFirstChild("RE")

        if RE and RE:FindFirstChild("1Ca1r") then
            RE["1Ca1r"]:FireServer("PickingCar", "SchoolBus")
        end

        task.wait(1)
        u191 = v190()
    end

    if u191 then
        local v193 = u191:FindFirstChild("Body") and u191.Body:FindFirstChild("VehicleSeat")

        if v193 and (Character:FindFirstChildOfClass("Humanoid") and not Character.Humanoid.Sit) then
            if not Character.Humanoid.Sit then
                local _ = u191.Parent
            end

            repeat
                v188.CFrame = v193.CFrame * CFrame.new(0, 2, 0)
                task.wait()
            until Character.Humanoid.Sit or not u191.Parent

            if Character.Humanoid.Sit or not u191.Parent then
                for _, child in pairs(u191.Body:GetChildren()) do
                    if child:IsA("Seat") then
                        child.CanTouch = false
                    end
                end
            end
        end
    end

    spawn(function()
        while true do
            if t1.value19 then
                local t1value19 = t1.value1:FindFirstChild(t1.value19)

                if t1value19 and (t1value19.Character and t1value19.Character:FindFirstChild("HumanoidRootPart")) then
                    local Humanoid = t1value19.Character:FindFirstChildOfClass("Humanoid")

                    if Humanoid and Humanoid.Sit then
                        if Character.Humanoid then
                            u191:SetPrimaryPartCFrame(CFrame.new(Vector3.new(9999, -450, 9999)))
                            task.wait(0.2)

                            local v985 = Character and Character:FindFirstChildWhichIsA("Humanoid")

                            if v985 then
                                v985:ChangeState(Enum.HumanoidStateType.Jumping)
                            end

                            task.wait(0.5)
                            v188.CFrame = CFrame2
                        end

                        return
                    end

                    local HumanoidRootPart = t1value19.Character.HumanoidRootPart
                    local timestamp = tick()
                    local _math = math
                    local v989 = timestamp * 35
                    local v990 = _math.sin(v989)
                    local _math2 = math
                    local v992 = v990 * 4
                    local v993 = _math2.cos(v989) * 20

                    u191:SetPrimaryPartCFrame(HumanoidRootPart.CFrame * CFrame.new(v992, 0, v993))
                end
            end

            t1.value2.RenderStepped:Wait()
        end
    end)
end
})
v11:AddButton({
	Name = "اسحب الاعب ال اخترتها لعندك",
	Callback = function()
    local v197 = not t1.value19

    if not v197 then
        v197 = not t1.value1:FindFirstChild(t1.value19)
    end

    if v197 then
        return
    end

    if t1.value26 == "Couch" then
        t1.value29()

        return
    end

    if t1.value26 == "Couch Sem ir até o alvo [BETA]" then
        t1.value30()

        return
    end

    local Character = t1.value18.Character
    local v199 = Character and Character:FindFirstChild("HumanoidRootPart")

    if not v199 then
        return
    end

    local CFrame3 = v199.CFrame

    local function v201()
        local Vehicles = game.Workspace:FindFirstChild("Vehicles")

        if Vehicles then
            return Vehicles:FindFirstChild(t1.value18.Name .. "Car")
        end

        return nil
    end

    local u202 = v201()

    if not u202 then
        v199.CFrame = CFrame.new(1118.81, 75.998, -1138.61)
        task.wait(0.5)

        local RE = t1.value21:FindFirstChild("RE")

        if RE and RE:FindFirstChild("1Ca1r") then
            RE["1Ca1r"]:FireServer("PickingCar", "SchoolBus")
        end

        task.wait(1)
        u202 = v201()
    end

    if u202 then
        local v204 = u202:FindFirstChild("Body") and u202.Body:FindFirstChild("VehicleSeat")

        if v204 and (Character:FindFirstChildOfClass("Humanoid") and not Character.Humanoid.Sit) then
            if not Character.Humanoid.Sit then
                local _ = u202.Parent
            end

            repeat
                v199.CFrame = v204.CFrame * CFrame.new(0, 2, 0)
                task.wait()
            until Character.Humanoid.Sit or not u202.Parent
        end
    end

    spawn(function()
        while true do
            if t1.value19 then
                local t1value19 = t1.value1:FindFirstChild(t1.value19)

                if t1value19 and (t1value19.Character and t1value19.Character:FindFirstChild("HumanoidRootPart")) then
                    local Humanoid = t1value19.Character:FindFirstChildOfClass("Humanoid")

                    if Humanoid and Humanoid.Sit then
                        if Character.Humanoid then
                            u202:SetPrimaryPartCFrame(CFrame3)
                            task.wait(0.7)

                            local t17 = {
									[1] = "DeleteAllVehicles"
								}

                            t1.value21.RE:FindFirstChild("1Ca1r"):FireServer(unpack(t17))
                        end

                        return
                    end

                    local HumanoidRootPart = t1value19.Character.HumanoidRootPart
                    local timestamp = tick()
                    local _math = math
                    local v1001 = timestamp * 35
                    local v1002 = _math.sin(v1001) * 4
                    local v1003 = math.cos(v1001) * 20

                    u202:SetPrimaryPartCFrame(HumanoidRootPart.CFrame * CFrame.new(v1002, 0, v1003))
                end
            end

            t1.value2.RenderStepped:Wait()
        end
    end)
end
})
v11:AddButton({
	Name = "سوي باند بيت لللاعب المختار",
	Callback = function()
    if not t1.value19 then
        return
    end

    local LocalPlayer = game.Players.LocalPlayer
    local _ = LocalPlayer.Backpack
    local Character = LocalPlayer.Character
    local Humanoid = Character:FindFirstChildOfClass("Humanoid")
    local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")
    local v211 = game.Workspace:FindFirstChild("001_Lots")
    local _ = HumanoidRootPart.CFrame
    local n11 = 0
    local Vehicles = workspace.Vehicles

    function Check()
        local v1004 = LocalPlayer

        if v1004 then
            v1004 = Character and (Humanoid and (HumanoidRootPart and Vehicles))
        end

        if v1004 then
            return true
        end

        return false
    end

    local t1value19 = game.Players:FindFirstChild(t1.value19)

    if t1value19 and t1value19.Character and Check() then
        if not v211:FindFirstChild(LocalPlayer.Name .. "House") then
            local t18 = {}
            local GetChildren = v211.GetChildren
            for v220, v221 in pairs(GetChildren(v211)) do

                if v221.Name == "For Sale" then
                    for _, descendant in pairs(v221:GetDescendants()) do
                        if descendant:IsA("NumberValue") and (descendant.Name == "Number" and (descendant.Value < 25 and descendant.Value > 10)) then
                            local insert = table.insert
                            local descendantValue = descendant.Value

                            insert(t18, {
									Lot = v221,
									Number = descendantValue
								})

                            break
                        end
                    end
                end
            end
            if not (#t18 > 0) then
                return
            end
            local v226 = t18[math.random(1, #t18)]
            local Lot = v226.Lot
            local Number = v226.Number
            local BuyHouse = Lot:FindFirstChild("BuyHouse")
            local _ = BuyHouse.Position
            if BuyHouse and BuyHouse:IsA("BasePart") then
                HumanoidRootPart.CFrame = BuyHouse.CFrame + Vector3.new(0, -6, 0)
                task.wait(0.5)

                local ClickDetector = BuyHouse:FindFirstChild("ClickDetector")

                if ClickDetector then
                    fireclickdetector(ClickDetector)
                end
            end
            task.wait(0.5)
            game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("Lot:BuildProperty"):FireServer(unpack({
					Number,
					"056_House"
				}))
        end

        task.wait(0.5)

        local v232 = v211:FindFirstChild(LocalPlayer.Name .. "House")

        if v232 then
            task.wait(0.5)
            local v233
            for _, descendant in pairs(v232:GetDescendants()) do
                if descendant.Name == "Number" and descendant:IsA("NumberValue") then
                    v233 = descendant
                end
            end
            task.wait(0.5)
            game:GetService("ReplicatedStorage").RE:FindFirstChild("1Gettin1gHous1e"):FireServer("PickingCustomHouse", "049_House", v233.Value)
        end

        task.wait(0.5)

        if not Vehicles:FindFirstChild(LocalPlayer.Name .. "Car") and Check() then
            HumanoidRootPart.CFrame = CFrame.new(1118.81, 75.998, -1138.61)
            task.wait(0.5)
            game:GetService("ReplicatedStorage").RE:FindFirstChild("1Ca1r"):FireServer("PickingCar", "SchoolBus")
            task.wait(0.5)

            local v236 = Vehicles:FindFirstChild(LocalPlayer.Name .. "Car")

            task.wait(0.5)

            local v237 = v236:FindFirstChild("Body") and v236.Body:FindFirstChild("VehicleSeat")

            if v237 then
                local _ = Humanoid.Sit

                repeat
                    task.wait()
                    HumanoidRootPart.CFrame = v237.CFrame * CFrame.new(0, math.random(-1, 1), 0)
                until Humanoid.Sit
            end
        end

        task.wait(0.5)

        local v239 = Vehicles:FindFirstChild(LocalPlayer.Name .. "Car")

        if v239 then
            if not Humanoid.Sit then
                local v240 = v239:FindFirstChild("Body") and v239.Body:FindFirstChild("VehicleSeat")

                if v240 then
                    local _ = Humanoid.Sit

                    repeat
                        task.wait()
                        HumanoidRootPart.CFrame = v240.CFrame * CFrame.new(0, math.random(-1, 1), 0)
                    until Humanoid.Sit
                end
            end

            local Character7 = t1value19.Character
            local Humanoid5 = Character7:FindFirstChildOfClass("Humanoid")
            local HumanoidRootPart2 = Character7:FindFirstChild("HumanoidRootPart")

            if Character7 and (Humanoid5 and HumanoidRootPart2) and not Humanoid5.Sit then
                while not Humanoid5.Sit do
                    task.wait()

                    local function v245(p18, p19, p20)
                        v239:SetPrimaryPartCFrame(CFrame.new(p18.Position) * p19 * p20)
                    end

                    n11 += 100
                    v245(HumanoidRootPart2, CFrame.new(0, 1.5, 0) + Humanoid5.MoveDirection * HumanoidRootPart2.Velocity.Magnitude / 1.1, CFrame.Angles(math.rad(n11), 0, 0))
                    v245(HumanoidRootPart2, CFrame.new(0, -1.5, 0) + Humanoid5.MoveDirection * HumanoidRootPart2.Velocity.Magnitude / 1.1, CFrame.Angles(math.rad(n11), 0, 0))
                    v245(HumanoidRootPart2, CFrame.new(2.25, 1.5, -2.25) + Humanoid5.MoveDirection * HumanoidRootPart2.Velocity.Magnitude / 1.1, CFrame.Angles(math.rad(n11), 0, 0))
                    v245(HumanoidRootPart2, CFrame.new(-2.25, -1.5, 2.25) + Humanoid5.MoveDirection * HumanoidRootPart2.Velocity.Magnitude / 1.1, CFrame.Angles(math.rad(n11), 0, 0))
                    v245(HumanoidRootPart2, CFrame.new(0, 1.5, 0) + Humanoid5.MoveDirection * HumanoidRootPart2.Velocity.Magnitude / 1.1, CFrame.Angles(math.rad(n11), 0, 0))
                    v245(HumanoidRootPart2, CFrame.new(0, -1.5, 0) + Humanoid5.MoveDirection * HumanoidRootPart2.Velocity.Magnitude / 1.1, CFrame.Angles(math.rad(n11), 0, 0))
                end

                task.wait(0.2)

                local v246 = v211:FindFirstChild(LocalPlayer.Name .. "House")
                local t19 = { CFrame.new(v246.HouseSpawnPosition.Position) }

                v239:SetPrimaryPartCFrame(v2(t19))
                task.wait(0.2)

                local region3 = Region3.new(game.Players.LocalPlayer.Character.HumanoidRootPart.Position - Vector3.new(30, 30, 30), game.Players.LocalPlayer.Character.HumanoidRootPart.Position + Vector3.new(30, 30, 30))
                local PartsInRegion3 = workspace:FindPartsInRegion3(region3, game.Players.LocalPlayer.Character.HumanoidRootPart, 1e999)

                for _, v in pairs(PartsInRegion3) do
                    if v.Name == "HumanoidRootPart" then
                        local vParentName = game:GetService("Players"):FindFirstChild(v.Parent.Name)
                        local vParent = v.Parent
                        local t20 = {
								[1] = "BanPlayerFromHouse",
								[2] = vParentName,
								[3] = vParent
							}

                        game:GetService("ReplicatedStorage").RE:FindFirstChild("1Playe1rTrigge1rEven1t"):FireServer(unpack(t20))

                        local t21 = {
								[1] = "DeleteAllVehicles"
							}
                        local v256 = game:GetService("ReplicatedStorage").RE:FindFirstChild("1Ca1r")
                        local t22 = { unpack(t21) }

                        v256:FireServer(v2(t22))
                    end
                end
            end
        end
    end
end
})
v11:AddToggle({
	Name = "تفعيل فلنق تلقايي علي اخترتها😍",
	Default = false,
	Callback = function(p21)
    local v259 = p21

    if p21 then
        v259 = t1.value19
    end

    if v259 then
        local t1value19 = t1.value1:FindFirstChild(t1.value19)

        if not t1value19 or not t1value19.Character then
            return
        end

        local v261 = t1.value18.Character and t1.value18.Character:FindFirstChild("HumanoidRootPart")
        local v262 = t1value19.Character and t1value19.Character:FindFirstChild("HumanoidRootPart")

        if not v261 or not v262 then
            return
        end

        local Character = t1.value18.Character
        local Humanoid = Character:FindFirstChildOfClass("Humanoid")
        local CFrame4 = v261.CFrame
        local CurrentCamera = workspace.CurrentCamera

        game:GetService("ReplicatedStorage"):WaitForChild("RE"):WaitForChild("1Clea1rTool1s"):FireServer(unpack({ "ClearAllTools" }))
        task.wait(0.2)

        local t23 = {
				[1] = "PickingTools",
				[2] = "Couch"
			}
        local v268 = game:GetService("ReplicatedStorage").RE:FindFirstChild("1Too1l")
        local t24 = { unpack(t23) }

        v268:InvokeServer(v2(t24))
        task.wait(0.3)

        local Couch = t1.value18.Backpack:FindFirstChild("Couch")

        if Couch then
            Couch.Parent = Character
        end

        task.wait(0.2)
        game:GetService("VirtualInputManager"):SendKeyEvent(true, Enum.KeyCode.F, false, game)
        task.wait(0.25)
        workspace.FallenPartsDestroyHeight = (0/0)

        local BodyVelocity = Instance.new("BodyVelocity")

        BodyVelocity.Name = "FlingForce"
        BodyVelocity.Velocity = Vector3.new(900000000, 900000000, 900000000)
        BodyVelocity.MaxForce = Vector3.new(1e999, 1e999, 1e999)
        BodyVelocity.Parent = v261
        Humanoid:SetStateEnabled(Enum.HumanoidStateType.Seated, false)
        Humanoid.PlatformStand = false
        CurrentCamera.CameraSubject = t1value19.Character:FindFirstChild("Head") or (v262 or Humanoid)
        task.spawn(function()
            local v1008
            local t25 = { v261 }
            while true do
                local v1010 = p21

                if v1010 then
                    v1010 = t1value19 and (t1value19.Character and t1value19.Character:FindFirstChildOfClass("Humanoid"))
                end

                if not v1010 or t1value19.Character:FindFirstChildOfClass("Humanoid").Sit then
                    break
                end

                v1008 += 50

                for _, _ in ipairs(t25) do
                    local PositionX = t1value19.Character.HumanoidRootPart.Position.X
                    local PositionY = t1value19.Character.HumanoidRootPart.Position.Y
                    local PositionZ = t1value19.Character.HumanoidRootPart.Position.Z
                    local v1016 = PositionX + t1value19.Character.HumanoidRootPart.Velocity.X / 1.5
                    local v1017 = PositionY + t1value19.Character.HumanoidRootPart.Velocity.Y / 1.5
                    local v1018 = PositionZ + t1value19.Character.HumanoidRootPart.Velocity.Z / 1.5

                    v261.CFrame = CFrame.new(v1016, v1017, v1018) * CFrame.Angles(math.rad(v1008), 0, 0)
                end

                v261.Velocity = Vector3.new(900000000, 900000000, 900000000)
                v261.RotVelocity = Vector3.new(900000000, 900000000, 900000000)
                task.wait()
            end
            BodyVelocity:Destroy()
            Humanoid:SetStateEnabled(Enum.HumanoidStateType.Seated, true)
            Humanoid.PlatformStand = false
            v261.CFrame = CFrame4
            CurrentCamera.CameraSubject = Humanoid
            for _, descendant in pairs(Character:GetDescendants()) do
                if descendant:IsA("BasePart") then
                    descendant.Velocity = Vector3.zero
                    descendant.RotVelocity = Vector3.zero
                end
            end
            Humanoid:UnequipTools()
            game:GetService("ReplicatedStorage").RE:FindFirstChild("1Too1l"):InvokeServer(unpack(t23))
        end)
    end
end
})
local function v14(p22)
    local Players = game:GetService("Players")
    local LocalPlayer = Players.LocalPlayer
    local v275 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()
    local Humanoid = v275:WaitForChild("Humanoid")

    v275:WaitForChild("HumanoidRootPart")

    local Backpack = LocalPlayer:WaitForChild("Backpack")
    local v278 = workspace.WorkspaceCom:WaitForChild("001_SoccerBalls"):FindFirstChild("Soccer" .. LocalPlayer.Name) or (function()
        if not Backpack:FindFirstChild("SoccerBall") then
            game:GetService("ReplicatedStorage").RE:FindFirstChild("1Too1l"):InvokeServer("PickingTools", "SoccerBall")
        end

        Backpack:FindFirstChild("SoccerBall")

        repeat
            task.wait()
        until Backpack:FindFirstChild("SoccerBall")

        Backpack.SoccerBall.Parent = v275;
        (nil):FindFirstChild("Soccer" .. LocalPlayer.Name)

        repeat
            task.wait()
        until (nil):FindFirstChild("Soccer" .. LocalPlayer.Name)

        v275.SoccerBall.Parent = Backpack

        return (nil):FindFirstChild("Soccer" .. LocalPlayer.Name)
    end)()

    v278.CanCollide = false
    v278.Massless = true
    v278.CustomPhysicalProperties = PhysicalProperties.new(0.0001, 0, 0)

    if p22 ~= LocalPlayer then
        local Character = p22.Character

        if Character and (Character:FindFirstChild("HumanoidRootPart") and Character:FindFirstChild("Humanoid")) then
            local HumanoidRootPart = Character.HumanoidRootPart
            local Humanoid6 = Character.Humanoid

            if v278:FindFirstChildWhichIsA("BodyVelocity") then
                v278:FindFirstChildWhichIsA("BodyVelocity"):Destroy()
            end

            local BodyVelocity = Instance.new("BodyVelocity")

            BodyVelocity.Name = "FlingPower"
            BodyVelocity.Velocity = Vector3.new(900000000, 900000000, 900000000)
            BodyVelocity.MaxForce = Vector3.new(1e999, 1e999, 1e999)
            BodyVelocity.P = 1e999
            BodyVelocity.Parent = v278
            workspace.CurrentCamera.CameraSubject = Humanoid6

            if not (HumanoidRootPart.Velocity.Magnitude > 1000) and not (Humanoid6.Health <= 0) and Character:IsDescendantOf(workspace) then
                if Players == p22.Parent then
                end
            end

            repeat
                if HumanoidRootPart.Velocity.Magnitude > 0 then
                    local v283 = HumanoidRootPart.Position.X + HumanoidRootPart.Velocity.X / 1.5
                    local v284 = HumanoidRootPart.Position.Y + HumanoidRootPart.Velocity.Y / 1.5
                    local v285 = HumanoidRootPart.Position.Z + HumanoidRootPart.Velocity.Z / 1.5
                    local vector3 = Vector3.new(v283, v284, v285)

                    v278.CFrame = CFrame.new(vector3)

                    local s27 = "Orientation"
                    local vector3_2 = Vector3.new(45, 60, 30)

                    v278[s27] = v278[s27] + vector3_2
                else
                    for _, child in pairs(Character:GetChildren()) do
                        if child:IsA("BasePart") and (child.CanCollide and not child.Anchored) then
                            v278.CFrame = child.CFrame
                            task.wait(0.00016666666666667)
                        end
                    end
                end

                task.wait(0.00016666666666667)

                local v291 = HumanoidRootPart.Velocity.Magnitude > 1000

                if not v291 then
                    v291 = Humanoid6.Health <= 0

                    if not v291 then
                        v291 = not Character:IsDescendantOf(workspace) or Players ~= p22.Parent
                    end
                end
            until v291

            workspace.CurrentCamera.CameraSubject = Humanoid
        end
    end
end
v11:AddButton({
	Name = "فلنق كره",
	Callback = function()
    v14(game:GetService("Players")[t1.value19])
end
})
v11:AddSection({
	Name = "فلنق مركب"
})
v11:AddButton({
	Name = "فلنق - مركب يبرو",
	Callback = function()
    if not t1.value19 or not game.Players:FindFirstChild(t1.value19) then
        return
    end

    local LocalPlayer = game.Players.LocalPlayer
    local Character = LocalPlayer.Character
    local v304 = Character and Character:FindFirstChildOfClass("Humanoid")
    local v305 = Character and Character:FindFirstChild("HumanoidRootPart")
    local Vehicles = game.Workspace:FindFirstChild("Vehicles")

    if not v304 or not v305 then
        return
    end

    local v307 = Vehicles:FindFirstChild(LocalPlayer.Name .. "Car") or (function()
        v305.CFrame = CFrame.new(1754, -2, 58)
        task.wait(0.5)
        game:GetService("ReplicatedStorage").RE:FindFirstChild("1Ca1r"):FireServer("PickingBoat", "MilitaryBoatFree")
        task.wait(1)

        return Vehicles:FindFirstChild(LocalPlayer.Name .. "Car")
    end)()

    if not v307 then
        return
    end

    local v308 = v307:FindFirstChild("Body") and v307.Body:FindFirstChild("VehicleSeat")

    if not v308 then
        return
    end

    if v308 ~= v304.SeatPart then
    end

    repeat
        task.wait(0.1)
        v305.CFrame = v308.CFrame * CFrame.new(0, 1, 0)
    until v308 == v304.SeatPart

    local t1value19 = game.Players:FindFirstChild(t1.value19)

    if not t1value19 or not t1value19.Character then
        return
    end

    local Character8 = t1value19.Character
    local Humanoid = Character8:FindFirstChildOfClass("Humanoid")
    local HumanoidRootPart = Character8:FindFirstChild("HumanoidRootPart")

    if not HumanoidRootPart or not Humanoid then
        return
    end

    local BodyAngularVelocity = Instance.new("BodyAngularVelocity")

    BodyAngularVelocity.Name = "Spinning"
    BodyAngularVelocity.Parent = v307.PrimaryPart
    BodyAngularVelocity.MaxTorque = Vector3.new(0, 1e999, 0)
    BodyAngularVelocity.AngularVelocity = Vector3.new(0, 369, 0)

    local function v314(p23, p24)
        if v307 and v307.PrimaryPart then
            local v1025 = v307
            local t26 = { CFrame.new(p23.Position + p24) }

            v1025:SetPrimaryPartCFrame(v2(t26))
        end
    end

    task.spawn(function()
        while true do
            local v1027 = v307

            if v1027 then
                v1027 = v307.Parent and (HumanoidRootPart and HumanoidRootPart.Parent)
            end

            if not v1027 then
                break
            end

            task.wait(0.01)
            v314(HumanoidRootPart, Vector3.new(0, 1, 0))
            v314(HumanoidRootPart, Vector3.new(0, -2.25, 5))
            v314(HumanoidRootPart, Vector3.new(0, 2.25, 0.25))
            v314(HumanoidRootPart, Vector3.new(-2.25, -1.5, 2.25))
            v314(HumanoidRootPart, Vector3.new(0, 1.5, 0))
            v314(HumanoidRootPart, Vector3.new(0, -1.5, 0))

            if v307 and v307.PrimaryPart then
                local cFrame = CFrame.Angles(math.rad((math.random(-369, 369))), math.rad((math.random(-369, 369))), (math.rad((math.random(-369, 369)))))

                v307:SetPrimaryPartCFrame(CFrame.new(HumanoidRootPart.Position + Vector3.new(0, 1.5, 0)) * cFrame)
            end
        end

        if BodyAngularVelocity and BodyAngularVelocity.Parent then
            BodyAngularVelocity:Destroy()
        end
    end)
end
})
v11:AddButton({
	Name = "فلنق مركب سريع - برو",
	Callback = function()
    local LocalPlayer = game.Players.LocalPlayer
    local Character = LocalPlayer.Character
    local v317 = Character and Character:FindFirstChild("HumanoidRootPart")
    local v318 = Character and Character:FindFirstChildOfClass("Humanoid")
    local Vehicles = game.Workspace:FindFirstChild("Vehicles")

    if not v317 or not v318 then
        return
    end

    v318.PlatformStand = true

    local GetChildren = v317.GetChildren

    for _, v in pairs(GetChildren(v317)) do
        if v:IsA("BodyAngularVelocity") or v:IsA("BodyVelocity") then
            v:Destroy()
        end
    end

    game:GetService("ReplicatedStorage").RE:FindFirstChild("1Ca1r"):FireServer("DeleteAllVehicles")
    task.wait(0.5)

    if Vehicles then
        Vehicles = Vehicles:FindFirstChild(LocalPlayer.Name .. "Car")
    end

    if Vehicles and Vehicles.PrimaryPart then
        for _, child in pairs(Vehicles.PrimaryPart:GetChildren()) do
            if child:IsA("BodyAngularVelocity") or child:IsA("BodyVelocity") then
                child:Destroy()
            end
        end
    end

    task.wait(1)

    local vector3 = Vector3.new(0, 1000, 0)
    local BodyPosition = Instance.new("BodyPosition", v317)

    BodyPosition.Position = vector3
    BodyPosition.MaxForce = Vector3.new(1e999, 1e999, 1e999)

    local BodyGyro = Instance.new("BodyGyro", v317)

    BodyGyro.CFrame = v317.CFrame
    BodyGyro.MaxTorque = Vector3.new(1e999, 1e999, 1e999)
    task.wait(3)
    BodyPosition:Destroy()
    BodyGyro:Destroy()
    v318.PlatformStand = false
end
})
v11:AddSection({
	Name = "اضغط علي الاعب التبيه بعد لما تاخد الشي الهتستخدمه"
})
v11:AddButton({
	Name = "ابواب :) [عادي]",
	Description = "هيا احيانا بتعلق",
	Callback = function()
    local Players = game:GetService("Players")
    local Workspace = game:GetService("Workspace")
    local RunService = game:GetService("RunService")
    local UserInputService = game:GetService("UserInputService")
    local LocalPlayer = Players.LocalPlayer
    local HumanoidRootPart = (LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()):WaitForChild("HumanoidRootPart")
    local Part = Instance.new("Part")

    Part.Size = Vector3.new(100000, 100000, 100000)
    Part.Transparency = 1
    Part.Anchored = true
    Part.CanCollide = false
    Part.Name = "BlackHoleTarget"
    Part.Parent = Workspace

    local Attachment = Instance.new("Attachment")

    Attachment.Name = "Luscaa_BlackHoleAttachment"
    Attachment.Parent = Part
    RunService.Heartbeat:Connect(function()
        Part.CFrame = HumanoidRootPart.CFrame
    end)

    local t27 = {}

    local function v337(p25)
        if not p25:IsA("BasePart") or (p25.Anchored or not string.find(p25.Name, "Door")) then
            return
        end

        if p25:FindFirstChild("Luscaa_Attached") then
            return
        end

        p25.CanCollide = false

        local GetChildren = p25.GetChildren

        for _, v in ipairs(GetChildren(p25)) do
            if v:IsA("AlignPosition") or (v:IsA("Torque") or v:IsA("Attachment")) then
                v:Destroy()
            end
        end

        Instance.new("BoolValue", p25).Name = "Luscaa_Attached"

        local Attachment2 = Instance.new("Attachment", p25)
        local AlignPosition = Instance.new("AlignPosition", p25)

        AlignPosition.Attachment0 = Attachment2
        AlignPosition.Attachment1 = Attachment
        AlignPosition.MaxForce = 1E+20
        AlignPosition.MaxVelocity = 1e999
        AlignPosition.Responsiveness = 99999

        local Torque = Instance.new("Torque", p25)

        Torque.Attachment0 = Attachment2
        Torque.RelativeTo = Enum.ActuatorRelativeTo.World
        Torque.Torque = Vector3.new(math.random(-1000000, 1000000) * 10000, math.random(-1000000, 1000000) * 10000, math.random(-1000000, 1000000) * 10000)
        table.insert(t27, {
				Part = p25,
				Align = AlignPosition
			})
    end

    for _, descendant in ipairs(Workspace:GetDescendants()) do
        if descendant:IsA("BasePart") and string.find(descendant.Name, "Door") then
            v337(descendant)
        end
    end

    Workspace.DescendantAdded:Connect(function(descendant)
        if descendant:IsA("BasePart") and string.find(descendant.Name, "Door") then
            v337(descendant)
        end
    end)

    local function v340(p26)
        local Character = p26.Character
        if not Character then
            return
        end
        local HumanoidRootPart3 = Character:FindFirstChild("HumanoidRootPart")
        if not HumanoidRootPart3 then
            return
        end
        local SHNMAX_TargetAttachment = HumanoidRootPart3:FindFirstChild("SHNMAX_TargetAttachment")
        if not SHNMAX_TargetAttachment then
            SHNMAX_TargetAttachment = Instance.new("Attachment", HumanoidRootPart3)
            SHNMAX_TargetAttachment.Name = "SHNMAX_TargetAttachment"
        end
        for v1043, v1044 in ipairs(t27) do

            if v1044.Align then
                v1044.Align.Attachment1 = SHNMAX_TargetAttachment
            end
        end
        local timestamp = tick()
        while tick() - timestamp < 5 and not (HumanoidRootPart3.Velocity.Magnitude >= 20) do
            RunService.Heartbeat:Wait()
        end
        for _, v in ipairs(t27) do
            if v.Align then
                v.Align.Attachment1 = Attachment
            end
        end
    end

    UserInputService.TouchTap:Connect(function(p27, p28)
        if p28 then
            return
        end

        local v1050 = p27[1]
        local v1051 = Workspace.CurrentCamera:ScreenPointToRay(v1050.X, v1050.Y)
        local raycastResult = Workspace:Raycast(v1051.Origin, v1051.Direction * 1000)

        if raycastResult and raycastResult.Instance then
            local Instance2 = raycastResult.Instance
            local player = Players:GetPlayerFromCharacter(Instance2:FindFirstAncestorOfClass("Model"))

            if player and player ~= LocalPlayer then
                v340(player)
            end
        end
    end)
end
})
v11:AddButton({
	Name = "اضغط علي الاعب التبيه وانت ماسك الاداه (اداه)",
	Callback = function()
    local Players = game:GetService("Players")
    local ReplicatedStorage = game:GetService("ReplicatedStorage")
    local UserInputService = game:GetService("UserInputService")
    local LocalPlayer = Players.LocalPlayer
    local CurrentCamera = workspace.CurrentCamera
    local u346 = false
    local Backpack = LocalPlayer:WaitForChild("Backpack")

    if not Backpack:FindFirstChild("Click Fling Couch") and (not LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("Click Fling Couch")) then
        local Tool = Instance.new("Tool")

        Tool.Name = "Click Fling Couch"
        Tool.RequiresHandle = false
        Tool.CanBeDropped = false
        Tool.Equipped:Connect(function()
            u346 = true
        end)
        Tool.Unequipped:Connect(function()
            u346 = false
        end)
        Tool.Parent = Backpack
    end

    local function v349(p29)
        if not u346 then
            return
        end

        if not p29 or (not p29.Character or p29 == LocalPlayer) then
            return
        end

        local u1056 = true
        local v1057 = LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
        local v1058 = p29.Character and p29.Character:FindFirstChild("HumanoidRootPart")

        if not v1057 or not v1058 then
            return
        end

        local Character = LocalPlayer.Character
        local Humanoid = Character:FindFirstChildOfClass("Humanoid")
        local CFrame5 = v1057.CFrame

        ReplicatedStorage:WaitForChild("RE"):WaitForChild("1Clea1rTool1s"):FireServer("ClearAllTools")
        task.wait(0.2)
        ReplicatedStorage.RE:FindFirstChild("1Too1l"):InvokeServer("PickingTools", "Couch")
        task.wait(0.3)

        local Couch = LocalPlayer.Backpack:FindFirstChild("Couch")

        if Couch then
            Couch.Parent = Character
        end

        task.wait(0.1)
        game:GetService("VirtualInputManager"):SendKeyEvent(true, Enum.KeyCode.F, false, game)
        task.wait(0.25)
        workspace.FallenPartsDestroyHeight = (0/0)

        local BodyVelocity = Instance.new("BodyVelocity")

        BodyVelocity.Name = "ForcaJogada"
        BodyVelocity.Velocity = Vector3.new(900000000, 900000000, 900000000)
        BodyVelocity.MaxForce = Vector3.new(1e999, 1e999, 1e999)
        BodyVelocity.Parent = v1057
        Humanoid:SetStateEnabled(Enum.HumanoidStateType.Seated, false)
        Humanoid.PlatformStand = false
        CurrentCamera.CameraSubject = p29.Character:FindFirstChild("Head") or (v1058 or Humanoid)
        task.spawn(function()
            local v1440
            local t28 = { v1057 }
            while true do
                local v1442 = u1056

                if v1442 then
                    v1442 = p29 and (p29.Character and p29.Character:FindFirstChildOfClass("Humanoid"))
                end

                if not v1442 or p29.Character:FindFirstChildOfClass("Humanoid").Sit then
                    break
                end

                v1440 += 50

                for _, _ in ipairs(t28) do
                    local HumanoidRootPart = p29.Character.HumanoidRootPart
                    local v1446 = HumanoidRootPart.Position + HumanoidRootPart.Velocity / 1.5

                    v1057.CFrame = CFrame.new(v1446) * CFrame.Angles(math.rad(v1440), 0, 0)
                end

                v1057.Velocity = Vector3.new(900000000, 900000000, 900000000)
                v1057.RotVelocity = Vector3.new(900000000, 900000000, 900000000)
                task.wait()
            end
            u1056 = false
            BodyVelocity:Destroy()
            Humanoid:SetStateEnabled(Enum.HumanoidStateType.Seated, true)
            Humanoid.PlatformStand = false
            v1057.CFrame = CFrame5
            CurrentCamera.CameraSubject = Humanoid
            for _, descendant in pairs(Character:GetDescendants()) do
                if descendant:IsA("BasePart") then
                    descendant.Velocity = Vector3.zero
                    descendant.RotVelocity = Vector3.zero
                end
            end
            Humanoid:UnequipTools()
            ReplicatedStorage.RE:FindFirstChild("1Too1l"):InvokeServer("PickingTools", "Couch")
        end)

        while u1056 do
            task.wait()
        end
    end

    UserInputService.TouchTap:Connect(function(p30, p31)
        if not p31 then
            p31 = not u346
        end

        if p31 then
            return
        end

        local v1066 = p30[1]
        local v1067 = CurrentCamera:ScreenPointToRay(v1066.X, v1066.Y)
        local raycastResult = workspace:Raycast(v1067.Origin, v1067.Direction * 1000)

        if raycastResult and raycastResult.Instance then
            local player = Players:GetPlayerFromCharacter(raycastResult.Instance:FindFirstAncestorOfClass("Model"))

            if player and player ~= LocalPlayer then
                v349(player)
                task.delay(2, function()
                end)
            end
        end
    end)
end
})
v11:AddButton({
	Name = "اضغط علي الاعب وانت ماسك الاداه فلنق كره (اداه)",
	Callback = function()
    local Players = game:GetService("Players")

    game:GetService("ReplicatedStorage")

    local Workspace = game:GetService("Workspace")
    local UserInputService = game:GetService("UserInputService")
    local CurrentCamera = Workspace.CurrentCamera
    local LocalPlayer = Players.LocalPlayer
    local s28 = "Click Fling Ball"
    local u356 = false
    local Backpack = LocalPlayer:WaitForChild("Backpack")

    if not Backpack:FindFirstChild(s28) then
        local Tool = Instance.new("Tool")

        Tool.Name = s28
        Tool.RequiresHandle = false
        Tool.CanBeDropped = false
        Tool.Equipped:Connect(function()
            u356 = true
        end)
        Tool.Unequipped:Connect(function()
            u356 = false
        end)
        Tool.Parent = Backpack
    end

    local function v359(p32)
        local Players2 = game:GetService("Players")
        local LocalPlayer2 = Players2.LocalPlayer
        local v1073 = LocalPlayer2.Character or LocalPlayer2.CharacterAdded:Wait()
        local Humanoid = v1073:WaitForChild("Humanoid")

        v1073:WaitForChild("HumanoidRootPart")

        local Backpack2 = LocalPlayer2:WaitForChild("Backpack")
        local v1076 = workspace.WorkspaceCom:WaitForChild("001_SoccerBalls"):FindFirstChild("Soccer" .. LocalPlayer2.Name) or (function()
            if not Backpack2:FindFirstChild("SoccerBall") and not v1073:FindFirstChild("SoccerBall") then
                game:GetService("ReplicatedStorage").RE:FindFirstChild("1Too1l"):InvokeServer("PickingTools", "SoccerBall")
            end

            if not Backpack2:FindFirstChild("SoccerBall") then
                v1073:FindFirstChild("SoccerBall")
            end

            repeat
                task.wait()
            until Backpack2:FindFirstChild("SoccerBall") or v1073:FindFirstChild("SoccerBall")

            local SoccerBall = Backpack2:FindFirstChild("SoccerBall")

            if SoccerBall then
                SoccerBall.Parent = v1073
            end;

            (nil):FindFirstChild("Soccer" .. LocalPlayer2.Name)

            repeat
                task.wait()
            until (nil):FindFirstChild("Soccer" .. LocalPlayer2.Name)

            return (nil):FindFirstChild("Soccer" .. LocalPlayer2.Name)
        end)()

        v1076.CanCollide = false
        v1076.Massless = true
        v1076.CustomPhysicalProperties = PhysicalProperties.new(0.0001, 0, 0)

        if p32 ~= LocalPlayer2 then
            local Character = p32.Character

            if Character and (Character:FindFirstChild("HumanoidRootPart") and Character:FindFirstChild("Humanoid")) then
                local HumanoidRootPart = Character.HumanoidRootPart
                local Humanoid7 = Character.Humanoid

                if v1076:FindFirstChildWhichIsA("BodyVelocity") then
                    v1076:FindFirstChildWhichIsA("BodyVelocity"):Destroy()
                end

                local BodyVelocity = Instance.new("BodyVelocity")

                BodyVelocity.Name = "FlingPower"
                BodyVelocity.Velocity = Vector3.new(900000000, 900000000, 900000000)
                BodyVelocity.MaxForce = Vector3.new(1e999, 1e999, 1e999)
                BodyVelocity.P = 1e999
                BodyVelocity.Parent = v1076
                workspace.CurrentCamera.CameraSubject = Humanoid7

                if not (HumanoidRootPart.Velocity.Magnitude > 1000) and not (Humanoid7.Health <= 0) and Character:IsDescendantOf(workspace) then
                    if Players2 == p32.Parent then
                    end
                end

                repeat
                    if HumanoidRootPart.Velocity.Magnitude > 0 then
                        local v1081 = HumanoidRootPart.Position + HumanoidRootPart.Velocity / 1.5

                        v1076.CFrame = CFrame.new(v1081)

                        local s29 = "Orientation"
                        local vector3 = Vector3.new(45, 60, 30)

                        v1076[s29] = v1076[s29] + vector3
                    else
                        for _, child in pairs(Character:GetChildren()) do
                            if child:IsA("BasePart") and (child.CanCollide and not child.Anchored) then
                                v1076.CFrame = child.CFrame
                                task.wait(0.00016666666666667)
                            end
                        end
                    end

                    task.wait(0.00016666666666667)

                    local v1086 = HumanoidRootPart.Velocity.Magnitude > 1000

                    if not v1086 then
                        v1086 = Humanoid7.Health <= 0

                        if not v1086 then
                            v1086 = not Character:IsDescendantOf(workspace) or Players2 ~= p32.Parent
                        end
                    end
                until v1086

                workspace.CurrentCamera.CameraSubject = Humanoid
            end
        end
    end

    UserInputService.TouchTap:Connect(function(p33, p34)
        if not u356 or p34 then
            return
        end

        local v1089 = p33[1]
        local v1090 = CurrentCamera:ScreenPointToRay(v1089.X, v1089.Y)
        local raycastResult = Workspace:Raycast(v1090.Origin, v1090.Direction * 1000)

        if raycastResult and raycastResult.Instance then
            local Model = raycastResult.Instance:FindFirstAncestorOfClass("Model")
            local player = Players:GetPlayerFromCharacter(Model)

            if player and player ~= LocalPlayer then
                v359(player)
            end
        end
    end)
end
})
v11:AddButton({
	Name = "اضغط علي الاعب التبيه يموت وانت  ماسك الاداه لا تنسي (اداه)",
	Callback = function()
    local Players = game:GetService("Players")
    local ReplicatedStorage = game:GetService("ReplicatedStorage")
    local RunService = game:GetService("RunService")
    local Workspace = game:GetService("Workspace")
    local UserInputService = game:GetService("UserInputService")
    local LocalPlayer = Players.LocalPlayer
    local CurrentCamera = Workspace.CurrentCamera
    local u367 = false
    local u368
    local u369
    local u370
    local Backpack = LocalPlayer:WaitForChild("Backpack")
    if not Backpack:FindFirstChild("Click Kill Couch") then
        local Tool = Instance.new("Tool")

        Tool.Name = "Click Kill Couch"
        Tool.RequiresHandle = false
        Tool.CanBeDropped = false
        Tool.Equipped:Connect(function()
            u367 = true
        end)
        Tool.Unequipped:Connect(function()
            u367 = false
            u368 = nil
            limparSofa()
        end)
        Tool.Parent = Backpack
    end
    function limparSofa()
        if u369 then
            u369:Destroy()
            u369 = nil
        end

        if getgenv().AntiSit then
            getgenv().AntiSit:Set(false)
        end

        local v1094 = LocalPlayer.Character and LocalPlayer.Character:FindFirstChildOfClass("Humanoid")

        if v1094 then
            v1094:SetStateEnabled(Enum.HumanoidStateType.Physics, true)
            v1094:ChangeState(Enum.HumanoidStateType.GettingUp)
        end

        if u370 and nil then
            (nil).CFrame = u370
            u370 = nil
        end
    end
    function pegarSofa()
        local Character = LocalPlayer.Character

        if not Character then
            return
        end

        local Backpack3 = LocalPlayer.Backpack

        if not Backpack3:FindFirstChild("Couch") and not Character:FindFirstChild("Couch") then
            local v1097 = ReplicatedStorage.RE["1Too1l"]
            local t29 = { unpack({
					"PickingTools",
					"Couch"
				}) }

            v1097:InvokeServer(v2(t29))
            task.wait(0.1)
        end

        local v1099 = Backpack3:FindFirstChild("Couch") or Character:FindFirstChild("Couch")

        if v1099 then
            v1099.Parent = Character
        end
    end
    function posAleatoriaAbaixo(p35)
        local HumanoidRootPart = p35:FindFirstChild("HumanoidRootPart")

        if not HumanoidRootPart then
            return Vector3.new()
        end

        local vector3 = Vector3.new(math.random(-2, 2), -5.1, math.random(-2, 2))

        return HumanoidRootPart.Position + vector3
    end
    function tpAbaixo(p36)
        if not p36 or (not p36.Character or not p36.Character:FindFirstChild("HumanoidRootPart")) then
            return
        end

        local Character = LocalPlayer.Character
        local v1105 = Character and Character:FindFirstChild("HumanoidRootPart")
        local v1106 = Character and Character:FindFirstChildOfClass("Humanoid")

        if not v1105 or not v1106 then
            return
        end

        v1106:SetStateEnabled(Enum.HumanoidStateType.Physics, false)

        if not u369 then
            u369 = Instance.new("Part")
            u369.Size = Vector3.new(10, 1, 10)
            u369.Anchored = true
            u369.CanCollide = true
            u369.Transparency = 0.5
            u369.Parent = Workspace
        end

        local v1107 = posAleatoriaAbaixo(p36.Character)

        u369.Position = v1107
        v1105.CFrame = CFrame.new(v1107)
        v1106:SetStateEnabled(Enum.HumanoidStateType.Physics, true)
    end
    function arremessarComSofa(p37)
        if not p37 then
            return
        end

        u368 = p37.Name

        local Character = LocalPlayer.Character

        if not Character then
            return
        end

        u370 = Character:FindFirstChild("HumanoidRootPart") and Character.HumanoidRootPart.CFrame
        Character:FindFirstChild("HumanoidRootPart")
        pegarSofa()
        RunService.Heartbeat:Connect(function()
            local v1450 = Players:FindFirstChild(u368)

            if not v1450 or (not v1450.Character or not v1450.Character:FindFirstChild("Humanoid")) then
                limparSofa()

                return
            end

            if getgenv().AntiSit then
                getgenv().AntiSit:Set(true)
            end

            tpAbaixo(v1450)
        end)
        task.spawn(function()
            local v1451 = Players:FindFirstChild(u368)

            repeat
                if not (v1451 and (v1451.Character and v1451.Character:FindFirstChild("Humanoid"))) then
                    return
                end

                task.wait(0.05)
            until v1451.Character.Humanoid.SeatPart

            local cFrame = CFrame.new(265.46, -450.83, -59.93)

            v1451.Character.HumanoidRootPart.CFrame = cFrame
            LocalPlayer.Character.HumanoidRootPart.CFrame = cFrame
            task.wait(0.4)
            limparSofa()
            task.wait(0.2)

            if u370 then
                LocalPlayer.Character.HumanoidRootPart.CFrame = u370

                return
            end
        end)
    end
    UserInputService.TouchTap:Connect(function(p38, p39)
        if not u367 or p39 then
            return
        end

        local v1112 = p38[1]
        local v1113 = CurrentCamera:ScreenPointToRay(v1112.X, v1112.Y)
        local raycastResult = Workspace:Raycast(v1113.Origin, v1113.Direction * 1000)

        if raycastResult and raycastResult.Instance then
            local Model = raycastResult.Instance:FindFirstAncestorOfClass("Model")
            local player = Players:GetPlayerFromCharacter(Model)

            if player and player ~= LocalPlayer then
                arremessarComSofa(player)
            end
        end
    end)
end
})
v11:AddSection({
	Name = "قتل كل الفي سرفر بجميع القتالات الفوق"
})
v11:AddButton({
	Name = "قتل الكل بل باص",
	Callback = function()
    local Players = game:GetService("Players")
    local Workspace = game:GetService("Workspace")
    local RunService = game:GetService("RunService")
    local ReplicatedStorage = game:GetService("ReplicatedStorage")
    local vector3 = Vector3.new(145.51, -374.09, 21.58)

    local function v378(p40, p41)
        while true do
            if p40 then
                local p40_2 = Players:FindFirstChild(p40)

                if p40_2 and (p40_2.Character and p40_2.Character:FindFirstChild("HumanoidRootPart")) then
                    local Humanoid = p40_2.Character:FindFirstChildOfClass("Humanoid")

                    if Humanoid and Humanoid.Sit then
                        local Vehicles = Workspace:FindFirstChild("Vehicles")
                        local v1123 = if not Vehicles then nil else Vehicles:FindFirstChild(Players.LocalPlayer.Name .. "Car")

                        if v1123 then
                            v1123:SetPrimaryPartCFrame(CFrame.new(vector3))
                            task.wait(0.2)

                            local function v1124()
                                local v1453 = Players.LocalPlayer.Character and Players.LocalPlayer.Character:FindFirstChildWhichIsA("Humanoid")

                                if v1453 then
                                    v1453:ChangeState(Enum.HumanoidStateType.Jumping)
                                end
                            end

                            v1124()
                            task.wait(0.4)
                            v1124()
                            task.wait(0.5)
                        end

                        if p41 then
                            p41()
                        end

                        return
                    end

                    local HumanoidRootPart = p40_2.Character.HumanoidRootPart
                    local v1126 = tick() * 35
                    local _ = math.sin(v1126) * 10
                    local v1128 = math.cos(v1126) * 20
                    local Vehicles = Workspace:FindFirstChild("Vehicles")
                    local v1130 = if not Vehicles then nil else Vehicles:FindFirstChild(Players.LocalPlayer.Name .. "Car")

                    if v1130 then
                        v1130:SetPrimaryPartCFrame(HumanoidRootPart.CFrame * CFrame.new(0, 0, v1128))
                    end
                end
            end

            RunService.RenderStepped:Wait()
        end
    end
    local function v379(p42, p43)
        local LocalPlayer = Players.LocalPlayer
        local v1134 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()
        local HumanoidRootPart = v1134:WaitForChild("HumanoidRootPart")
        local _ = HumanoidRootPart.CFrame
        local Vehicles = Workspace:FindFirstChild("Vehicles")
        local v1138 = if not Vehicles then nil else Vehicles:FindFirstChild(Players.LocalPlayer.Name .. "Car")

        if not v1138 then
            HumanoidRootPart.CFrame = CFrame.new(1118.81, 75.998, -1138.61)
            task.wait(0.5)

            local RE = ReplicatedStorage:FindFirstChild("RE")

            if RE and RE:FindFirstChild("1Ca1r") then
                RE["1Ca1r"]:FireServer("PickingCar", "SchoolBus")
            end

            task.wait(1)

            local Vehicles2 = Workspace:FindFirstChild("Vehicles")

            v1138 = if not Vehicles2 then nil else Vehicles2:FindFirstChild(Players.LocalPlayer.Name .. "Car")
        end

        if v1138 then
            local v1141 = v1138:FindFirstChild("Body") and v1138.Body:FindFirstChild("VehicleSeat")

            if v1141 and (v1134:FindFirstChildOfClass("Humanoid") and not v1134.Humanoid.Sit) then
                if not v1134.Humanoid.Sit then
                    local _ = v1138.Parent
                end

                repeat
                    HumanoidRootPart.CFrame = v1141.CFrame * CFrame.new(0, 2, 0)
                    task.wait()
                until v1134.Humanoid.Sit or not v1138.Parent
            end
        end

        spawn(function()
            v378(p42, p43)
        end)
    end
    local function u380(p44)
        if #p44 == 0 then
            return
        end

        local v1144 = table.remove(p44, 1)

        v379(v1144.Name, function()
            task.wait(0.5)
            u380(p44)
        end)
    end

    u380(Players:GetPlayers())
end
})
v11:AddButton({
	Name = "باند بيت للكل",
	Callback = function()
    local ReplicatedStorage = game:GetService("ReplicatedStorage")
    local Players = game:GetService("Players")
    local Workspace = game:GetService("Workspace")
    local GetPlayers = Players.GetPlayers
    local u384 = Workspace
    for _, v in pairs(GetPlayers(Players)) do
        if v ~= Players.LocalPlayer then
            (function(p45)
                local LocalPlayer = game.Players.LocalPlayer
                local _ = LocalPlayer.Backpack
                local Character = LocalPlayer.Character
                local Humanoid = Character:FindFirstChildOfClass("Humanoid")
                local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")
                local v1151 = game.Workspace:FindFirstChild("001_Lots")
                local _ = HumanoidRootPart.CFrame
                local n12 = 0
                local Vehicles = u384.Vehicles

                function Check()
                    local v1454 = LocalPlayer

                    if v1454 then
                        v1454 = Character and (Humanoid and (HumanoidRootPart and Vehicles))
                    end

                    if v1454 then
                        return true
                    end

                    return false
                end

                if Check() then
                    if not v1151:FindFirstChild(LocalPlayer.Name .. "House") then
                        local v1155
                        local GetChildren = v1151.GetChildren
                        for _, v5 in pairs(GetChildren(v1151)) do
                            if v5.Name == "For Sale" then
                                local GetDescendants = v5.GetDescendants

                                for _, v6 in pairs(GetDescendants(v5)) do
                                    if v6:IsA("NumberValue") and (v6.Name == "Number" and (v6.Value < 25 and v6.Value > 10)) then
                                        v1155 = v5

                                        break
                                    end
                                end
                            end
                        end
                        local BuyHouse = v1155:FindFirstChild("BuyHouse")
                        local _ = BuyHouse.Position
                        if BuyHouse and BuyHouse:IsA("BasePart") then
                            HumanoidRootPart.CFrame = BuyHouse.CFrame + Vector3.new(0, -6, 0)
                            task.wait(0.5)

                            local ClickDetector = BuyHouse:FindFirstChild("ClickDetector")

                            if ClickDetector then
                                fireclickdetector(ClickDetector)
                            end
                        end
                    end

                    task.wait(0.5)

                    local v1165 = v1151:FindFirstChild(LocalPlayer.Name .. "House")

                    if v1165 then
                        local wait2 = task.wait
                        local GetDescendants = v1165.GetDescendants
                        wait2(0.5)
                        local v1168
                        for _, v7 in pairs(GetDescendants(v1165)) do
                            if v7.Name == "Number" and v7:IsA("NumberValue") then
                                v1168 = v7
                            end
                        end
                        task.wait(0.5)
                        game:GetService("ReplicatedStorage").RE:FindFirstChild("1Gettin1gHous1e"):FireServer("PickingCustomHouse", "049_House", v1168.Value)
                    end

                    task.wait(0.5)

                    if not Vehicles:FindFirstChild(LocalPlayer.Name .. "Car") and Check() then
                        HumanoidRootPart.CFrame = CFrame.new(1118.81, 75.998, -1138.61)
                        task.wait(0.5)
                        game:GetService("ReplicatedStorage").RE:FindFirstChild("1Ca1r"):FireServer("PickingCar", "SchoolBus")
                        task.wait(0.5)

                        local v1171 = Vehicles:FindFirstChild(LocalPlayer.Name .. "Car")

                        task.wait(0.5)

                        local v1172 = v1171:FindFirstChild("Body") and v1171.Body:FindFirstChild("VehicleSeat")

                        if v1172 then
                            local _ = Humanoid.Sit

                            repeat
                                task.wait()
                                HumanoidRootPart.CFrame = v1172.CFrame * CFrame.new(0, math.random(-1, 1), 0)
                            until Humanoid.Sit
                        end
                    end

                    task.wait(0.5)

                    local v1174 = Vehicles:FindFirstChild(LocalPlayer.Name .. "Car")

                    if v1174 then
                        if not Humanoid.Sit then
                            local v1175 = v1174:FindFirstChild("Body") and v1174.Body:FindFirstChild("VehicleSeat")

                            if v1175 then
                                local _ = Humanoid.Sit

                                repeat
                                    task.wait()
                                    HumanoidRootPart.CFrame = v1175.CFrame * CFrame.new(0, math.random(-1, 1), 0)
                                until Humanoid.Sit
                            end
                        end

                        local Character9 = p45.Character
                        local Humanoid8 = Character9:FindFirstChildOfClass("Humanoid")
                        local HumanoidRootPart4 = Character9:FindFirstChild("HumanoidRootPart")

                        if Character9 and (Humanoid8 and HumanoidRootPart4) and not Humanoid8.Sit then
                            while not Humanoid8.Sit do
                                task.wait()

                                local function v1180(p46, p47, p48)
                                    v1174:SetPrimaryPartCFrame(CFrame.new(p46.Position) * p47 * p48)
                                end

                                n12 += 100
                                v1180(HumanoidRootPart4, CFrame.new(0, 1.5, 0) + Humanoid8.MoveDirection * HumanoidRootPart4.Velocity.Magnitude / 1.1, CFrame.Angles(math.rad(n12), 0, 0))
                                v1180(HumanoidRootPart4, CFrame.new(0, -1.5, 0) + Humanoid8.MoveDirection * HumanoidRootPart4.Velocity.Magnitude / 1.1, CFrame.Angles(math.rad(n12), 0, 0))
                                v1180(HumanoidRootPart4, CFrame.new(2.25, 1.5, -2.25) + Humanoid8.MoveDirection * HumanoidRootPart4.Velocity.Magnitude / 1.1, CFrame.Angles(math.rad(n12), 0, 0))
                                v1180(HumanoidRootPart4, CFrame.new(-2.25, -1.5, 2.25) + Humanoid8.MoveDirection * HumanoidRootPart4.Velocity.Magnitude / 1.1, CFrame.Angles(math.rad(n12), 0, 0))
                                v1180(HumanoidRootPart4, CFrame.new(0, 1.5, 0) + Humanoid8.MoveDirection * HumanoidRootPart4.Velocity.Magnitude / 1.1, CFrame.Angles(math.rad(n12), 0, 0))
                                v1180(HumanoidRootPart4, CFrame.new(0, -1.5, 0) + Humanoid8.MoveDirection * HumanoidRootPart4.Velocity.Magnitude / 1.1, CFrame.Angles(math.rad(n12), 0, 0))
                            end

                            task.wait(0.2)

                            local v1181 = v1151:FindFirstChild(LocalPlayer.Name .. "House")

                            v1174:SetPrimaryPartCFrame(CFrame.new(v1181.HouseSpawnPosition.Position))
                            task.wait(0.2)

                            local region3 = Region3.new(game.Players.LocalPlayer.Character.HumanoidRootPart.Position - Vector3.new(30, 30, 30), game.Players.LocalPlayer.Character.HumanoidRootPart.Position + Vector3.new(30, 30, 30))
                            local PartsInRegion3 = workspace:FindPartsInRegion3(region3, game.Players.LocalPlayer.Character.HumanoidRootPart, 1e999)

                            for _, v9 in pairs(PartsInRegion3) do
                                if v9.Name == "HumanoidRootPart" then
                                    local v9ParentName = game:GetService("Players"):FindFirstChild(v9.Parent.Name)
                                    local v9Parent = v9.Parent
                                    local t30 = {
											[1] = "BanPlayerFromHouse",
											[2] = v9ParentName,
											[3] = v9Parent
										}
                                    local v1189 = game:GetService("ReplicatedStorage").RE:FindFirstChild("1Playe1rTrigge1rEven1t")
                                    local t31 = { unpack(t30) }

                                    v1189:FireServer(v2(t31))
                                end
                            end
                        end
                    end
                end

                local t32 = {
						[1] = "DeleteAllVehicles"
					}
                local v1192 = ReplicatedStorage:WaitForChild("RE"):WaitForChild("1Ca1r")
                local t33 = { unpack(t32) }

                v1192:FireServer(v2(t33))
            end)(v)
            task.wait(2)
        end
    end
end
})
v11:AddButton({
	Name = "فلنق مركب للكل",
	Callback = function()
    local LocalPlayer = game.Players.LocalPlayer
    local Character = LocalPlayer.Character
    local Humanoid = Character:FindFirstChildOfClass("Humanoid")
    local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")
    local Vehicles = game.Workspace:FindFirstChild("Vehicles")
    local HumanoidRootPartCFrame = HumanoidRootPart.CFrame
    local n13 = 0

    if not Vehicles:FindFirstChild(LocalPlayer.Name .. "Car") and HumanoidRootPart then
        HumanoidRootPart.CFrame = CFrame.new(1754, -2, 58)
        task.wait(0.5)
        game:GetService("ReplicatedStorage").RE:FindFirstChild("1Ca1r"):FireServer("PickingBoat", "MilitaryBoatFree")
        task.wait(0.5)

        local v395 = Vehicles:FindFirstChild(LocalPlayer.Name .. "Car")

        task.wait(0.5)

        local v396 = v395:FindFirstChild("Body") and v395.Body:FindFirstChild("VehicleSeat")

        if v396 then
            local _ = Humanoid.Sit

            repeat
                task.wait()
                HumanoidRootPart.CFrame = v396.CFrame * CFrame.new(0, math.random(-1, 1), 0)
            until Humanoid.Sit
        end
    end

    task.wait(0.5)

    local u398 = Vehicles:FindFirstChild(LocalPlayer.Name .. "Car")

    if u398 and not Humanoid.Sit then
        local v399 = u398:FindFirstChild("Body") and u398.Body:FindFirstChild("VehicleSeat")

        if v399 then
            local _ = Humanoid.Sit

            repeat
                task.wait()
                HumanoidRootPart.CFrame = v399.CFrame * CFrame.new(0, math.random(-1, 1), 0)
            until Humanoid.Sit
        end
    end

    local BodyGyro = Instance.new("BodyGyro")

    BodyGyro.Parent = u398.PrimaryPart
    BodyGyro.MaxTorque = Vector3.new(10000000, 10000000, 10000000)
    BodyGyro.P = 10000000
    BodyGyro.CFrame = u398.PrimaryPart.CFrame * CFrame.Angles(0, 1.5707963267948966, 0)

    for _, player in pairs(game.Players:GetPlayers()) do
        if player ~= LocalPlayer then
            local Character10 = player.Character
            local v405 = Character10 and Character10:FindFirstChildOfClass("Humanoid")
            local v406 = Character10 and Character10:FindFirstChild("HumanoidRootPart")

            if Character10 and (v405 and v406) then
                (function(_, p50, _)
                    n13 = 0

                    local v1197 = tick() + 1

                    while v1197 > tick() do
                        n13 += 100
                        task.wait()

                        local function v1198(p52, p53, p54)
                            u398:SetPrimaryPartCFrame(CFrame.new(p52.Position) * p53 * p54)
                        end

                        v1198(p50, CFrame.new(0, 3, 0), CFrame.Angles(math.rad(n13), 0, 0))
                        v1198(p50, CFrame.new(0, -1.5, 2), CFrame.Angles(math.rad(n13), 0, 0))
                        v1198(p50, CFrame.new(2, 1.5, 2.25), CFrame.Angles(0.8726646259971648, 0, 0))
                        v1198(p50, CFrame.new(-2.25, -1.5, 2.25), CFrame.Angles(0.5235987755982988, 0, 0))
                        v1198(p50, CFrame.new(0, 1.5, 0), CFrame.Angles(math.rad(n13), 0, 0))
                        v1198(p50, CFrame.new(0, -1.5, 0), CFrame.Angles(math.rad(n13), 0, 0))
                    end
                end)(Character10, v406, v405)
            end
        end
    end

    task.wait(0.5)
    u398:SetPrimaryPartCFrame(CFrame.new(0, 0, 0))
    task.wait(0.5)
    Humanoid.Sit = false
    task.wait(0.5)
    HumanoidRootPart.CFrame = HumanoidRootPartCFrame
    BodyGyro:Destroy()
end
})
v11:AddButton({
	Name = "فلنق تلقايي للكل ",
	Callback = function()
    local Players = game:GetService("Players")
    local ReplicatedStorage = game:GetService("ReplicatedStorage")
    local LocalPlayer = Players.LocalPlayer
    local CurrentCamera = workspace.CurrentCamera
    local GetPlayers = Players.GetPlayers

    for _, v in ipairs(GetPlayers(Players)) do
        (function(p55)
            if not p55 or (not p55.Character or p55 == LocalPlayer) then
                return
            end

            local u1200 = true
            local v1201 = LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
            local v1202 = p55.Character and p55.Character:FindFirstChild("HumanoidRootPart")

            if not v1201 or not v1202 then
                return
            end

            local Character = LocalPlayer.Character
            local Humanoid = Character:FindFirstChildOfClass("Humanoid")
            local CFrame6 = v1201.CFrame

            ReplicatedStorage:WaitForChild("RE"):WaitForChild("1Clea1rTool1s"):FireServer("ClearAllTools")
            task.wait(0.2)
            ReplicatedStorage.RE:FindFirstChild("1Too1l"):InvokeServer("PickingTools", "Couch")
            task.wait(0.3)

            local Couch = LocalPlayer.Backpack:FindFirstChild("Couch")

            if Couch then
                Couch.Parent = Character
            end

            task.wait(0.1)
            game:GetService("VirtualInputManager"):SendKeyEvent(true, Enum.KeyCode.F, false, game)
            task.wait(0.25)
            workspace.FallenPartsDestroyHeight = (0/0)

            local BodyVelocity = Instance.new("BodyVelocity")

            BodyVelocity.Name = "FlingForce"
            BodyVelocity.Velocity = Vector3.new(900000000, 900000000, 900000000)
            BodyVelocity.MaxForce = Vector3.new(1e999, 1e999, 1e999)
            BodyVelocity.Parent = v1201
            Humanoid:SetStateEnabled(Enum.HumanoidStateType.Seated, false)
            Humanoid.PlatformStand = false
            CurrentCamera.CameraSubject = p55.Character:FindFirstChild("Head") or (v1202 or Humanoid)
            task.spawn(function()
                local v1461
                local t34 = { v1201 }
                while true do
                    local v1463 = u1200

                    if v1463 then
                        v1463 = p55 and (p55.Character and p55.Character:FindFirstChildOfClass("Humanoid"))
                    end

                    if not v1463 or p55.Character:FindFirstChildOfClass("Humanoid").Sit then
                        break
                    end

                    local _ipairs = ipairs

                    v1461 += 50

                    for _, _ in _ipairs(t34) do
                        local HumanoidRootPart = p55.Character.HumanoidRootPart
                        local v1468 = HumanoidRootPart.Position + HumanoidRootPart.Velocity / 1.5

                        v1201.CFrame = CFrame.new(v1468) * CFrame.Angles(math.rad(v1461), 0, 0)
                    end

                    v1201.Velocity = Vector3.new(900000000, 900000000, 900000000)
                    v1201.RotVelocity = Vector3.new(900000000, 900000000, 900000000)
                    task.wait()
                end
                u1200 = false
                BodyVelocity:Destroy()
                Humanoid:SetStateEnabled(Enum.HumanoidStateType.Seated, true)
                Humanoid.PlatformStand = false
                v1201.CFrame = CFrame6
                CurrentCamera.CameraSubject = Humanoid
                for _, descendant in pairs(Character:GetDescendants()) do
                    if descendant:IsA("BasePart") then
                        descendant.Velocity = Vector3.zero
                        descendant.RotVelocity = Vector3.zero
                    end
                end
                Humanoid:UnequipTools()
                ReplicatedStorage.RE:FindFirstChild("1Too1l"):InvokeServer("PickingTools", "Couch")
            end)

            while u1200 do
                task.wait()
            end
        end)(v)
    end
end
})
v11:AddButton({
	Name = "برانجج  للكل [اداه]",
	Callback = function()
    local t35 = {
			[1] = "ClearAllTools"
		}
    game:GetService("ReplicatedStorage"):WaitForChild("RE"):WaitForChild("1Clea1rTool1s"):FireServer(unpack(t35))
    wait(0.2)
    toolselcted = "Couch"
    dupeamot = 25
    picktoolremote = game:GetService("ReplicatedStorage").RE:FindFirstChild("1Too1l")
    cleartoolremote = game:GetService("ReplicatedStorage").RE:FindFirstChild("1Clea1rTool1s")
    game:GetService("StarterGui"):SetCore("SendNotification", {
			Title = "Dupando",
			Text = "Nao Clique em nada quando tiver dupando . ",
			Button1 = " Eu entendi",
			Duration = 5
		})
    game:GetService("StarterGui"):SetCore("SendNotification", {
			Title = "Dupe Script",
			Text = "Because It will break the script and you will need to rejoin.",
			Button1 = "Eu entendi",
			Duration = 5
		})
    duping = true
    oldcf = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
    if game.Players.LocalPlayer.Character.Humanoid.Sit == true then
        task.wait()
        game.Players.LocalPlayer.Character.Humanoid.Sit = false
    end
    wait(0.1)
    if game:GetService("Workspace"):FindFirstChild("Camera") then
        game:GetService("Workspace"):FindFirstChild("Camera"):Destroy()
    end
    for _ = 1, 2 do
        task.wait()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(999999999.414, -490, 999999999.414, 0.974360406, -0.175734088, 0.14049761, -0.133441404, 0.0514053069, 0.989722729, -0.181150302, -0.983094692, 0.0266370922)
    end
    task.wait(0.2)
    game.Players.LocalPlayer.Character.HumanoidRootPart.Anchored = true
    wait(0.5)
    for v418, v419 in pairs(game:GetService("Players").LocalPlayer.Character:GetChildren()) do

        if v419.Name == toolselcted == false and v419:IsA("Tool") then
            v419.Parent = game.Players.LocalPlayer.Backpack
        end
    end
    for _, child in pairs(game:GetService("Players").LocalPlayer.Backpack:GetChildren()) do
        if child:IsA("Tool") and child.Name == toolselcted == false then
            child:Destroy()
        end
    end
    for v424, v425 in pairs(game:GetService("Players").LocalPlayer.Character:GetChildren()) do

        if v425:IsA("Tool") and v425.name == toolselcted == false then
            v425:Destroy()
        end
    end
    for _, child in pairs(game:GetService("Players").LocalPlayer.Character:GetChildren()) do
        if child:IsA("Tool") then
            if child.Name == toolselcted then
                toollllfoun2 = true

                for _, descendant in pairs(child:GetDescendants()) do
                    if descendant.Name == "Handle" then
                        descendant.Name = "Hâ\194\129¥aâ\194\129¥nâ\194\129¥dâ\194\129¥lâ\194\129¥e"
                        child.Parent = game.Players.LocalPlayer.Backpack
                        child.Parent = game.Players.LocalPlayer.Character
                        tollllahhhh = child
                        task.wait()
                    end
                end
            else
                toollllfoun2 = false
            end
        end
    end
    for v432, v433 in pairs(game:GetService("Players").LocalPlayer.Backpack:GetChildren()) do

        if v433:IsA("Tool") then
            if v433.Name == toolselcted then
                local GetDescendants = v433.GetDescendants

                toollllfoun = true

                for _, v in pairs(GetDescendants(v433)) do
                    if v.Name == "Handle" then
                        v433.Parent = game.Players.LocalPlayer.Character
                        wait()
                        v.Name = "Hâ\194\129¥aâ\194\129¥nâ\194\129¥dâ\194\129¥lâ\194\129¥e"
                        v433.Parent = game.Players.LocalPlayer.Backpack
                        v433.Parent = game.Players.LocalPlayer.Character
                        toolllffel = v433
                    end
                end
            else
                toollllfoun = false
            end
        end
    end
    if toollllfoun == true then
        if game.Players.LocalPlayer.Character:FindFirstChild(toolllffel) == nil then
            toollllfoun = false
        end

        if game.Players.LocalPlayer.Character:FindFirstChild(toolllffel) ~= nil then
        end

        repeat
            wait()
        until game.Players.LocalPlayer.Character:FindFirstChild(toolllffel) == nil

        toollllfoun = false
    end
    if toollllfoun2 == true then
        if game.Players.LocalPlayer.Character:FindFirstChild(tollllahhhh) == nil then
            toollllfoun2 = false
        end

        if game.Players.LocalPlayer.Character:FindFirstChild(tollllahhhh) ~= nil then
        end

        repeat
            wait()
        until game.Players.LocalPlayer.Character:FindFirstChild(tollllahhhh) == nil

        toollllfoun2 = false
    end
    wait(0.1)
    for i = 1, dupeamot do
        local v438 = i

        if duping == false then
            game.Players.LocalPlayer.Character.HumanoidRootPart.Anchored = false

            return
        end

        if game:GetService("Workspace"):FindFirstChild("Camera") then
            game:GetService("Workspace"):FindFirstChild("Camera"):Destroy()
        end

        if v438 <= dupeamot then
            local StarterGui2 = game:GetService("StarterGui")
            local SetCore = StarterGui2.SetCore
            local v441 = "Se tem" .. " " .. v438 .. " " .. "Duped" .. " " .. toolselcted .. "!"

            SetCore(StarterGui2, "SendNotification", {
					Title = "Dupando vida",
					Text = v441,
					Duration = 0.5
				})
        elseif v438 == dupeamot or v438 >= dupeamot - 1 then
            local StarterGui3 = game:GetService("StarterGui")
            local SetCore = StarterGui3.SetCore
            local v444 = "Se tem" .. " " .. v438 .. " " .. "Duped" .. " " .. toolselcted .. "! Duping tools is done now, Please wait a little bit to respawn."

            SetCore(StarterGui3, "SendNotification", {
					Title = "Dupando",
					Text = v444,
					Duration = 4
				})
        end

        local t36 = {
				[1] = "PickingTools",
				[2] = toolselcted
			}
        local _picktoolremote = picktoolremote
        local t37 = { unpack(t36) }

        _picktoolremote:InvokeServer(v2(t37))
        game:GetService("Players").LocalPlayer.Backpack:WaitForChild(toolselcted).Parent = game.Players.LocalPlayer.Character

        if duping == false then
            game.Players.LocalPlayer.Character.HumanoidRootPart.Anchored = false

            return
        end

        wait()
        game:GetService("Players").LocalPlayer.Character[toolselcted]:FindFirstChild("Handle").Name = "Hâ\194\129¥aâ\194\129¥nâ\194\129¥dâ\194\129¥lâ\194\129¥e"
        game:GetService("Players").LocalPlayer.Character:FindFirstChild(toolselcted).Parent = game.Players.LocalPlayer.Backpack
        game:GetService("Players").LocalPlayer.Backpack:FindFirstChild(toolselcted).Parent = game.Players.LocalPlayer.Character

        if game:GetService("Players").LocalPlayer.Character:FindFirstChild(toolselcted) ~= nil then
        end

        repeat
            if game:GetService("Workspace"):FindFirstChild("Camera") then
                game:GetService("Workspace"):FindFirstChild("Camera"):Destroy()
            end

            task.wait()
        until game:GetService("Players").LocalPlayer.Character:FindFirstChild(toolselcted) == nil
    end
    game.Players.LocalPlayer.Character.HumanoidRootPart.Anchored = false
    if game.Players.LocalPlayer.Character:FindFirstChild("HumanoidRootPart") ~= nil then
    end
    repeat
        wait()
    until game.Players.LocalPlayer.Character:FindFirstChild("HumanoidRootPart") == nil
    game.Players.LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
    repeat
        wait()
    until game.Players.LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = oldcf
    wait()
    duping = false
    for k, player in pairs(game.Players:GetPlayers()) do
        if player.Name == game.Players.LocalPlayer.Name == false then
            ewoifjwoifjiwo = k
        end
    end
    for i = 1, ewoifjwoifjiwo do
        game.Players.LocalPlayer.Backpack.Couch.Name = "couch" .. i
    end
    wait()
    for v453, v454 in pairs(game.Players.LocalPlayer.Backpack:GetChildren()) do

        if v454.Name == "couch" .. v453 then
            v454.Handle.Name = "Handle "
        end
    end
    wait(0.2)
    local function v455(p56, p57)
        if p57 == nil == false then
            game.Players.LocalPlayer.Backpack["couch" .. p56]:FindFirstChild("Seat1").Disabled = true
            game.Players.LocalPlayer.Backpack["couch" .. p56]:FindFirstChild("Seat2").Disabled = true
            game.Players.LocalPlayer.Backpack["couch" .. p56].Parent = game.Players.LocalPlayer.Character
            tet = Instance.new("BodyVelocity", game.Players.LocalPlayer.Character["couch" .. p56]:FindFirstChild("Handle "))
            tet.MaxForce = Vector3.new(1e999, 1e999, 1e999)
            tet.P = 1250
            tet.Velocity = Vector3.new(0, 0, 0)
            tet.Name = "#mOVOOEPF$#@F$#GERE..>V<<<<EW<V<<W"

            if p57.Character.Humanoid.Sit ~= true then
            end

            repeat
                for _ = 1, 35 do
                    local t38 = {
							x = 0,
							y = 0,
							z = 0,
							x = p57.Character.HumanoidRootPart.Position.X,
							y = p57.Character.HumanoidRootPart.Position.Y,
							z = p57.Character.HumanoidRootPart.Position.Z
						}

                    t38.x = t38.x + p57.Character.HumanoidRootPart.Velocity.X / 2
                    t38.y = t38.y + p57.Character.HumanoidRootPart.Velocity.Y / 2
                    t38.z = t38.z + p57.Character.HumanoidRootPart.Velocity.Z / 2
                    game.Players.LocalPlayer.Character["couch" .. p56]:FindFirstChild("Seat1").CFrame = CFrame.new(Vector3.new(t38.x, t38.y, t38.z)) * CFrame.new(-2, 2, 0)
                    task.wait()
                end

                game.Players.LocalPlayer.Character["couch" .. p56].Parent = game.Players.LocalPlayer.Backpack
                wait()
                game.Players.LocalPlayer.Backpack["couch" .. p56]:FindFirstChild("Handle ").Name = "Handle"
                wait(0.2)
                game.Players.LocalPlayer.Backpack["couch" .. p56].Parent = game.Players.LocalPlayer.Character
                wait()
                game.Players.LocalPlayer.Character["couch" .. p56].Parent = game.Players.LocalPlayer.Backpack
                game.Players.LocalPlayer.Backpack["couch" .. p56].Handle.Name = "Handle "
                wait(0.2)
                game.Players.LocalPlayer.Backpack["couch" .. p56].Parent = game.Players.LocalPlayer.Character
                tet = Instance.new("BodyVelocity", game.Players.LocalPlayer.Character["couch" .. p56]:FindFirstChild("Seat1"))
                tet.MaxForce = Vector3.new(1e999, 1e999, 1e999)
                tet.P = 1250
                tet.Velocity = Vector3.new(0, 0, 0)
                tet.Name = "#mOVOOEPF$#@F$#GERE..>V<<<<EW<V<<W"
            until p57.Character.Humanoid.Sit == true

            wait()
            game.Players.LocalPlayer.Character["couch" .. p56]:FindFirstChild("Handle "):FindFirstChild("#mOVOOEPF$#@F$#GERE..>V<<<<EW<V<<W"):Destroy()
            game.Players.LocalPlayer.Character["couch" .. p56].Parent = game.Players.LocalPlayer.Backpack
            wait()
            game.Players.LocalPlayer.Backpack["couch" .. p56]:FindFirstChild("Handle ").Name = "Handle"
            wait(0.2)
            game.Players.LocalPlayer.Backpack["couch" .. p56].Parent = game.Players.LocalPlayer.Character
            wait()
            game.Players.LocalPlayer.Character["couch" .. p56].Parent = game.Players.LocalPlayer.Backpack
        end
    end
    for k, player in pairs(game.Players:GetPlayers()) do
        local v458 = k
        local v459 = player

        if v459.Name == game.Players.LocalPlayer.Name == false then
            spawn(function()
                v455(v458, v459)
            end)
        end
    end
end
})
v11:AddButton({
	Name = "قتل الكل اداه جديده [اداه]",
	Callback = function()
    local t39 = {
			[1] = "ClearAllTools"
		}
    local v461 = game:GetService("ReplicatedStorage"):WaitForChild("RE"):WaitForChild("1Clea1rTool1s")
    local t40 = { unpack(t39) }
    v461:FireServer(v2(t40))
    wait(0.2)
    local HumanoidRootPartPosition = game.Players.LocalPlayer.Character.HumanoidRootPart.Position
    local Part = Instance.new("Part")
    Part.Size = Vector3.new(5000, 10, 5000)
    Part.Position = Vector3.new(0, -500, 0)
    Part.Anchored = true
    Part.CanCollide = true
    Part.Parent = game.Workspace
    task.wait()
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(0, -500, 0)
    wait(2)
    toolselcted = "Couch"
    dupeamot = 25
    picktoolremote = game:GetService("ReplicatedStorage").RE:FindFirstChild("1Too1l")
    cleartoolremote = game:GetService("ReplicatedStorage").RE:FindFirstChild("1Clea1rTool1s")
    game:GetService("StarterGui"):SetCore("SendNotification", {
			Title = "Dupando",
			Text = "Nao clique em nada",
			Button1 = "Eu entendi",
			Duration = 5
		})
    game:GetService("StarterGui"):SetCore("SendNotification", {
			Title = "Dupando",
			Text = "Espere",
			Button1 = "Tendeu",
			Duration = 5
		})
    duping = true
    oldcf = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
    if game.Players.LocalPlayer.Character.Humanoid.Sit == true then
        task.wait()
        game.Players.LocalPlayer.Character.Humanoid.Sit = false
    end
    wait(0.1)
    if game:GetService("Workspace"):FindFirstChild("Camera") then
        game:GetService("Workspace"):FindFirstChild("Camera"):Destroy()
    end
    for _ = 1, 2 do
        task.wait()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(999999999.414, -490, 999999999.414, 0.974360406, -0.175734088, 0.14049761, -0.133441404, 0.0514053069, 0.989722729, -0.181150302, -0.983094692, 0.0266370922)
    end
    task.wait(0.2)
    game.Players.LocalPlayer.Character.HumanoidRootPart.Anchored = true
    wait(0.5)
    for v468, v469 in pairs(game:GetService("Players").LocalPlayer.Character:GetChildren()) do

        if v469.Name == toolselcted == false and v469:IsA("Tool") then
            v469.Parent = game.Players.LocalPlayer.Backpack
        end
    end
    for _, child in pairs(game:GetService("Players").LocalPlayer.Backpack:GetChildren()) do
        if child:IsA("Tool") and child.Name == toolselcted == false then
            child:Destroy()
        end
    end
    for v474, v475 in pairs(game:GetService("Players").LocalPlayer.Character:GetChildren()) do

        if v475:IsA("Tool") and v475.Name == toolselcted == false then
            v475:Destroy()
        end
    end
    for _, child in pairs(game:GetService("Players").LocalPlayer.Character:GetChildren()) do
        if child:IsA("Tool") then
            if child.Name == toolselcted then
                toollllfoun2 = true

                for _, descendant in pairs(child:GetDescendants()) do
                    if descendant.Name == "Handle" then
                        descendant.Name = "HÃ¢Â\194\129Â¥aÃ¢Â\194\129Â¥nÃ¢Â\194\129Â¥dÃ¢Â\194\129Â¥lÃ¢Â\194\129Â¥e"
                        child.Parent = game.Players.LocalPlayer.Backpack
                        child.Parent = game.Players.LocalPlayer.Character
                        tollllahhhh = child
                        task.wait()
                    end
                end
            else
                toollllfoun2 = false
            end
        end
    end
    for v482, v483 in pairs(game:GetService("Players").LocalPlayer.Backpack:GetChildren()) do

        if v483:IsA("Tool") then
            if v483.Name == toolselcted then
                local GetDescendants = v483.GetDescendants

                toollllfoun = true

                for _, v in pairs(GetDescendants(v483)) do
                    if v.Name == "Handle" then
                        v483.Parent = game.Players.LocalPlayer.Character
                        wait()
                        v.Name = "HÃ¢Â\194\129Â¥aÃ¢Â\194\129Â¥nÃ¢Â\194\129Â¥dÃ¢Â\194\129Â¥lÃ¢Â\194\129Â¥e"
                        v483.Parent = game.Players.LocalPlayer.Backpack
                        v483.Parent = game.Players.LocalPlayer.Character
                        toolllffel = v483
                    end
                end
            else
                toollllfoun = false
            end
        end
    end
    if toollllfoun == true then
        if game.Players.LocalPlayer.Character:FindFirstChild(toolllffel) == nil then
            toollllfoun = false
        end

        if game.Players.LocalPlayer.Character:FindFirstChild(toolllffel) ~= nil then
        end

        repeat
            wait()
        until game.Players.LocalPlayer.Character:FindFirstChild(toolllffel) == nil

        toollllfoun = false
    end
    if toollllfoun2 == true then
        if game.Players.LocalPlayer.Character:FindFirstChild(tollllahhhh) == nil then
            toollllfoun2 = false
        end

        if game.Players.LocalPlayer.Character:FindFirstChild(tollllahhhh) ~= nil then
        end

        repeat
            wait()
        until game.Players.LocalPlayer.Character:FindFirstChild(tollllahhhh) == nil

        toollllfoun2 = false
    end
    wait(0.1)
    for i = 1, dupeamot do
        local v488 = i

        if duping == false then
            game.Players.LocalPlayer.Character.HumanoidRootPart.Anchored = false

            return
        end

        if game:GetService("Workspace"):FindFirstChild("Camera") then
            game:GetService("Workspace"):FindFirstChild("Camera"):Destroy()
        end

        if v488 <= dupeamot then
            local StarterGui4 = game:GetService("StarterGui")
            local SetCore = StarterGui4.SetCore
            local v491 = "Agora c Tem" .. " " .. v488 .. " " .. "Duped" .. " " .. toolselcted .. "!"

            SetCore(StarterGui4, "SendNotification", {
					Title = "Dupe Script",
					Text = v491,
					Duration = 0.5
				})
        elseif v488 == dupeamot or v488 >= dupeamot - 1 then
            local StarterGui5 = game:GetService("StarterGui")
            local SetCore = StarterGui5.SetCore
            local v494 = "Agora c tem" .. " " .. v488 .. " " .. "Duped" .. " " .. toolselcted .. "! As tools Tao sendo dupada Clica em nada nao fiote"

            SetCore(StarterGui5, "SendNotification", {
					Title = "Dupe Script",
					Text = v494,
					Duration = 4
				})
        end

        local t41 = {
				[1] = "PickingTools",
				[2] = toolselcted
			}
        local _picktoolremote = picktoolremote
        local t42 = { unpack(t41) }

        _picktoolremote:InvokeServer(v2(t42))
        game:GetService("Players").LocalPlayer.Backpack:WaitForChild(toolselcted).Parent = game.Players.LocalPlayer.Character

        if duping == false then
            game.Players.LocalPlayer.Character.HumanoidRootPart.Anchored = false

            return
        end

        wait()
        game:GetService("Players").LocalPlayer.Character[toolselcted]:FindFirstChild("Handle").Name = "HÃ¢Â\194\129Â¥aÃ¢Â\194\129Â¥nÃ¢Â\194\129Â¥dÃ¢Â\194\129Â¥lÃ¢Â\194\129Â¥e"
        game:GetService("Players").LocalPlayer.Character:FindFirstChild(toolselcted).Parent = game.Players.LocalPlayer.Backpack
        game:GetService("Players").LocalPlayer.Backpack:FindFirstChild(toolselcted).Parent = game.Players.LocalPlayer.Character

        if game:GetService("Players").LocalPlayer.Character:FindFirstChild(toolselcted) ~= nil then
        end

        repeat
            if game:GetService("Workspace"):FindFirstChild("Camera") then
                game:GetService("Workspace"):FindFirstChild("Camera"):Destroy()
            end

            task.wait()
        until game:GetService("Players").LocalPlayer.Character:FindFirstChild(toolselcted) == nil
    end
    game.Players.LocalPlayer.Character.HumanoidRootPart.Anchored = false
    if game.Players.LocalPlayer.Character:FindFirstChild("HumanoidRootPart") ~= nil then
    end
    repeat
        wait()
    until game.Players.LocalPlayer.Character:FindFirstChild("HumanoidRootPart") == nil
    game.Players.LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
    repeat
        wait()
    until game.Players.LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = oldcf
    wait()
    duping = false
    for k, player in pairs(game.Players:GetPlayers()) do
        if player.Name == game.Players.LocalPlayer.Name == false then
            ewoifjwoifjiwo = k
        end
    end
    for i = 1, ewoifjwoifjiwo do
        game.Players.LocalPlayer.Backpack.Couch.Name = "Zyronis Couch" .. i
    end
    wait()
    for v503, v504 in pairs(game.Players.LocalPlayer.Backpack:GetChildren()) do

        if v504.Name == "Zyronis Couch" .. v503 then
            v504.Handle.Name = "Handle "
        end
    end
    wait(0.2)
    local function v505(p58, p59)
        if p59 == nil == false then
            game.Players.LocalPlayer.Backpack["Zyronis Couch" .. p58]:FindFirstChild("Seat1").Disabled = true
            game.Players.LocalPlayer.Backpack["Zyronis Couch" .. p58]:FindFirstChild("Seat2").Disabled = true
            game.Players.LocalPlayer.Backpack["Zyronis Couch" .. p58].Parent = game.Players.LocalPlayer.Character
            tet = Instance.new("BodyVelocity", game.Players.LocalPlayer.Character["Zyronis Couch" .. p58]:FindFirstChild("Handle "))
            tet.MaxForce = Vector3.new(1e999, 1e999, 1e999)
            tet.P = 1250
            tet.Velocity = Vector3.new(0, 0, 0)
            tet.Name = "#mOVOOEPF$#@F$#GERE..>V<<<<EW<V<<W"

            if p59.Character.Humanoid.Sit ~= true then
            end

            repeat
                for _ = 1, 35 do
                    local t43 = {
							x = 0,
							y = 0,
							z = 0,
							x = p59.Character.HumanoidRootPart.Position.X,
							y = p59.Character.HumanoidRootPart.Position.Y,
							z = p59.Character.HumanoidRootPart.Position.Z
						}

                    t43.x = t43.x + p59.Character.HumanoidRootPart.Velocity.X / 2
                    t43.y = t43.y + p59.Character.HumanoidRootPart.Velocity.Y / 2
                    t43.z = t43.z + p59.Character.HumanoidRootPart.Velocity.Z / 2
                    game.Players.LocalPlayer.Character["Zyronis Couch" .. p58]:FindFirstChild("Seat1").CFrame = CFrame.new(Vector3.new(t43.x, t43.y, t43.z)) * CFrame.new(-2, 2, 0)
                    task.wait()
                end

                game.Players.LocalPlayer.Character["Zyronis Couch" .. p58].Parent = game.Players.LocalPlayer.Backpack
                wait()
                game.Players.LocalPlayer.Backpack["Zyronis Couch" .. p58]:FindFirstChild("Handle ").Name = "Handle"
                wait(0.2)
                game.Players.LocalPlayer.Backpack["Zyronis Couch" .. p58].Parent = game.Players.LocalPlayer.Character
                wait()
                game.Players.LocalPlayer.Character["Zyronis Couch" .. p58].Parent = game.Players.LocalPlayer.Backpack
                game.Players.LocalPlayer.Backpack["Zyronis Couch" .. p58].Handle.Name = "Handle "
                wait(0.2)
                game.Players.LocalPlayer.Backpack["Zyronis Couch" .. p58].Parent = game.Players.LocalPlayer.Character
                tet = Instance.new("BodyVelocity", game.Players.LocalPlayer.Character["Zyronis Couch" .. p58]:FindFirstChild("Seat1"))
                tet.MaxForce = Vector3.new(1e999, 1e999, 1e999)
                tet.P = 1250
                tet.Velocity = Vector3.new(0, 0, 0)
                tet.Name = "#mOVOOEPF$#@F$#GERE..>V<<<<EW<V<<W"
            until p59.Character.Humanoid.Sit == true

            wait()
            game.Players.LocalPlayer.Character["Zyronis Couch" .. p58]:FindFirstChild("Handle "):FindFirstChild("#mOVOOEPF$#@F$#GERE..>V<<<<EW<V<<W"):Destroy()
            game.Players.LocalPlayer.Character["Zyronis Couch" .. p58].Parent = game.Players.LocalPlayer.Backpack
            wait()
            game.Players.LocalPlayer.Backpack["Zyronis Couch" .. p58]:FindFirstChild("Handle ").Name = "Handle"
            wait(0.2)
            game.Players.LocalPlayer.Backpack["Zyronis Couch" .. p58].Parent = game.Players.LocalPlayer.Character
            wait()
            game.Players.LocalPlayer.Character["Zyronis Couch" .. p58].Parent = game.Players.LocalPlayer.Backpack
        end
    end
    for k, player in pairs(game.Players:GetPlayers()) do
        local v508 = k
        local v509 = player

        if v509.Name == game.Players.LocalPlayer.Name == false then
            spawn(function()
                v505(v508, v509)
            end)
        end
    end
    task.delay(14, function()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(HumanoidRootPartPosition)
    end)
    task.delay(14.1, function()
        game:GetService("ReplicatedStorage"):WaitForChild("RE"):WaitForChild("1Clea1rTool1s"):FireServer(unpack(t39))
    end)
end
})
v11:AddButton({
	Name = "فلنق الكل كره",
	Callback = function()
    local LocalPlayer = game:GetService("Players").LocalPlayer
    local v511 = workspace.WorkspaceCom["001_SoccerBalls"]
    local v512 = v511:FindFirstChild("Soccer" .. LocalPlayer.Name)

    if not v512 then
        if not LocalPlayer.Backpack:FindFirstChild("SoccerBall") then
            local t44 = {
					[1] = "PickingTools",
					[2] = "SoccerBall"
				}
            local v514 = game:GetService("ReplicatedStorage").RE:FindFirstChild("1Too1l")
            local t45 = { unpack(t44) }

            v514:InvokeServer(v2(t45))
            task.wait()
            LocalPlayer.Backpack.SoccerBall.Parent = LocalPlayer.Character

            repeat
                v512 = v511:FindFirstChild("Soccer" .. LocalPlayer.Name)
                task.wait()
            until v512

            LocalPlayer.Character.SoccerBall.Parent = LocalPlayer.Backpack
            task.wait()
        else
            LocalPlayer.Backpack.SoccerBall.Parent = LocalPlayer.Character

            repeat
                v512 = v511:FindFirstChild("Soccer" .. LocalPlayer.Name)
                task.wait()
            until v512

            LocalPlayer.Character.SoccerBall.Parent = LocalPlayer.Backpack
        end
    end

    for _, player in pairs(game.Players:GetPlayers()) do
        if player == game.Players.LocalPlayer then
            continue
        end

        local v518 = player
        local v519 = v518.Character or v518.CharacterAdded:Wait()
        local HumanoidRootPart = v519:WaitForChild("HumanoidRootPart")

        if not v512 or not HumanoidRootPart then
            return
        end

        for _, child in pairs(v512:GetChildren()) do
            if child:IsA("BodyMover") then
                child:Destroy()
            end
        end

        local BodyVelocity = Instance.new("BodyVelocity")

        BodyVelocity.Velocity = Vector3.new(900000000, 900000000, 900000000)
        BodyVelocity.MaxForce = Vector3.new(1e999, 1e999, 1e999)
        BodyVelocity.P = 10000000000
        BodyVelocity.Parent = v512

        local BodyVelocity2 = Instance.new("BodyVelocity")

        BodyVelocity2.Velocity = Vector3.new(900000000, 900000000, 900000000)
        BodyVelocity2.MaxForce = Vector3.new(1e999, 1e999, 1e999)
        BodyVelocity2.P = 1000000000
        BodyVelocity2.Parent = HumanoidRootPart

        local _ = HumanoidRootPart.Position

        workspace.CurrentCamera.CameraSubject = HumanoidRootPart

        if not (HumanoidRootPart.Velocity.Magnitude > 5000) and v519.Humanoid.Health ~= 0 and v518.Parent == game.Players and v519 == HumanoidRootPart.Parent then
            if v519 == v518.Character then
            end
        end

        repeat
            local _ = HumanoidRootPart.Velocity.Magnitude
            local t46 = {}
            local GetDescendants = v519.GetDescendants
            for v531, v532 in pairs(GetDescendants(v519)) do

                if v532:IsA("BasePart") and (v532.CanCollide and not v532.Anchored) then
                    table.insert(t46, v532)
                end
            end
            for v535, v536 in ipairs(t46) do

                local PositionX = v518.Character.HumanoidRootPart.Position.X
                local PositionY = v518.Character.HumanoidRootPart.Position.Y
                local PositionZ = v518.Character.HumanoidRootPart.Position.Z
                local v540 = PositionX + v518.Character.HumanoidRootPart.Velocity.X / 1.5
                local v541 = PositionY + v518.Character.HumanoidRootPart.Velocity.Y / 1.5
                local v542 = PositionZ + v518.Character.HumanoidRootPart.Velocity.Z / 1.5

                v512.CFrame = CFrame.new(v540, v541, v542)
                task.wait(0.00016666666666667)
            end
            task.wait(0.00016666666666667)
            local v543 = HumanoidRootPart.Velocity.Magnitude > 5000
            if not v543 then
                v543 = v519.Humanoid.Health == 0 or (v518.Parent ~= game.Players or (v519 ~= HumanoidRootPart.Parent or v519 ~= v518.Character))
            end
        until v543
    end

    workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character:WaitForChild("HumanoidRootPart")
end
})
t1.value31 = game:GetService("Players")
t1.value32 = game:GetService("ReplicatedStorage")
t1.value33 = game:GetService("RunService")
t1.value34 = game:GetService("VirtualUser")
t1.value35 = t1.value31.LocalPlayer
t1.value36 = nil
t1.value37 = nil
t1.value38 = false
t1.value39 = nil
t1.value40 = false
local v15 = t1.value4:MakeTab({
	Title = "افك",
	Icon = "rbxassetid://76144975356652"
})
v15:AddSection({
	Name = "اختيار اللاعب"
})
local v16 = (function()
    local t47 = {}

    for _, player in ipairs(t1.value31:GetPlayers()) do
        if player ~= t1.value35 then
            table.insert(t47, player.Name)
        end
    end

    return t47
end)()
t1.value41 = v15:AddDropdown({
	Name = "اختار الاعب",
	Options = v16,
	Default = "",
	Callback = function(p60)
    t1.value36 = p60
    getgenv().Target = p60
    print("تم اختيار: " .. tostring(p60))
end
})
v15:AddButton({
	Name = "تحديث القايمه",
	Callback = function()
    local t48 = {}
    local players = t1.value31:GetPlayers()

    if t1.value41 and #players > 0 then
        for _, v in ipairs(players) do
            if v.Name ~= t1.value35.Name then
                table.insert(t48, v.Name)
            end
        end

        t1.value41:Set(t48)
        print("تم تحديث القائمة: ", table.concat(t48, ", "))

        if t1.value36 and not t1.value31:FindFirstChild(t1.value36) then
            t1.value36 = nil
            getgenv().Target = nil
            t1.value41:SetValue("")
            print("تم اعادة تعيين الاختيار - اللاعب غير موجود")

            return
        end
    else
        print("خطأ: لا يوجد لاعبين")
    end
end
})
v15:AddButton({
	Name = "انتقل للاعب",
	Callback = function()
    if not t1.value36 or not t1.value31:FindFirstChild(t1.value36) then
        print("خطأ: لم يتم اختيار لاعب")

        return
    end

    local Character = t1.value35.Character
    local v553 = Character and Character:FindFirstChild("HumanoidRootPart")

    if not v553 then
        return
    end

    local t1value36 = t1.value31:FindFirstChild(t1.value36)

    if t1value36 and (t1value36.Character and t1value36.Character:FindFirstChild("HumanoidRootPart")) then
        v553.CFrame = t1value36.Character.HumanoidRootPart.CFrame
        print("تم الانتقال الى " .. t1.value36)
    end
end
})
v15:AddToggle({
	Name = "راقب الاعب",
	Default = false,
	Callback = function(p61)
    local CurrentCamera = workspace.CurrentCamera

    local function v557()
        if p61 then
            local t1value36 = t1.value31:FindFirstChild(t1.value36)

            if t1value36 and t1value36.Character then
                local Humanoid = t1value36.Character:FindFirstChild("Humanoid")

                if Humanoid then
                    CurrentCamera.CameraSubject = Humanoid

                    return
                end
            end
        elseif t1.value35.Character then
            local Humanoid = t1.value35.Character:FindFirstChild("Humanoid")

            if Humanoid then
                CurrentCamera.CameraSubject = Humanoid
            end
        end
    end

    if p61 then
        if not getgenv().CameraConnection then
            getgenv().CameraConnection = t1.value33.Heartbeat:Connect(v557)

            local _print = print
            local value36 = t1.value36

            if not value36 then
                value36 = "لاعب"
            end

            _print("بدء مراقبة " .. value36)

            return
        end
    else
        if getgenv().CameraConnection then
            getgenv().CameraConnection:Disconnect()
            getgenv().CameraConnection = nil
            print("تم ايقاف المراقبة")
        end

        v557()
    end
end
})
v15:AddSection({
	Name = "مضاد الافك"
})
t1.value42 = nil
t1.value43 = false
v15:AddToggle({
	Name = "مضاد افك (Anti-AFK)",
	Default = false,
	Callback = function(p62)
    t1.value43 = p62

    if t1.value43 then
        if not t1.value42 then
            t1.value35.Idled:Connect(function()
                if t1.value43 then
                    t1.value34:CaptureController()
                    t1.value34:ClickButton2(Vector2.new())
                    print("Anti-AFK:")
                end
            end)
        end

        print("تم تفعيل مضاد الافك")

        return
    end

    print("تم ايقاف مضاد الافك")
end
})
v15:AddSection({
	Name = "تفعيل روبوت علي التختاره"
})
local function v17()
    local v561 = "Prop" .. t1.value35.Name
    local v562 = workspace:FindFirstChild("WorkspaceCom") and workspace.WorkspaceCom:FindFirstChild("001_TrafficCones")

    if v562 then
        local GetChildren = v562.GetChildren

        for _, v in ipairs(GetChildren(v562)) do
            if v561 == v.Name or string.find(v.Name, t1.value35.Name) then
                return v
            end
        end
    end

    local Character = t1.value35.Character
    local v567 = Character and Character:FindFirstChild("HumanoidRootPart")

    for _, child in ipairs(workspace:GetChildren()) do
        local v570 = child:IsA("Model")

        if v570 then
            local v571 = v561 == child.Name

            if not v571 then
                v571 = string.find(child.Name, "Prop") and (v567 and (child:GetPivot().Position - v567.Position).Magnitude < 15)
            end

            v570 = v571 and child ~= Character
        end

        if v570 then
            return child
        end
    end

    return nil
end
function t1.value44()
    if t1.value37 then
        t1.value37:Disconnect()
    end

    print(".")
end
t1.value45 = nil
function t1.value45()
    t1.value44()

    if not t1.value36 then
        return
    end

    task.spawn(function()
        pcall(function()
            local t1value36 = t1.value31:FindFirstChild(t1.value36)

            if not t1value36 or not t1value36.Character then
                return
            end

            local v1472 = t1.value32:FindFirstChild("RE") or workspace
            local v1473 = v1472:FindFirstChild("1Clea1rTool1s")
            local v1474 = v1472:FindFirstChild("1Too1l")

            if v1473 then
                v1473:FireServer("ClearAllTools")
            end

            task.wait(0.2)

            if v1474 then
                v1474:InvokeServer("PickingTools", "PropMaker")
            end

            local PropMaker = t1.value35.Backpack:WaitForChild("PropMaker", 5)

            if not PropMaker then
                return
            end

            local Character = t1.value35.Character

            if Character then
                local Humanoid = Character:FindFirstChild("Humanoid")

                if Humanoid then
                    Humanoid:EquipTool(PropMaker)
                end
            end

            task.wait(0.3)

            if v1473 then
                v1473:FireServer("RequestingPropName", "ScreensRobotBig", "Screens", "Play")
            end

            task.wait(0.3)

            local Tool_PropMake = PropMaker:FindFirstChild("Tool_PropMake")

            if Tool_PropMake and Character then
                local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

                if HumanoidRootPart then
                    local v1480 = HumanoidRootPart.Position + HumanoidRootPart.CFrame.LookVector * 5
                    local vector3 = Vector3.new(v1480.X, HumanoidRootPart.Position.Y - 3, v1480.Z)

                    Tool_PropMake:FireServer(workspace:FindFirstChild("Street") or (workspace:FindFirstChild("Map") or (workspace:FindFirstChild("Terrain") or workspace)), vector3)
                end
            end

            t1.value34:Button1Down(Vector2.new(0, 500), workspace.CurrentCamera.CFrame)
            task.wait(0.1)
            t1.value34:Button1Up(Vector2.new(0, 500), workspace.CurrentCamera.CFrame)
            task.wait(0.5)

            local v1482 = v17()

            if v1482 then
                local SetCurrentCFrame = v1482:WaitForChild("SetCurrentCFrame", 5)

                if SetCurrentCFrame then
                    local n14 = 0

                    t1.value33.Heartbeat:Connect(function(dt)
                        if t1.value38 and t1.value36 then
                            if not v1482 or not v1482.Parent then
                                t1.value44()
                                task.wait(0.5)
                                t1.value45()

                                return
                            end

                            local t1value36_2 = t1.value31:FindFirstChild(t1.value36)

                            if t1value36_2 and (t1value36_2.Character and t1value36_2.Character:FindFirstChild("HumanoidRootPart")) then
                                local HumanoidRootPart = t1value36_2.Character.HumanoidRootPart

                                n14 += dt * 16

                                local v1725 = math.sin(n14) * 0.8
                                local v1726 = HumanoidRootPart.CFrame * CFrame.new(0, 0, -2.2 + v1725)

                                pcall(function()
                                    SetCurrentCFrame:InvokeServer(v1726)
                                end)

                                return
                            end
                        else
                            t1.value44()
                        end
                    end)
                end
            end
        end)
    end)
end
v15:AddToggle({
	Name = "فعل بانج روبوت وجه",
	Default = false,
	Callback = function(p63)
    if p63 and not t1.value36 then
        print("!! ولك اختارلك لاعب !!")

        return false
    end

    if p63 then
        t1.value45()
        print("تم تفعيل الروبوت لعيونك " .. t1.value36 or "لا يوجد")

        return
    end

    t1.value44()
end
})
function t1.value46()
    if t1.value39 then
        t1.value39:Disconnect()
    end

    print(".")
end
t1.value47 = nil
function t1.value47()
    t1.value46()

    if not t1.value36 then
        return
    end

    task.spawn(function()
        pcall(function()
            local t1value36 = t1.value31:FindFirstChild(t1.value36)

            if not t1value36 or not t1value36.Character then
                return
            end

            local v1486 = t1.value32:FindFirstChild("RE") or workspace
            local v1487 = v1486:FindFirstChild("1Clea1rTool1s")
            local v1488 = v1486:FindFirstChild("1Too1l")

            if v1487 then
                v1487:FireServer("ClearAllTools")
            end

            task.wait(0.2)

            if v1488 then
                v1488:InvokeServer("PickingTools", "PropMaker")
            end

            local PropMaker = t1.value35.Backpack:WaitForChild("PropMaker", 5)

            if not PropMaker then
                return
            end

            local Character = t1.value35.Character

            if Character then
                local Humanoid = Character:FindFirstChild("Humanoid")

                if Humanoid then
                    Humanoid:EquipTool(PropMaker)
                end
            end

            task.wait(0.3)

            if v1487 then
                v1487:FireServer("RequestingPropName", "ScreensRobotBig", "Screens", "Play")
            end

            task.wait(0.3)

            local Tool_PropMake = PropMaker:FindFirstChild("Tool_PropMake")

            if Tool_PropMake and Character then
                local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

                if HumanoidRootPart then
                    local v1494 = HumanoidRootPart.Position + HumanoidRootPart.CFrame.LookVector * 5
                    local vector3 = Vector3.new(v1494.X, HumanoidRootPart.Position.Y - 3, v1494.Z)

                    Tool_PropMake:FireServer(workspace:FindFirstChild("Street") or (workspace:FindFirstChild("Map") or (workspace:FindFirstChild("Terrain") or workspace)), vector3)
                end
            end

            t1.value34:Button1Down(Vector2.new(0, 500), workspace.CurrentCamera.CFrame)
            task.wait(0.1)
            t1.value34:Button1Up(Vector2.new(0, 500), workspace.CurrentCamera.CFrame)
            task.wait(0.5)

            local v1496 = v17()

            if v1496 then
                local SetCurrentCFrame = v1496:WaitForChild("SetCurrentCFrame", 5)

                if SetCurrentCFrame then
                    local n15 = 0

                    t1.value33.Heartbeat:Connect(function(dt)
                        local value40 = t1.value40

                        if value40 then
                            value40 = t1.value36
                        end

                        if value40 then
                            if not v1496 or not v1496.Parent then
                                t1.value46()
                                task.wait(0.5)
                                t1.value47()

                                return
                            end

                            local t1value36_3 = t1.value31:FindFirstChild(t1.value36)

                            if t1value36_3 and (t1value36_3.Character and t1value36_3.Character:FindFirstChild("HumanoidRootPart")) then
                                local HumanoidRootPart = t1value36_3.Character.HumanoidRootPart
                                n15 += dt * 25
                                local v1731 = math.sin(n15) * 3
                                local v1732 = HumanoidRootPart.CFrame * CFrame.new(0, -4, 2 + v1731) * CFrame.Angles(0, 3.141592653589793, 0)
                                local u1733 = v1732
                                pcall(function()
                                    SetCurrentCFrame:InvokeServer(u1733)
                                end)

                                return
                            end
                        else
                            t1.value46()
                        end
                    end)
                end
            end
        end)
    end)
end
v15:AddToggle({
	Name = "فعل علي الاعب روبوت خلفي",
	Default = false,
	Callback = function(p64)
    if p64 and not t1.value36 then
        print("!! يسطا اختار الاعب الاول من قايمه !!")

        return false
    end

    if p64 then
        t1.value47()
        print("تم تفعيل الروبوت لعيونك " .. t1.value36 or "لا يوجد")

        return
    end

    t1.value46()
end
})
v15:AddButton({
	Name = "تفعيل روبوتات علي كل الفي سرفر",
	Callback = function()
    pcall(function()
        loadstring(game:HttpGet("https://encrypt-x.pages.dev/Scripts?Id=rexmhub1"))("rexmhub1")
        print("تم تشغيل لعيونك")
    end)
end
})
_G.FLOREX_NameAnim_Toggle = false
_G.FLOREX_Anim_Speed = 2
_G.Names_List = {
	"",
	"",
	"",
	"",
	""
}
_G.Bios_List = {
	"",
	"",
	"",
	"",
	""
}
_G.FLOREX_Rainbow_Toggle = false
_G.FLOREX_Rainbow_Speed = 5
_G.FLOREX_RedBlack_Toggle = false
_G.FLOREX_Neon_Toggle = false
_G.FLOREX_GoldWhite_Toggle = false
_G.FLOREX_PurplePink_Toggle = false
_G.FLOREX_GreenBlack_Toggle = false
_G.FLOREX_Fire_Toggle = false
_G.FLOREX_Ice_Toggle = false
_G.FLOREX_Vampire_Toggle = false
_G.FLOREX_Galaxy_Toggle = false
_G.FLOREX_Thunder_Toggle = false
_G.FLOREX_Emerald_Toggle = false
_G.FLOREX_Magma_Toggle = false
_G.FLOREX_Toxic_Toggle = false
function t1.value48()
    _G.FLOREX_Rainbow_Toggle = false
    _G.FLOREX_RedBlack_Toggle = false
    _G.FLOREX_Neon_Toggle = false
    _G.FLOREX_GoldWhite_Toggle = false
    _G.FLOREX_PurplePink_Toggle = false
    _G.FLOREX_GreenBlack_Toggle = false
    _G.FLOREX_Fire_Toggle = false
    _G.FLOREX_Ice_Toggle = false
    _G.FLOREX_Vampire_Toggle = false
    _G.FLOREX_Galaxy_Toggle = false
    _G.FLOREX_Thunder_Toggle = false
    _G.FLOREX_Emerald_Toggle = false
    _G.FLOREX_Magma_Toggle = false
    _G.FLOREX_Toxic_Toggle = false
end
local v18 = t1.value4:MakeTab({
	Title = "الاسماء",
	Icon = "rbxassetid://76144975356652"
})
v18:AddSection({ "غير اسم لماب البيوت (RP Name & Bio)" })
v18:AddTextBox({
	Name = "اكتب الاسم (RP Name)",
	PlaceholderText = "اكتب الاسم هنا...",
	Default = "",
	ClearText = false,
	Callback = function(p65)
    pcall(function()
        local RE = t1.value32:FindFirstChild("RE")

        if RE then
            RE:FindFirstChild("1RPNam1eTex1t"):FireServer("RolePlayName", p65)
        end
    end)
end
})
v18:AddTextBox({
	Name = "اكتب الوصف (Bio)",
	PlaceholderText = "اكتب الوصف هنا...",
	Default = "",
	ClearText = false,
	Callback = function(p66)
    pcall(function()
        local RE = t1.value32:FindFirstChild("RE")

        if RE then
            RE:FindFirstChild("1RPNam1eTex1t"):FireServer("RolePlayBio", p66)
        end
    end)
end
})
v18:AddSection({ "تغيير تلقائي للأسماء والبايو" })
v18:AddToggle({
	Name = "تشغيل التغيير التلقائي",
	Default = false,
	Callback = function(p67)
    _G.FLOREX_NameAnim_Toggle = p67
end
})
v18:AddSlider({
	Name = "سرعة التغيير (ثواني)",
	Min = 0,
	Max = 30,
	Default = 2,
	Increase = 1,
	Callback = function(p68)
    _G.FLOREX_Anim_Speed = p68
end
})
v18:AddSection({ "الاسماء" })

for i = 1, 5 do
    local v20 = "الاسم " .. i
    local v21 = "الاسم " .. i .. "..."

    v18:AddTextBox({
		Name = v20,
		PlaceholderText = v21,
		Default = "",
		ClearText = false,
		Callback = function(p69)
        _G.Names_List[i] = p69
    end
	})
end
v18:AddSection({ "البايو (Bio)" })

for i = 1, 5 do
    local v23 = "البايو " .. i
    local v24 = "البايو " .. i .. "..."

    v18:AddTextBox({
		Name = v23,
		PlaceholderText = v24,
		Default = "",
		ClearText = false,
		Callback = function(p70)
        _G.Bios_List[i] = p70
    end
	})
end
v18:AddSection({ "تأثيرات الألوان" })
v18:AddSlider({
	Name = "سرعة Rainbow",
	Min = 0,
	Max = 10,
	Default = 5,
	Increase = 1,
	Callback = function(p71)
    _G.FLOREX_Rainbow_Speed = p71
end
})
v18:AddToggle({
	Name = "Rainbow 🌈",
	Default = false,
	Callback = function(p72)
    t1.value48()
    _G.FLOREX_Rainbow_Toggle = p72
end
})
v18:AddToggle({
	Name = "أحمر وأسود 🔴",
	Default = false,
	Callback = function(p73)
    t1.value48()
    _G.FLOREX_RedBlack_Toggle = p73
end
})
v18:AddToggle({
	Name = "أزرق وأبيض ⚡",
	Default = false,
	Callback = function(p74)
    t1.value48()
    _G.FLOREX_Neon_Toggle = p74
end
})
v18:AddToggle({
	Name = "ذهبي وأبيض 👑",
	Default = false,
	Callback = function(p75)
    t1.value48()
    _G.FLOREX_GoldWhite_Toggle = p75
end
})
v18:AddToggle({
	Name = "بنفسجي وورديّ 💜",
	Default = false,
	Callback = function(p76)
    t1.value48()
    _G.FLOREX_PurplePink_Toggle = p76
end
})
v18:AddToggle({
	Name = "أخضر وأسود 🟢",
	Default = false,
	Callback = function(p77)
    t1.value48()
    _G.FLOREX_GreenBlack_Toggle = p77
end
})
v18:AddToggle({
	Name = "نيران 🔥",
	Default = false,
	Callback = function(p78)
    t1.value48()
    _G.FLOREX_Fire_Toggle = p78
end
})
v18:AddToggle({
	Name = "جليد ❄\239\184\143",
	Default = false,
	Callback = function(p79)
    t1.value48()
    _G.FLOREX_Ice_Toggle = p79
end
})
v18:AddToggle({
	Name = "برق ⚡",
	Default = false,
	Callback = function(p80)
    t1.value48()
    _G.FLOREX_Thunder_Toggle = p80
end
})
v18:AddToggle({
	Name = "فامباير 🧛",
	Default = false,
	Callback = function(p81)
    t1.value48()
    _G.FLOREX_Vampire_Toggle = p81
end
})
v18:AddToggle({
	Name = "مجرة 🌌",
	Default = false,
	Callback = function(p82)
    t1.value48()
    _G.FLOREX_Galaxy_Toggle = p82
end
})
v18:AddToggle({
	Name = "زمرد 💎",
	Default = false,
	Callback = function(p83)
    t1.value48()
    _G.FLOREX_Emerald_Toggle = p83
end
})
v18:AddToggle({
	Name = "حمم 🌋",
	Default = false,
	Callback = function(p84)
    t1.value48()
    _G.FLOREX_Magma_Toggle = p84
end
})
v18:AddToggle({
	Name = "سام 🧪",
	Default = false,
	Callback = function(p85)
    t1.value48()
    _G.FLOREX_Toxic_Toggle = p85
end
})
task.spawn(function()
    local n16 = 1

    while true do
        if _G.FLOREX_NameAnim_Toggle then
            pcall(function()
                local RE = t1.value32:FindFirstChild("RE")

                if RE then
                    local v1222 = _G.Names_List[n16]
                    local v1223 = _G.Bios_List[n16]

                    if v1222 and v1222 ~= "" then
                        RE:FindFirstChild("1RPNam1eTex1t"):FireServer("RolePlayName", v1222)
                    end

                    if v1223 and v1223 ~= "" then
                        RE:FindFirstChild("1RPNam1eTex1t"):FireServer("RolePlayBio", v1223)
                    end

                    n16 = n16 % 5 + 1
                end
            end)
        end

        task.wait(_G.FLOREX_Anim_Speed)
    end
end)
task.spawn(function()
    while true do
        pcall(function()
            local RE = t1.value32:FindFirstChild("RE")
            local v1225 = RE and RE:FindFirstChild("1RPNam1eColo1r")

            if v1225 then
                local color3
                if _G.FLOREX_Rainbow_Toggle then
                    color3 = Color3.fromHSV(tick() % _G.FLOREX_Rainbow_Speed / _G.FLOREX_Rainbow_Speed, 1, 1)
                elseif _G.FLOREX_RedBlack_Toggle then
                    color3 = Color3.fromRGB(255, 0, 0):Lerp(Color3.fromRGB(0, 0, 0), (math.abs((math.sin(tick() * 2)))))
                elseif _G.FLOREX_Neon_Toggle then
                    local color3_2 = Color3.fromRGB(0, 170, 255)
                    local color3_3 = Color3.fromRGB(255, 255, 255)
                    local abs = math.abs
                    local t49 = { math.cos(tick() * 2) }

                    color3 = color3_2:Lerp(color3_3, abs(v2(t49)))
                elseif _G.FLOREX_GoldWhite_Toggle then
                    local color3_4 = Color3.fromRGB(255, 215, 0)
                    local color3_5 = Color3.fromRGB(255, 255, 255)
                    local abs = math.abs
                    local t50 = { math.sin(tick() * 1.5) }

                    color3 = color3_4:Lerp(color3_5, abs(v2(t50)))
                elseif _G.FLOREX_PurplePink_Toggle then
                    local color3_6 = Color3.fromRGB(138, 43, 226)
                    local color3_7 = Color3.fromRGB(255, 20, 147)
                    local abs = math.abs
                    local t51 = { math.cos(tick() * 2) }

                    color3 = color3_6:Lerp(color3_7, abs(v2(t51)))
                elseif _G.FLOREX_GreenBlack_Toggle then
                    color3 = Color3.fromRGB(0, 255, 0):Lerp(Color3.fromRGB(0, 0, 0), math.abs((math.sin(tick() * 3))))
                elseif _G.FLOREX_Fire_Toggle then
                    color3 = Color3.fromRGB(255, 0, 0):Lerp(Color3.fromRGB(255, 165, 0), math.abs(math.sin(tick() * 3)))
                elseif _G.FLOREX_Ice_Toggle then
                    color3 = Color3.fromRGB(135, 206, 235):Lerp(Color3.fromRGB(255, 255, 255), math.abs(math.sin(tick() * 1.5)))
                elseif _G.FLOREX_Thunder_Toggle then
                    local color3_8 = Color3.fromRGB(255, 255, 255)
                    local color3_9 = Color3.fromRGB(0, 255, 255)
                    local abs = math.abs
                    local t52 = { math.sin(tick() * 10) }

                    color3 = color3_8:Lerp(color3_9, abs(v2(t52)))
                elseif _G.FLOREX_Vampire_Toggle then
                    color3 = Color3.fromRGB(139, 0, 0):Lerp(Color3.fromRGB(0, 0, 0), (math.abs((math.sin(tick() * 2)))))
                elseif _G.FLOREX_Galaxy_Toggle then
                    color3 = Color3.fromRGB(75, 0, 130):Lerp(Color3.fromRGB(0, 0, 255), math.abs(math.cos(tick() * 1.2)))
                elseif _G.FLOREX_Emerald_Toggle then
                    color3 = Color3.fromRGB(0, 255, 100):Lerp(Color3.fromRGB(255, 215, 0), math.abs((math.sin(tick() * 2))))
                elseif _G.FLOREX_Magma_Toggle then
                    color3 = Color3.fromRGB(255, 69, 0):Lerp(Color3.fromRGB(0, 0, 0), math.abs(math.sin(tick() * 2)))
                elseif _G.FLOREX_Toxic_Toggle then
                    color3 = Color3.fromRGB(173, 255, 47):Lerp(Color3.fromRGB(138, 43, 226), math.abs(math.sin(tick() * 2)))
                end
                if color3 then
                    v1225:FireServer("PickingRPNameColor", color3)
                    v1225:FireServer("PickingRPBioColor", color3)
                end
            end
        end)
        task.wait(0.1)
    end
end)

local v25 = t1.value4:MakeTab({
	Title = "الأغاني ",
	Icon = "rbxassetid://76144975356652"
})
function t1.value49(p86, p87, p88)
    local StarterGui6 = game:GetService("StarterGui")
    local v600 = p88 or 3

    StarterGui6:SetCore("SendNotification", {
		Title = p86,
		Text = p87,
		Duration = v600
	})
end
function t1.value50(p89, p90)

    local u603 = p89
    local u604 = p90
    pcall(function()
        local RE = t1.value32:FindFirstChild("RE")

        if not RE then
            t1.value49("خطأ", "لم يتم العثور على RE!")

            return
        end

        local v1244 = RE:FindFirstChild("1NoMoto1rVehicle1s")

        if v1244 then
            v1244:FireServer(u604 or "SkateBoard")
            task.wait(0.4)
            v1244:FireServer("PickingScooterMusicText", (tostring(u603)))
            t1.value49("مشغل الأغاني", "تم تشغيل الأغنية بنجاح 🎵")

            return
        end

        t1.value49("خطأ", "لم يتم العثور على حدث المركبة!")
    end)
end
function t1.value51(p91)
    pcall(function()
        local v1245 = game:GetService("ReplicatedStorage"):WaitForChild("RE"):WaitForChild("1NoMoto1rVehicle1s")

        v1245:FireServer("SegwaySmall")
        task.wait(0.4)
        v1245:FireServer("PickingScooterMusicText", tostring(p91), nil, true)
        t1.value49(".", "تم تشغيل الأغنية على سكوتر ")
    end)
end
t1.value52 = ""
v25:AddSection({
	Name = "كود اغاني"
})
v25:AddTextBox({
	Name = "حط كود الاغنيه التبي تشغله",
	PlaceholderText = "ID هنا...",
	Default = "",
	ClearText = false,
	Callback = function(p92)
    t1.value52 = p92
end
})
v25:AddButton({
	Name = "تشغيل علي سكوتر عادي",
	Callback = function()
    if t1.value52 ~= "" then
        t1.value50(t1.value52, "SkateBoard")

        return
    end

    t1.value49("تنبيه", "يبني حط الكود ID الأغنية أولاً!")
end
})
v25:AddButton({
	Name = "تشغيل علي سكوتر نجمه",
	Callback = function()
    if t1.value52 ~= "" then
        t1.value51(t1.value52)

        return
    end

    t1.value49("حطط كود الاغنيه", "حطط الكود  !")
end
})
v25:AddSection({
	Name = "مالي خلق احط اسميهم"
})
for _, v in ipairs({
	{
		"1",
		"73211638025913"
	},
	{
		"2",
		"79148752172118"
	},
	{
		"3",
		"86576312825535"
	},
	{
		"4",
		"122929786531506"
	},
	{
		"5",
		"117499298661785"
	},
	{
		"6",
		"126494008493117"
	},
	{
		"7",
		"136832177766399"
	},
	{
		"8",
		"125175922597354"
	},
	{
		"9",
		"82436130306823"
	},
	{
		"10",
		"138361625716987"
	},
	{
		"11",
		"109105438058030"
	},
	{
		"12",
		"121584066241524"
	},
	{
		"13",
		"73746846460748"
	},
	{
		"14",
		"86370168350239"
	},
	{
		"15",
		"133174241634120"
	},
	{
		"16",
		"123916759419724"
	},
	{
		"17",
		"109337680029292"
	},
	{
		"18",
		"107819089007268"
	},
	{
		"19",
		"136601122443530"
	},
	{
		"20",
		"134693931986753"
	},
	{
		"21",
		"91611648163631"
	},
	{
		"22",
		"75745765058107"
	},
	{
		"23",
		"87920916682123"
	},
	{
		"24",
		"124393177931443"
	},
	{
		"25",
		"100754234156181"
	},
	{
		"26",
		"0x00000000000006B8E78719165"
	},
	{
		"27",
		"140160495884365"
	},
	{
		"28",
		"127621033784944"
	},
	{
		"29",
		"101448039772098"
	},
	{
		"30",
		"90390662535933"
	},
	{
		"31",
		"110499769951543"
	},
	{
		"32",
		"98640789490482"
	},
	{
		"33",
		"115153161936086"
	},
	{
		"34",
		"126189830749452"
	},
	{
		"35",
		"129963257934687"
	},
	{
		"36",
		"129778791857455"
	},
	{
		"37",
		"107982108641297"
	},
	{
		"38",
		"124688308713895"
	},
	{
		"39",
		"104500083392020"
	},
	{
		"40",
		"88611661470391"
	},
	{
		"41",
		"114339730158889"
	},
	{
		"42",
		"136660784388263"
	},
	{
		"43",
		"130012558337510"
	},
	{
		"44",
		"88232201387507"
	},
	{
		"45",
		"71535145894863"
	},
	{
		"46",
		"124123680327164"
	},
	{
		"47",
		"75019437630721"
	},
	{
		"48",
		"72369698229901"
	},
	{
		"49",
		"129902784040741"
	},
	{
		"50",
		"125570651517245"
	},
	{
		"51",
		"134395113028306"
	},
	{
		"52",
		"93297302504653"
	},
	{
		"53",
		"79193631928944"
	},
	{
		"54",
		"107640531223975"
	},
	{
		"55",
		"98624615549076"
	},
	{
		"56",
		"122098253902813"
	},
	{
		"57",
		"90392454924262"
	},
	{
		"58",
		"117377891709305"
	},
	{
		"59",
		"99352274208551"
	},
	{
		"60",
		"74366649069715"
	},
	{
		"61",
		"85682109892034"
	},
	{
		"62",
		"112517108460773"
	},
	{
		"63",
		"73211638025913"
	},
	{
		"64",
		"79148752172118"
	},
	{
		"65",
		"86576312825535"
	},
	{
		"66",
		"112517108460773"
	},
	{
		"67",
		"73211638025913"
	}
}) do
    local v28 = v

    v25:AddButton({
		Name = " " .. v28[1],
		Callback = function()
        local v607 = v28[2]

        t1.value50(v607)
    end
	})
end
v25:AddSection({
	Name = "🎲 أغاني عشوائية"
})
for _, v in ipairs({
	{
		"افخم فونك",
		"17647322226"
	},
	{
		"فونك غضب",
		"115859025716354"
	},
	{
		"فونك عالمي",
		"76578817848504"
	},
	{
		"فونك ممتاز",
		"102402883551679"
	},
	{
		"فونك ازعاج",
		"85682109892034"
	},
	{
		"عربية نادر",
		"134833118817796"
	}
}) do
    local v31 = v

    v25:AddButton({
		Name = " " .. v31[1],
		Callback = function()
        local v608 = v31[2]

        t1.value50(v608)
    end
	})
end
v25:AddSection({
	Name = "🇮🇶 أغاني عراقية"
})
for _, v in ipairs({
	{
		"راب عراقي 🧩",
		"116272643488592"
	},
	{
		"اخذت بدنيا تعناط ودروس 🙁",
		"112254940188047"
	},
	{
		"شراره 🎻",
		"81023003196738"
	},
	{
		"عراقي 🔥",
		"116815742960163"
	},
	{
		"عراقي حب ❤",
		"105956659839019"
	},
	{
		"فنان 🎸",
		"130012558337510"
	},
	{
		"فنان راب 2 🔥",
		"80945632184135"
	},
	{
		"عراقي ابشرك 🔥❤",
		"82396938710161"
	},
	{
		"ميت انا من فراقك ❤",
		"98313375960954"
	},
	{
		"دم حزني",
		"99123490695024"
	},
	{
		"الحجني يا شرطي 👾",
		"120675895107276"
	},
	{
		"الف صلاه عليك يا محمد",
		"103786200526639"
	},
	{
		"ريمكس عراقي 🔥",
		"136909019669593"
	},
	{
		"شعر عراقي 🎼",
		"83309655997452"
	},
	{
		"وش علينا من الناس",
		"81808954656328"
	},
	{
		"ازعاج عراقي",
		"127840997774724"
	},
	{
		"عراقي حزين 🔥",
		"106271890575602"
	},
	{
		"عود عراقي 🎼",
		"94546035218751"
	},
	{
		"قول الصواري نا🔥",
		"135009652401688"
	},
	{
		"قررنا رحيلك",
		"87510423075068"
	},
	{
		"حلوه 👍",
		"77951452994771"
	},
	{
		"سبحيني بلمشائر",
		"80017487709494"
	},
	{
		"غرقت بحبو",
		"118850051381032"
	},
	{
		"تراني سكران 😂",
		"111811908070601"
	},
	{
		"ازعاج صردع",
		"72369698229901"
	},
	{
		"ما اريدك بعد تهواني",
		"135911328646170"
	}
}) do
    local v34 = v

    v25:AddButton({
		Name = "🇮🇶 " .. v34[1],
		Callback = function()
        local v609 = v34[2]

        t1.value50(v609)
    end
	})
end
v25:AddSection({
	Name = "🇪🇬 أغاني عربية / مصرية"
})
for _, v in ipairs({
	{
		"مصريه 🔥",
		"128624259208020"
	},
	{
		"رمضان برودكشن 👾",
		"123555966146480"
	},
	{
		"دمرتي حياتي",
		"124482316940059"
	},
	{
		"راب",
		"8559374146822"
	},
	{
		"جامده ❤",
		"106941936452890"
	},
	{
		"جامده ❤2",
		"107471923441527"
	},
	{
		"تصدق كرهتك",
		"113478978326245"
	},
	{
		"كارزما وفد شي ينحب",
		"89189069089618"
	},
	{
		"الله الله يا جمالك",
		"102463539890606"
	},
	{
		"اكبر غلطه بحياتي",
		"127085435747898"
	},
	{
		"اه يا حلو",
		"93620598835551"
	},
	{
		"اتركيني جامده",
		"131870431323817"
	},
	{
		"سيبتيني فين كلامك",
		"136793917774554"
	},
	{
		"ليه جي",
		"92304349905750"
	},
	{
		"فارس سكر",
		"115153161936086"
	},
	{
		"هات الدكتور",
		"8776769631"
	},
	{
		"اغنية بنت 🔥",
		"118359337959122"
	},
	{
		"راب فكني منها",
		"125880160870644"
	},
	{
		"اول مره حياتي تورد",
		"122957821960545"
	},
	{
		"علي كيفك 🔥",
		"123487073954032"
	}
}) do
    local v37 = v

    v25:AddButton({
		Name = "🇪🇬 " .. v37[1],
		Callback = function()
        local v610 = v37[2]

        t1.value50(v610)
    end
	})
end
v25:AddSection({
	Name = " أغاني أجنبية"
})
for _, v in ipairs({
	{
		"اجنبيه 😂💔",
		"70782176012619"
	},
	{
		"اجنبي حزين",
		"72320758533508"
	},
	{
		"حلوه",
		"130721206402716"
	},
	{
		"حلوه 2",
		"136869502216760"
	},
	{
		"فونك اجنبي 🔥",
		"130721206402716"
	},
	{
		"قوية 🔥",
		"103288558732219"
	},
	{
		"كرسمس",
		"135528953872601"
	},
	{
		"فونك",
		"111205815697819"
	},
	{
		"جامده 1",
		"127775034804421"
	},
	{
		"جامده 2",
		"135454681412242"
	},
	{
		"جامده 3",
		"127491720343331"
	},
	{
		"اغنية نم نم",
		"95489036869789"
	},
	{
		"ريمكس اجنبي",
		"120871403922972"
	},
	{
		"فونك GTA",
		"109337680029292"
	},
	{
		"فونك خطير 🔥",
		"92165865063521"
	},
	{
		"my money",
		"1846687233"
	},
	{
		"فونك قوي 🔥",
		"138361625716987"
	},
	{
		"ريمكس 🔥",
		"92959057847076"
	}
}) do
    local v40 = v

    v25:AddButton({
		Name = " " .. v40[1],
		Callback = function()
        local v611 = v40[2]

        t1.value50(v611)
    end
	})
end
v25:AddSection({
	Name = " أغاني ازعاج"
})
for _, v in ipairs({
	{
		"get out",
		"99796748877356"
	},
	{
		"علي البي",
		"105438850576001"
	},
	{
		"مو متذكر اسمها",
		"97439414907139"
	},
	{
		"ازعاج فونك",
		"120576436665675"
	}
}) do
    local v43 = v

    v25:AddButton({
		Name = " " .. v43[1],
		Callback = function()
        local v612 = v43[2]

        t1.value50(v612)
    end
	})
end
v25:AddSection({
	Name = "اكواد عشوايهه"
})
for _, v in ipairs({
	{
		"راب",
		"91611648163631"
	},
	{
		"راب",
		"131794008455004"
	},
	{
		"حلوه",
		"112355709978731"
	},
	{
		"black Beatles",
		"134395113028306"
	},
	{
		"Hunter eyes",
		"125309696724310"
	},
	{
		"queen street",
		"1210939149022"
	},
	{
		"",
		"95197852052116"
	},
	{
		"",
		"91946302508743"
	},
	{
		"شوقر",
		"75203096269146"
	},
	{
		"ايلفو سو",
		"131484103484346"
	},
	{
		"ازعاج",
		"112639920708630"
	},
	{
		"SEE TINH",
		"121242950842428"
	},
	{
		"ازعاج سمر",
		"70787882418532"
	},
	{
		"ازعاج كمان",
		"138410854139543"
	},
	{
		"سونا هينا هنيا",
		"137486973114353"
	},
	{
		"جامدووو",
		"83795838775865"
	},
	{
		"تركي مصر",
		"125693571824719"
	},
	{
		"مصريه اعمل ايه",
		"97258693395534"
	},
	{
		"برازيلي",
		"102005596404833"
	},
	{
		"برازيلي",
		"96934467275534"
	},
	{
		"برازيلي",
		"126941748428319"
	},
	{
		"مصري",
		"124482316940059"
	},
	{
		"مصري",
		"86238849012344"
	},
	{
		"مصري",
		"79748972110632"
	},
	{
		"برازيلي",
		"85182585406642"
	},
	{
		"فونكات",
		"72844613532784"
	},
	{
		"باك رومز",
		"120817494107898"
	},
	{
		"كروتسول",
		"110919391228823"
	},
	{
		"راب",
		"98559374146822"
	},
	{
		"راب اجنبي",
		"114316100741483"
	},
	{
		"راب اجنبي",
		"127038714548359"
	},
	{
		"راب اجنبي",
		"110327279527500"
	},
	{
		"Golden Brown",
		"135528953872601"
	},
	{
		"انجليزي",
		"75817059227467"
	},
	{
		"اجنبيه اه",
		"70782176012619"
	},
	{
		"اجنبيه",
		"81875379204994"
	},
	{
		"كود اغنيه هدوء",
		"129338574094673"
	},
	{
		"حلوه",
		"131794008455004"
	}
}) do
    local v46 = v

    v25:AddButton({
		Name = ". " .. v46[1],
		Callback = function()
        local v613 = v46[2]

        t1.value50(v613)
    end
	})
end
v25:AddSection({
	Name = " أكواد سب"
})
for _, v in ipairs({
	{
		"سب 1",
		"91611648163631"
	},
	{
		"كشلي امك",
		"71491005545506"
	},
	{
		"كسر كى*ك يا اجنبي",
		"79928045539255"
	},
	{
		"العن الق*به ياوز الق*به",
		"131006804177346"
	},
	{
		"متجيش مع واحد شر**ط",
		"99113135294997"
	},
	{
		"سب بهجت صابر",
		"6713993281"
	},
	{
		"كى**ك يا حلبي",
		"7942547789"
	},
	{
		"سب 2",
		"131794008455004"
	},
	{
		"سب 3",
		"88304661583351"
	},
	{
		"سب 4",
		"94943308357738"
	}
}) do
    local v49 = v

    v25:AddButton({
		Name = ". " .. v49[1],
		Callback = function()
        local v614 = v49[2]

        t1.value50(v614)
    end
	})
end
local v50 = t1.value4:MakeTab({
	Title = "مضادات  ",
	Icon = "rbxassetid://76144975356652"
})
function t1.value53(p93, p94, p95)
    local StarterGui7 = game:GetService("StarterGui")
    local v619 = p95 or 3

    StarterGui7:SetCore("SendNotification", {
		Title = p93,
		Text = p94,
		Duration = v619
	})
end
t1.value54 = game.Players.LocalPlayer
t1.value55 = game:GetService("RunService")
t1.value56 = game:GetService("TweenService")
t1.value57 = game:GetService("Players")

local ReplicatedStorage = game:GetService("ReplicatedStorage")

t1.value58 = false
t1.value59 = {}
t1.value60 = nil
t1.value61 = nil
t1.value62 = nil
function t1.value63()
    t1.value59 = {}

    if not t1.value60 then
        return
    end

    for _, descendant in ipairs(t1.value60:GetDescendants()) do
        if descendant:IsA("BasePart") and descendant.Transparency < 1 then
            table.insert(t1.value59, descendant)
        end
    end
end
function t1.value64(p96)
    t1.value58 = p96

    for _, v in ipairs(t1.value59) do
        if t1.value58 then
            v.Transparency = 0.5
        else
            v.Transparency = 0
        end
    end
end
local function v52(p97)
    t1.value60 = p97
    t1.value61 = p97:WaitForChild("Humanoid")
    t1.value62 = p97:WaitForChild("HumanoidRootPart")
    t1.value63()
    t1.value64(false)
end
t1.value54.CharacterAdded:Connect(v52)

if t1.value54.Character then
    v52(t1.value54.Character)
end
t1.value55.Heartbeat:Connect(function()
    if t1.value58 and (t1.value62 and t1.value61) then
        local value62CFrame = t1.value62.CFrame
        local CameraOffset = t1.value61.CameraOffset
        local v628 = value62CFrame * CFrame.new(0, -200000, 0)
        local Position = v628:ToObjectSpace(CFrame.new(value62CFrame.Position)).Position

        t1.value62.CFrame = v628
        t1.value61.CameraOffset = Position
        t1.value55.RenderStepped:Wait()
        t1.value62.CFrame = value62CFrame
        t1.value61.CameraOffset = CameraOffset
    end
end)
v50:AddSection({ "مضادات " })

function t1.value65()
    pcall(function()
        local v1246 = t1.value54.Character and t1.value54.Character:FindFirstChildOfClass("Humanoid")

        if v1246 then
            v1246.MaxHealth = 999999
            v1246.Health = 999999
            v1246:SetStateEnabled(Enum.HumanoidStateType.Dead, false)
            v1246:SetStateEnabled(Enum.HumanoidStateType.FallingDown, false)
        end
    end)
end
t1.value54.CharacterAdded:Connect(function()
    if _G.VoidExileActive then
        task.wait(1)
        t1.value65()
    end
end)
v50:AddButton({
	Name = "اضغط علي زر ذا اي احد يفعل عليك ادوات او روبوتات",
	Callback = function()
    task.spawn(function()
        pcall(function()
            t1.value53("REX-M", "اصبر رح احذفلك الادوات معليك...", 2)

            local ReplicatedStorage2 = game:GetService("ReplicatedStorage")
            local LocalPlayer = game:GetService("Players").LocalPlayer
            local Character = LocalPlayer.Character

            if not Character then
                t1.value53("REX-M", ".!", 2)

                return
            end

            local HumanoidRootPart = Character:WaitForChild("HumanoidRootPart")
            local HumanoidRootPartCFrame = HumanoidRootPart.CFrame
            local v1504 = workspace:WaitForChild("001_Lots")
            local u1505 = v1504:FindFirstChild(LocalPlayer.Name .. "House")

            if not u1505 then
                local t53 = {}
                for v1509, v1510 in pairs(v1504:GetChildren()) do

                    if v1510.Name == "For Sale" then
                        for _, descendant in pairs(v1510:GetDescendants()) do
                            if descendant:IsA("NumberValue") and (descendant.Name == "Number" and (descendant.Value <= 25 and descendant.Value >= 11)) then
                                local insert = table.insert
                                local descendantValue = descendant.Value

                                insert(t53, {
										Lot = v1510,
										Number = descendantValue
									})
                            end
                        end
                    end
                end
                if #t53 > 0 then
                    local v1515 = t53[math.random(1, #t53)]
                    local BuyHouse = v1515.Lot:FindFirstChild("BuyHouse")

                    if BuyHouse then
                        HumanoidRootPart.CFrame = BuyHouse.CFrame + Vector3.new(0, -6, 0)
                        task.wait(0.5)

                        if BuyHouse:FindFirstChild("ClickDetector") then
                            fireclickdetector(BuyHouse.ClickDetector)
                        end
                    end

                    if ReplicatedStorage2:FindFirstChild("Remotes") then
                        if ReplicatedStorage2.Remotes:FindFirstChild("Lot:Claim") then
                            ReplicatedStorage2.Remotes["Lot:Claim"]:InvokeServer(v1515.Number)
                        end

                        task.wait(0.5)

                        if ReplicatedStorage2.Remotes:FindFirstChild("TelemetryClientInteraction") then
                            ReplicatedStorage2.Remotes.TelemetryClientInteraction:FireServer("filterClick", {
									name = "029_House",
									itemType = "Houses"
								})
                        end

                        task.wait(0.5)

                        if ReplicatedStorage2.Remotes:FindFirstChild("Lot:BuildProperty") then
                            ReplicatedStorage2.Remotes["Lot:BuildProperty"]:InvokeServer(v1515.Number, "029_House")
                        end
                    end

                    task.wait(1)
                end
                u1505 = v1504:FindFirstChild(LocalPlayer.Name .. "House")
            end

            if u1505 then
                HumanoidRootPart.CFrame = u1505:GetModelCFrame()
                task.wait(1)
                pcall(function()
                    u1505:WaitForChild("HousePickedByPlayer"):WaitForChild("HouseModel"):WaitForChild("Permissions:ClearProps"):InvokeServer()
                end)
                task.wait(0.2)
                t1.value53("REX-M", "حذفتهم لك يلا مبروك!", 2)
            end

            if HumanoidRootPartCFrame then
                HumanoidRootPart.CFrame = HumanoidRootPartCFrame
            end
        end)
    end)
end
})
v50:AddToggle({
	Name = "مضاد بانج (REX-M)",
	Default = false,
	Callback = function(p98)
    _G.VoidExileActive = p98

    if _G.VoidExileActive then
        t1.value53("REX-M", "انت تحت حمايتي دلوقتي")
        t1.value65()
        task.spawn(function()
            while _G.VoidExileActive do
                t1.value55.Heartbeat:Wait()
                pcall(function()
                    local Character = t1.value54.Character
                    local v1518 = Character and Character:FindFirstChild("HumanoidRootPart")
                    local v1519 = Character and Character:FindFirstChildOfClass("Humanoid")

                    if not v1518 or v1519 and v1519.Health <= 0 then
                        return
                    end

                    for _, player in pairs(t1.value57:GetPlayers()) do
                        if player ~= t1.value54 and (player.Character and player.Character:FindFirstChild("HumanoidRootPart")) then
                            local HumanoidRootPart = player.Character.HumanoidRootPart
                            local Humanoid = player.Character:FindFirstChildOfClass("Humanoid")

                            if (v1518.Position - HumanoidRootPart.Position).Magnitude < 7 and (Humanoid and Humanoid.Health > 0) then
                                local CFrame7 = v1518.CFrame
                                local Velocity = v1518.Velocity
                                local vector3 = Vector3.new(1000000, -100000, 1000000)

                                HumanoidRootPart.Velocity = Vector3.new(0, -1000000, 0)
                                HumanoidRootPart.RotVelocity = Vector3.new(5000, 5000, 5000)
                                v1518.CFrame = CFrame.new(vector3)
                                HumanoidRootPart.CFrame = CFrame.new(vector3)
                                t1.value55.RenderStepped:Wait()
                                v1518.CFrame = CFrame7
                                v1518.Velocity = Velocity
                            end
                        end
                    end
                end)
            end
        end)

        return
    end

    t1.value53("REX-M", "تم ايقاف مضاد البانج.")
    pcall(function()
        if t1.value54.Character and t1.value54.Character:FindFirstChildOfClass("Humanoid") then
            t1.value54.Character.Humanoid.MaxHealth = 100
            t1.value54.Character.Humanoid.Health = 100
            t1.value54.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Dead, true)
        end
    end)
end
})
v50:AddToggle({
	Name = " مضاد بانج (بانج)",
	Default = false,
	Callback = function(p99)
    t1.value64(p99)
end
})
t1.value66 = false
function t1.value67(p100)
    local t54 = {}
    local GetAccessories = p100.GetAccessories

    for _, v in ipairs(GetAccessories(p100, true)) do
        if v.AssetId then
            t54[v.AssetId] = true
        end
    end

    return t54
end
local function v53(p101, p102)
    local n17 = 0
    for v642 in pairs(p101) do

        if p102[v642] then
            n17 += 1
        end
    end

    return n17
end
local Remotes = ReplicatedStorage:FindFirstChild("Remotes")

t1.value68 = Remotes and Remotes:FindFirstChild("ResetCharacterAppearance")

function t1.value69(p103)
    if not p103.Character or not t1.value54.Character then
        return
    end

    local HumanoidRootPart = t1.value54.Character:FindFirstChild("HumanoidRootPart")
    local HumanoidRootPart5 = p103.Character:FindFirstChild("HumanoidRootPart")

    if not HumanoidRootPart or not HumanoidRootPart5 then
        return
    end

    t1.value56:Create(HumanoidRootPart, TweenInfo.new(0.2, Enum.EasingStyle.Linear), {
		CFrame = HumanoidRootPart5.CFrame
	}):Play()
end
function t1.value70(p104)
    if p104 == t1.value54 then
        return
    end

    task.spawn(function()
        while t1.value66 and p104.Parent do
            if p104.Character and t1.value54.Character then
                local Humanoid = t1.value54.Character:FindFirstChildOfClass("Humanoid")
                local Humanoid9 = p104.Character:FindFirstChildOfClass("Humanoid")

                if Humanoid and Humanoid9 then
                    local GetAppliedDescription = Humanoid.GetAppliedDescription
                    local GetAppliedDescription2 = Humanoid9.GetAppliedDescription
                    local v1251 = t1.value67(GetAppliedDescription(Humanoid))
                    local v1252 = t1.value67(GetAppliedDescription2(Humanoid9))

                    if v53(v1251, v1252) >= 3 then
                        if t1.value68 then
                            t1.value68:FireServer()
                        end

                        task.wait(0.1)
                        t1.value69(p104)
                        task.wait(1E-05)
                    end
                end
            end

            task.wait(0.2)
        end
    end)
end
v50:AddToggle({
	Name = " مضاد نسخ سكنات",
	Default = false,
	Callback = function(p105)
    t1.value66 = p105

    if p105 then
        for _, player in ipairs(t1.value57:GetPlayers()) do
            t1.value70(player)
        end

        t1.value57.PlayerAdded:Connect(t1.value70)
    end
end
})
t1.value71 = nil
t1.value72 = {}
t1.value73 = nil
t1.value73 = "1Gu1nSound1s"
function t1.value74()
    for _, descendant in ipairs(game:GetDescendants()) do
        local v655 = descendant

        if v655.Name == t1.value73 then
            pcall(function()
                local clone = v655:Clone()
                local Parent = v655.Parent

                table.insert(t1.value72, {
					Clone = clone,
					Parent = Parent
				})
                v655:Destroy()
            end)
        end
    end
end
function t1.value75()
    for _, v in ipairs(t1.value72) do
        local v652 = v

        pcall(function()
            v652.Clone.Parent = v652.Parent
        end)
    end

    t1.value72 = {}
end
v50:AddToggle({
	Name = " مضاد ازعاج الصوت",
	Default = false,
	Callback = function(p106)
    if p106 then
        t1.value74()
        t1.value71 = game.DescendantAdded:Connect(function(descendant)
            if descendant.Name == t1.value73 then
                task.wait(0.1)
                pcall(function()
                    local clone = descendant:Clone()
                    local descendantParent = descendant.Parent

                    table.insert(t1.value72, {
							Clone = clone,
							Parent = descendantParent
						})
                    descendant:Destroy()
                end)
            end
        end)

        return
    end

    if t1.value71 then
        t1.value71:Disconnect()
    end

    t1.value75()
end
})
t1.value76 = nil
t1.value77 = Vector3.new(-26.09, 2.79, 6.11)
v50:AddToggle({
	Name = " مضاد فويد",
	Default = false,
	Callback = function(p107)
    if t1.value76 then
        t1.value76:Disconnect()
    end

    if p107 then
        t1.value55.Stepped:Connect(function()
            local Character = t1.value54.Character
            local v1257 = Character and Character:FindFirstChild("HumanoidRootPart")

            if not v1257 then
                return
            end

            local Position = v1257.Position
            local v1259 = Position.Y > -20

            if v1259 then
                v1259 = Position.Y < 1000 and (math.abs(Position.X) < 2000 and math.abs(Position.Z) < 2000)
            end

            if v1259 then
                t1.value77 = Position
            end

            local v1260 = Position.Y < -50

            if not v1260 then
                v1260 = Position.Y > 1500 or (math.abs(Position.X) > 3000 or math.abs(Position.Z) > 3000)
            end

            if v1260 then
                v1257.CFrame = CFrame.new(t1.value77)
                t1.value53("REX-M", "انت محمي من الموت تحت الارض", 3)
            end
        end)
    end
end
})
t1.value78 = {
	Vehicles = {},
	Canoes = {},
	Jets = {},
	Helis = {},
	Balls = {}
}
t1.value79 = workspace
local function v55(p108, p109)
    local u660 = false

    task.spawn(function()
        while true do
            if u660 and t1.value54.Character then
                local v1261 = p109()

                if v1261 then
                    for _, child in ipairs(v1261:GetChildren()) do
                        local v1264 = false

                        if p108 == "Vehicles" then
                            for _, descendant in ipairs(child:GetDescendants()) do
                                if descendant:IsA("VehicleSeat") or descendant:IsA("Seat") and (descendant.Occupant and descendant.Occupant.Parent == t1.value54.Character) then
                                    v1264 = true

                                    break
                                end
                            end
                        elseif p108 == "Canoes" then
                            local Owner = child:FindFirstChild("Owner")

                            v1264 = Owner and Owner.Value == t1.value54
                        else
                            local v1268 = p108 == "Jets"

                            if not v1268 then
                                v1268 = p108 == "Helis"
                            end

                            if v1268 then
                                v1264 = child.Name == t1.value54.Name
                            end
                        end

                        if not v1264 then
                            table.insert(t1.value78[p108], child:Clone())
                            child:Destroy()
                        end
                    end
                end
            end

            task.wait(0.03)
        end
    end)

    return function(p110)
        u660 = p110

        if not p110 then
            for _, v in ipairs(t1.value78[p108]) do
                local v1272 = p109()

                if v1272 then
                    v.Parent = v1272
                end
            end

            t1.value78[p108] = {}
        end
    end
end
local AddToggle = v50.AddToggle
local v57 = v55("Vehicles", function()
    return t1.value79:FindFirstChild("Vehicles")
end)

AddToggle(v50, {
	Name = " مضاد فلنق السيارات",
	Default = false,
	Callback = v57
})
local AddToggle2 = v50.AddToggle
local v59 = v55("Canoes", function()
    local WorkspaceCom = t1.value79:FindFirstChild("WorkspaceCom")

    return WorkspaceCom and WorkspaceCom:FindFirstChild("001_CanoeStorage")
end)

AddToggle2(v50, {
	Name = " مضاد فلنق قارب الصيد",
	Default = false,
	Callback = v59
})
local AddToggle3 = v50.AddToggle
local v61 = v55("Jets", function()
    local WorkspaceCom = t1.value79:FindFirstChild("WorkspaceCom")

    if WorkspaceCom and WorkspaceCom:FindFirstChild("001_Airport") then
        local AirportHanger = WorkspaceCom["001_Airport"]:FindFirstChild("AirportHanger")

        if AirportHanger and AirportHanger:FindFirstChild("001_JetStorage") then
            return AirportHanger["001_JetStorage"]:FindFirstChild("JetAirport")
        end
    end
end)

AddToggle3(v50, {
	Name = " مضاد فلنق طائرة",
	Default = false,
	Callback = v61
})
local AddToggle4 = v50.AddToggle
local v63 = v55("Helis", function()
    local WorkspaceCom = t1.value79:FindFirstChild("WorkspaceCom")

    return WorkspaceCom and (WorkspaceCom:FindFirstChild("001_HeliStorage") and WorkspaceCom["001_HeliStorage"]:FindFirstChild("PoliceStationHeli"))
end)

AddToggle4(v50, {
	Name = " مضاد فلنق هيليكوبتر",
	Default = false,
	Callback = v63
})
local AddToggle5 = v50.AddToggle
local v65 = v55("Balls", function()
    local WorkspaceCom = t1.value79:FindFirstChild("WorkspaceCom")

    return WorkspaceCom and WorkspaceCom:FindFirstChild("001_SoccerBalls")
end)

AddToggle5(v50, {
	Name = " مضاد فلنق كرة",
	Default = false,
	Callback = v65
})
t1.value80 = false
v50:AddToggle({
	Name = " مضاد جلوس",
	Default = false,
	Callback = function(p111)
    t1.value80 = p111
    task.spawn(function()
        while t1.value80 and t1.value54.Character do
            local Humanoid = t1.value54.Character:FindFirstChildOfClass("Humanoid")

            if Humanoid then
                Humanoid:SetStateEnabled(Enum.HumanoidStateType.Seated, false)

                if Humanoid:GetState() == Enum.HumanoidStateType.Seated then
                    Humanoid:ChangeState(Enum.HumanoidStateType.GettingUp)
                end
            end

            task.wait(0.05)
        end

        if not t1.value80 then
            local v1274 = t1.value54.Character and t1.value54.Character:FindFirstChildOfClass("Humanoid")

            if v1274 then
                v1274:SetStateEnabled(Enum.HumanoidStateType.Seated, true)
            end
        end
    end)
end
})
v50:AddToggle({
	Name = " مضاد لاق الأدوات",
	Default = false,
	Callback = function(p112)
    if not p112 then
        return
    end

    local t55 = {}

    local function v669(p113)
        return p113:IsA("Tool")
    end
    local function v670(p114)
        local t56 = {}
        local t57 = {}

        if p114.Character then
            table.insert(t57, p114.Character)
        end

        local Backpack = p114:FindFirstChildOfClass("Backpack")

        if Backpack then
            table.insert(t57, Backpack)
        end

        local StarterGear = p114:FindFirstChild("StarterGear")

        if StarterGear then
            table.insert(t57, StarterGear)
        end

        for _, v in ipairs(t57) do
            local GetChildren = v.GetChildren

            for _, v13 in ipairs(GetChildren(v)) do
                if v669(v13) then
                    table.insert(t56, v13)
                end
            end
        end

        return t56
    end
    local function v671(p115)
        if p115 == nil then
            return
        end

        if t55[p115] then
            return
        end

        t55[p115] = true

        local v1287 = v670(p115)

        if #v1287 > 1 then
            for i = 2, #v1287 do
                pcall(function()
                    v1287[i]:Destroy()
                end)
            end
        end

        t55[p115] = false
    end
    local function v672(p116)
        task.defer(v671, p116)

        local function v1290(p117)
            task.delay(0.5, function()
                v671(p116)
            end)
            p117.ChildAdded:Connect(function(child)
                if v669(child) then
                    task.delay(0.1, function()
                        v671(p116)
                    end)
                end
            end)
        end

        if p116.Character then
            v1290(p116.Character)
        end

        p116.CharacterAdded:Connect(v1290)

        local v1291 = p116:FindFirstChild("Backpack") or p116:WaitForChild("Backpack", 10)

        if v1291 then
            v1291.ChildAdded:Connect(function(child)
                if v669(child) then
                    task.delay(0.1, function()
                        v671(p116)
                    end)
                end
            end)
        end

        local v1292 = p116:FindFirstChild("StarterGear") or p116:WaitForChild("StarterGear", 10)

        if v1292 then
            v1292.ChildAdded:Connect(function(child)
                if v669(child) then
                    task.delay(0.1, function()
                        v671(p116)
                    end)
                end
            end)
        end
    end

    t1.value57.PlayerAdded:Connect(v672)

    for _, player in ipairs(t1.value57:GetPlayers()) do
        v672(player)
    end

    task.spawn(function()
        while p112 do
            for _, player in ipairs(t1.value57:GetPlayers()) do
                v671(player)
            end

            task.wait(2)
        end
    end)
end
})
v50:AddToggle({
	Name = " مضاد الأبواب",
	Default = false,
	Callback = function(p118)
    if not _G.hiddenDoors then
        _G.hiddenDoors = {}
    end

    if p118 then
        _G.hiddenDoors = {}

        for _, descendant in ipairs(workspace:GetDescendants()) do
            if descendant:IsA("BasePart") and descendant.Name:lower():find("door") then
                local descendantTransparency = descendant.Transparency
                local CanCollide = descendant.CanCollide
                local CastShadow = descendant.CastShadow
                local t58 = {
						door = descendant,
						originalTransparency = descendantTransparency,
						originalCanCollide = CanCollide,
						originalCastShadow = CastShadow
					}

                descendant.Transparency = 1
                descendant.CanCollide = false
                descendant.CastShadow = false

                for _, child in ipairs(descendant:GetChildren()) do
                    if child:IsA("BasePart") then
                        child.Transparency = 1
                        child.CanCollide = false
                    elseif child:IsA("SurfaceGui") or child:IsA("BillboardGui") then
                        child.Enabled = false
                    end
                end

                table.insert(_G.hiddenDoors, t58)
            end
        end

        t1.value53("مضادات V2", "تم إخفاء الأبواب!", 3)

        return
    end

    for _, v in ipairs(_G.hiddenDoors or {}) do
        if v.door and v.door.Parent then
            v.door.Transparency = v.originalTransparency
            v.door.CanCollide = v.originalCanCollide
            v.door.CastShadow = v.originalCastShadow

            for _, child in ipairs(v.door:GetChildren()) do
                if child:IsA("BasePart") then
                    child.Transparency = 0
                    child.CanCollide = true
                elseif child:IsA("SurfaceGui") or child:IsA("BillboardGui") then
                    child.Enabled = true
                end
            end
        end
    end

    _G.hiddenDoors = {}
    t1.value53("مضادات V2", "تم استعادة الأبواب!", 3)
end
})
t1.value81 = false
t1.value82 = nil
local function v66()
    local Character = t1.value54.Character

    if not Character then
        return
    end

    local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

    if not HumanoidRootPart then
        return
    end

    t1.value82 = HumanoidRootPart.CFrame
    HumanoidRootPart.CFrame = HumanoidRootPart.CFrame * CFrame.new(0, -200, 0)
    task.wait(2)

    if HumanoidRootPart and t1.value82 then
        t1.value56:Create(HumanoidRootPart, TweenInfo.new(0.2, Enum.EasingStyle.Linear), {
			CFrame = t1.value82
		}):Play()
    end
end
t1.value55.Heartbeat:Connect(function()
    if not t1.value81 then
        return
    end

    local Character = t1.value54.Character

    if not Character then
        return
    end

    local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

    if not HumanoidRootPart then
        return
    end

    for _, player in ipairs(t1.value57:GetPlayers()) do
        local v694 = player ~= t1.value54

        if v694 then
            v694 = workspace:FindFirstChild(player.Name)
        end

        if not v694 then
            continue
        end

        local FollowCharacter = workspace[player.Name]:FindFirstChild("FollowCharacter")

        if FollowCharacter and FollowCharacter:FindFirstChild("Torso") and (FollowCharacter.Torso.Position - HumanoidRootPart.Position).Magnitude < 6 then
            v66()
            task.wait(2.5)

            return
        end
    end
end)
v50:AddToggle({
	Name = " مضاد الأطفال",
	Default = false,
	Callback = function(p119)
    t1.value81 = p119
end
})
local v67 = t1.value4:MakeTab({
	Title = "التلوين",
	Icon = "rbxassetid://76144975356652"
})
v67:AddSection({
	Name = "تلوين الادوات          ",
	Icon = "rbxassetid://10734950309"
})
local Players = game:GetService("Players")
local ReplicatedStorage3 = game:GetService("ReplicatedStorage")

t1.value83 = game:GetService("RunService")
t1.value84 = Players.LocalPlayer
t1.value85 = ReplicatedStorage3:WaitForChild("RE")
t1.value86 = false
t1.value87 = "BabyRattle"
t1.value88 = {
	["حق الطلاء"] = "PaintRoller",
	["حمرة"] = "Lipstick",
	["قوس حق الاسهم"] = "Bow",
	["راديو الاغاني"] = "Boombox",
	["تارموس"] = "Thermos",
	["دونات"] = "Donut",
	["مشط حق الاحصنة"] = "HorseBrush",
	["عصي"] = "GlowingBatons",
	["مكبر صوت"] = "Megaphone",
	["شمعة"] = "Candle",
	["مشعل"] = "GuardTorch",
	["لعبة الاطفال"] = "BabyRattle"
}
function t1.value89(p120)
    local v699 = t1.value84.Character or t1.value84.CharacterAdded:Wait()
    local Humanoid = v699:WaitForChild("Humanoid")
    local p120_2 = t1.value84.Backpack:WaitForChild(p120, 2)

    if p120_2 then
        p120_2.Parent = v699
        Humanoid:EquipTool(p120_2)
    end

    return p120_2
end
function t1.value90(p121)
    return Color3.fromHSV(p121 % 1, 1, 1)
end
v67:AddDropdown({
	Name = "اختيار الاداة",
	Default = "لعبة الاطفال",
	Options = {
		"حق الطلاء",
		"حمرة",
		"قوس حق الاسهم",
		"راديو الاغاني",
		"تارموس",
		"دونات",
		"مشط حق الاحصنة",
		"عصي",
		"مكبر صوت",
		"شمعة",
		"مشعل",
		"لعبة الاطفال"
	},
	Callback = function(p122)
    t1.value87 = t1.value88[p122]
end
})
v67:AddToggle({
	Name = "تلوين الاداة",
	Default = false,
	Callback = function(p123)
    t1.value86 = p123

    if not p123 then
        return
    end

    task.spawn(function()
        t1.value85:WaitForChild("1Clea1rTool1s"):FireServer("ClearAllTools")
        task.wait(0.2)
        t1.value85:WaitForChild("1Too1l"):InvokeServer("PickingTools", t1.value87)
        task.wait(0.3)
        if not t1.value89(t1.value87) then
            return
        end
        local SetColor = t1.value84.PlayerGui:WaitForChild("ToolGui"):WaitForChild("ToolSettings"):WaitForChild("Settings"):WaitForChild("PropsColor"):WaitForChild("SetColor")
        local n18 = 0
        local u1297 = t1.value90(0)
        local connection
        connection = t1.value83.RenderStepped:Connect(function(dt)
            if not t1.value86 then
                connection:Disconnect()

                return
            end

            local v1533 = dt * 0.3

            n18 += v1533

            local v1534 = t1.value90(n18)

            u1297 = u1297:Lerp(v1534, dt * 5)
            SetColor:FireServer(u1297)
        end)
    end)
end
})
v67:AddSection({
	Name = "تلوين الشعر          ",
	Icon = "rbxassetid://10734939942"
})
t1.value91 = {
	Color3.new(1, 1, 0),
	Color3.new(0, 0, 1),
	Color3.new(1, 0, 1),
	Color3.new(1, 1, 1),
	Color3.new(0, 1, 0),
	Color3.new(0.5, 0, 1),
	Color3.new(1, 0.647, 0),
	Color3.new(0, 1, 1)
}
t1.value92 = false
local function v70()
    local n19 = 1

    while t1.value92 and t1.value92 do
        local v705 = t1.value91[n19]
        local t59 = {
			[1] = "ChangeHairColor2",
			[2] = v705
		}
        local v707 = game:GetService("ReplicatedStorage"):WaitForChild("RE"):WaitForChild("1Max1y")
        local t60 = { unpack(t59) }

        v707:FireServer(v2(t60))
        wait(0.1)
        n19 = n19 % #t1.value91 + 1
    end
end
v67:AddToggle({
	Name = "تلوين الشعر",
	Description = "",
	Default = false,
	Callback = function(p124)
    t1.value92 = p124

    if t1.value92 then
        v70()
    end
end
})
v67:AddSection({
	Name = "تلوين الجسم          ",
	Icon = "rbxassetid://10709782758"
})
local ReplicatedStorage4 = game:GetService("ReplicatedStorage")

t1.value93 = game:GetService("Players").LocalPlayer
t1.value94 = game:GetService("RunService")
t1.value95 = ReplicatedStorage4:WaitForChild("Remotes"):WaitForChild("ChangeBodyColor")
t1.value96 = {
	"Pastel brown",
	"Pastel yellow",
	"Pastel blue",
	"Pastel green",
	"Pastel pink",
	"Really red",
	"Bright orange",
	"Bright blue",
	"Bright violet",
	"Bright green",
	"Bright yellow",
	"White",
	"Black",
	"Dark stone grey",
	"Medium stone grey",
	"Light stone grey",
	"Bright red",
	"Bright yellowish green",
	"Bright bluish green",
	"Bright purple",
	"Bright pink",
	"Reddish brown",
	"Earth green",
	"Sand red",
	"Sand blue",
	"Sand green",
	"Dark green",
	"Navy blue",
	"Toothpaste",
	"Cyan",
	"Hot pink",
	"Crimson",
	"Royal purple",
	"Neon orange",
	"Neon green",
	"Neon pink",
	"Neon blue",
	"Gold",
	"Bright gold",
	"New Yeller",
	"Dark orange",
	"Deep blue",
	"Maroon",
	"Bright maroon"
}
t1.value97 = false
v67:AddToggle({
	Name = "تلوين الجسم ",
	Default = false,
	Callback = function(p125)
    t1.value97 = p125

    if p125 then
        task.spawn(function()
            while t1.value97 do
                for _, v in ipairs(t1.value96) do
                    if not t1.value97 then
                        break
                    end

                    t1.value95:FireServer(v)
                    task.wait(0.3)
                end
            end
        end)
    end
end
})
t1.value98 = 1
v67:AddSlider({
	Name = "سرعة التلوين",
	Description = "",
	Min = 1,
	Max = 5,
	Increase = 1,
	Default = 3,
	Callback = function(p126)
    t1.value98 = p126
end
})
function t1.value99(p127)
    local v713 = tick() * p127 % 5 / 5

    return Color3.fromHSV(v713, 1, 1)
end
function t1.value100(p128, p129)
    local RE = game:GetService("ReplicatedStorage"):FindFirstChild("RE")
    local v717 = RE

    if v717 then
        v717 = RE:FindFirstChild(p128)
    end

    if v717 then
        pcall(function()
            RE[p128]:FireServer(unpack(p129))
        end)
    end
end
v67:AddToggle({
	Name = "تلوين سكوتر مال الاغاني او الدراجة",
	Description = "",
	Default = false
}):Callback(function(p130)
    getgenv().rgbBicicleta = p130
    task.spawn(function()
        while getgenv().rgbBicicleta do
            local value100 = t1.value100
            local value98 = t1.value98

            value100("1Player1sCa1r", {
				"NoMotorColor",
				t1.value99(value98)
			})
            task.wait(0.1)
        end
    end)
end)

local v72 = t1.value4:MakeTab({
	Title = " اغاني مجانية",
	Icon = "rbxassetid://76144975356652"
})
v72:AddSection({
	Name = "اغاني مايبيله جيمباس و الكل يسمعها ",
	Icon = "rbxassetid://10734934132"
})
t1.value101 = game:GetService("Players")
t1.value102 = game:GetService("ReplicatedStorage")
t1.value103 = {
	["ضحكة مال سوكونا"] = "116395665143666",
	["غوجو توسيع النطاق"] = "139787675170861",
	["صوت فايت مزعج شوي"] = "132639404905710",
	["صوت بنت انمي مشكوك فجد خالة عمتو"] = "109779146034241",
	["صوت بنت انمي ثاني"] = "102993326623397",
	["صوت اسد"] = "9126101636",
	["صوت بنت انمي 3"] = "103430674469051",
	["صوت انمي مزعج"] = "97551835622379",
	["صوت سلاح فري فاير"] = "6909650402",
	["جراني"] = "1591860354",
	["توجي"] = "132509237694639",
	["اوريتشيمارو "] = "135109036831389",
	["ضحكة سونيك"] = "7337298420",
	["ازعاج"] = "146563959",
	["اغنية فينوم"] = "8086734311",
	["صوت فينوم"] = "126497226413207",
	["صوت رعد"] = "6994934244",
	["جوجوتسو كايسن"] = "18985328962",
	["صوت ازعاج 2"] = "94692079812822",
	["صوت ازعاج 3"] = "89442290120460"
}
local t61 = {}
for k, _ in pairs(t1.value103) do
    table.insert(t61, k)
end
table.sort(t61)
t1.value104 = ""
t1.value105 = 1
t1.value106 = 1
t1.value107 = 100
t1.value108 = false
t1.value109 = nil
local AddDropdown = v72.AddDropdown
local v77 = t61[1]

AddDropdown(v72, {
	Name = "اختيار الصوت",
	Options = t61,
	Default = v77,
	Callback = function(p131)
    t1.value104 = t1.value103[p131]
end
})
v72:AddSlider({
	Name = "سرعة الصوت",
	Min = 0.5,
	Max = 2,
	Default = 1,
	Increment = 0.05,
	Callback = function(p132)
    t1.value105 = p132
end
})
v72:AddSlider({
	Name = "قوة الصوت",
	Min = 0,
	Max = 10,
	Default = 1,
	Increment = 0.1,
	Callback = function(p133)
    t1.value106 = p133
end
})
v72:AddSlider({
	Name = "مدى الصوت",
	Min = 10,
	Max = 300,
	Default = 100,
	Increment = 5,
	Callback = function(p134)
    t1.value107 = p134
end
})
function t1.value110()
    if t1.value104 == "" then
        if NotifyEnabled then
            redzlib:MakeNotify({
				Title = "LOC4T HUB",
				Text = "اختار صوت اول شي",
				Time = 2
			})
        end

        return
    end
    local value104 = t1.value104
    local v724 = t1.value102:FindFirstChild("1Gu1nSound1s", true)
    if v724 then
        v724:FireServer(workspace, value104, 1)
    end
    task.wait(0.2)
    local v725 = t1.value102.RE:FindFirstChild("1Gu1n")
    if not v725 then
        return
    end
    for v728, v729 in ipairs(t1.value101:GetPlayers()) do

        local v730 = v729
        local Character = v730.Character

        if Character and Character:FindFirstChild("HumanoidRootPart") then
            local HumanoidRootPart = Character.HumanoidRootPart

            task.spawn(function()
                local Sound = Instance.new("Sound")

                Sound.SoundId = "rbxassetid://" .. value104
                Sound.Volume = t1.value106
                Sound.PlaybackSpeed = t1.value105
                Sound.RollOffMaxDistance = t1.value107
                Sound.Looped = false
                Sound.Parent = HumanoidRootPart
                Sound:Play()
                Sound.Ended:Connect(function()
                    Sound:Destroy()
                end)
            end)
            task.spawn(function()
                pcall(function()
                    local _firesignal = firesignal
                    local OnClientEvent = v725.OnClientEvent
                    local unpack2 = table.unpack
                    local v1538 = v730
                    local v1539 = HumanoidRootPart
                    local v1540 = HumanoidRootPart
                    local vector3 = Vector3.new(0, -1, 0)
                    local new = Vector3.new
                    local t62 = {
						[1] = true
					}
                    local v1544 = new(0, 0, 0)
                    local v1545 = HumanoidRootPart
                    local v1546 = HumanoidRootPart
                    local v1547 = value104
                    local v1548 = value104
                    local vector3_3 = Vector3.new(0.25, 0.25, t1.value107)
                    local brickColor = BrickColor.new("Bright yellow")
                    local SmoothPlastic = Enum.Material.SmoothPlastic

                    _firesignal(OnClientEvent, unpack2({
						[1] = v1538,
						[2] = v1539,
						[3] = v1540,
						[4] = vector3,
						[5] = v1544,
						[6] = v1545,
						[7] = v1546,
						[8] = v1547,
						[9] = v1548,
						[10] = t62,
						[11] = {
							25,
							vector3_3,
							brickColor,
							0.25,
							SmoothPlastic,
							0.25
						},
						[12] = true,
						[13] = false
					}))
                end)
            end)
            task.spawn(function()
                pcall(function()
                    local v1552 = v725
                    local unpack3 = table.unpack
                    local v1554 = HumanoidRootPart
                    local v1555 = HumanoidRootPart
                    local vector3 = Vector3.new(0, -1, 0)
                    local vector3_4 = Vector3.new(0, 0, 0)
                    local v1558 = HumanoidRootPart
                    local t63 = {
						[1] = true
					}
                    local v1560 = HumanoidRootPart
                    local v1561 = value104
                    local v1562 = value104
                    local vector3_5 = Vector3.new(0.25, 0.25, t1.value107)
                    local brickColor = BrickColor.new("Bright yellow")
                    local SmoothPlastic = Enum.Material.SmoothPlastic

                    v1552:FireServer(unpack3({
						[1] = v1554,
						[2] = v1555,
						[3] = vector3,
						[4] = vector3_4,
						[5] = v1558,
						[6] = v1560,
						[7] = v1561,
						[8] = v1562,
						[9] = t63,
						[10] = {
							25,
							vector3_5,
							brickColor,
							0.25,
							SmoothPlastic,
							0.25
						},
						[11] = true,
						[12] = false
					}))
                end)
            end)
        end
    end
    if NotifyEnabled then
        redzlib:MakeNotify({
			Title = "LOC4T HUB",
			Text = "تم تشغيل الصوت",
			Time = 2
		})
    end
end
v72:AddButton({
	Name = "تشغيل مرة وحدة",
	Callback = function()
    t1.value110()
end
})
v72:AddToggle({
	Name = "سبام تشغيل",
	Default = false,
	Callback = function(p135)
    t1.value108 = p135

    if p135 then
        t1.value109 = task.spawn(function()
            while t1.value108 do
                t1.value110()
                task.wait(1)
            end
        end)

        return
    end

    if t1.value109 then
        task.cancel(t1.value109)
    end
end
})
SkyBoxTab = t1.value4:MakeTab({
	Title = "سكاء بوكس",
	Icon = "rbxassetid://76144975356652"
})
t1.value111 = {
	"Bright red",
	"Lime green",
	"Bright blue",
	"Bright yellow",
	"Bright cyan",
	"Hot pink",
	"Royal purple"
}
t1.value112 = false
function changeColor(p136)
    game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("ChangeBodyColor"):FireServer(unpack({ p136 }))
end
function toggleRGBCharacter(p137)
    t1.value112 = p137

    if t1.value112 then
        while t1.value112 do
            for _, v in ipairs(t1.value111) do
                if not t1.value112 then
                    return
                end

                changeColor(v)
                wait(0.5)
            end
        end
    end
end
SkyBoxTab:AddToggle({
	Name = "تلوين السكن",
	Description = "RGB",
	Default = false,
	Callback = function(p138)
    toggleRGBCharacter(p138)
end
})
_G.HideNukePlayers = false
_G.HiddenPlayers = {}
t1.value113 = game:GetService("Players")
t1.value114 = game:GetService("StarterGui")
t1.value115 = "rbxassetid://70883871260184"
t1.value116 = {
	["96655874457685"] = true,
	["123402086843885"] = true,
	["78300682916056"] = true,
	["86276701020724"] = true,
	["78409653958165"] = true,
	["120668655481073"] = true
}
function t1.value117(p139)
    if not _G.HideNukePlayers then
        return
    end
    if _G.HiddenPlayers[p139] then
        return
    end
    local Character = p139.Character
    if not Character then
        return
    end
    local Humanoid = Character:FindFirstChildOfClass("Humanoid")
    if not Humanoid then
        return
    end
    local v743 = false
    local PlayingAnimationTracks = Humanoid:GetPlayingAnimationTracks()
    for v747, v748 in pairs(PlayingAnimationTracks) do

        if v748.Animation and v748.Animation.AnimationId == t1.value115 then
            v743 = true
        end
    end
    local AppliedDescription = Humanoid:GetAppliedDescription()
    if AppliedDescription then
        local t64 = {
			AppliedDescription.Torso,
			AppliedDescription.RightArm,
			AppliedDescription.LeftArm,
			AppliedDescription.RightLeg,
			AppliedDescription.LeftLeg,
			AppliedDescription.Head
		}

        for _, v in pairs(t64) do
            if t1.value116[tostring(v)] then
                v743 = true
            end
        end
    end
    if not v743 then
        return
    end
    local t65 = {
		parts = {},
		tracks = {}
	}
    for v756, v757 in pairs(Character:GetDescendants()) do

        if v757:IsA("BasePart") then
            table.insert(t65.parts, v757)
            v757.LocalTransparencyModifier = 1
        end
    end
    for _, v in pairs(PlayingAnimationTracks) do
        if v.Animation and v.Animation.AnimationId == t1.value115 then
            table.insert(t65.tracks, v)
            v:Stop()
        end
    end
    _G.HiddenPlayers[p139] = t65
    local v760 = "تم اخفاء سكاء بوكس بتاع الاعب: " .. p139.Name
    pcall(function()
        t1.value114:SetCore("SendNotification", {
			Title = "مضاد الفلاش والسماء",
			Text = v760,
			Duration = 4
		})
    end)
end
SkyBoxTab:AddToggle({
	Name = "مضاد سكاء بوكس",
	Default = false,
	Callback = function(p140)
    _G.HideNukePlayers = p140

    if p140 then
        for _, player in ipairs(t1.value113:GetPlayers()) do
            local v764 = player

            if v764 ~= t1.value113.LocalPlayer then
                task.spawn(function()
                    local _ = v764.Character

                    repeat
                        task.wait()
                    until v764.Character

                    task.wait(1)
                    t1.value117(v764)
                end)
            end
        end

        return
    end

    for _, v in pairs(_G.HiddenPlayers) do
        local v767 = v

        pcall(function()

            for v1307, v1308 in pairs(v767.parts) do

                v1308.LocalTransparencyModifier = 0
            end
            for _, v19 in pairs(v767.tracks) do
                v19:Play()
            end
        end)
    end

    _G.HiddenPlayers = {}
end
})
t1.value113.PlayerAdded:Connect(function(player)
    player.CharacterAdded:Connect(function()
        task.wait(2)
        t1.value117(player)
    end)
end)

for _, player in ipairs(t1.value113:GetPlayers()) do
    local v80 = player

    if v80 ~= t1.value113.LocalPlayer then
        v80.CharacterAdded:Connect(function()
            task.wait(2)
            t1.value117(v80)
        end)
    end
end
t1.value118 = {
	["الافتراضي"] = nil,
	colkid = 98679358331654,
	["T-Shirt 3"] = 100000000000003,
	["T-Shirt 4"] = 100000000000004,
	["T-Shirt 5"] = 100000000000005,
	["T-Shirt 6"] = 100000000000006,
	["T-Shirt 7"] = 100000000000007,
	["T-Shirt 8"] = 100000000000008,
	["T-Shirt 9"] = 100000000000010,
	["T-Shirt 10"] = 100000000000010
}
t1.value119 = nil
function t1.value120(p141, p142)
    t1.value114:SetCore("SendNotification", {
		Title = p141,
		Text = p142,
		Duration = 4
	})
end
SkyBoxTab:AddDropdown({
	Name = "اختر التيشرت",
	Description = "Skybox FE",
	Options = {
		"الافتراضي",
		"colkid",
		"T-Shirt 3",
		"T-Shirt 4",
		"T-Shirt 5",
		"T-Shirt 6",
		"T-Shirt 7",
		"T-Shirt 8",
		"T-Shirt 9",
		"T-Shirt 10"
	},
	Default = "الافتراضي",
	Callback = function(p143)
    t1.value119 = t1.value118[p143]
    t1.value120("T-Shirt", "تم اختيار: " .. p143)
end
})
SkyboxActive = false
CurrentTrack = nil
RigidTrack = nil
SkyBoxTab:AddButton({
	Name = "سكاء بوكس بل تيشرت ال اختارته  او التيشرت الحالي",
	Description = "ملاحظه لو تبي تشيله اضغط مرا كمان علي زر",
	Callback = function()
    if SkyboxActive then
        if CurrentTrack then
            CurrentTrack:Stop(0.1)
            CurrentTrack = nil
        end

        if RigidTrack then
            RigidTrack:Stop(0.1)
            RigidTrack = nil
        end

        t1.value102.Remotes.ResetCharacterAppearance:FireServer()
        task.wait(0.3)
        char = t1.value93.Character

        if char then
            hum = char:FindFirstChildOfClass("Humanoid")

            if hum then
                hum.Health = 100
            end
        end

        SkyboxActive = false
        print("")

        return
    end
    WearShirt = t1.value102.Remotes:FindFirstChild("WearShirt")
    if t1.value119 and WearShirt then
        pcall(function()
            WearShirt:InvokeServer(t1.value119)
        end)
    end
    t1.value102.Remotes.ChangeCharacterBody:InvokeServer({ 100839513065430 })
    t1.value84 = t1.value93
    character = t1.value84.Character or t1.value84.CharacterAdded:Wait()
    humanoid = character:WaitForChild("Humanoid")
    function LoadTrack(p144)
        anim = Instance.new("Animation")
        anim.AnimationId = "rbxassetid://" .. p144
        track = humanoid:LoadAnimation(anim)
        track.Priority = Enum.AnimationPriority.Action4
        track:Play(0.1, 1, 1)
        CurrentTrack = track

        return track
    end
    LoadTrack(70883871260184)
    task.wait(0.5)
    plank = Instance.new("Animation")
    plank.AnimationId = "rbxassetid://3695333486"
    RigidTrack = humanoid:LoadAnimation(plank)
    RigidTrack.Priority = Enum.AnimationPriority.Movement
    RigidTrack:Play(0.1, 1, 0)
    SkyboxActive = true
    print("Skybox")
end
})
SkyBoxTab:AddButton({
	Name = "ترجيع الاسكن ",
	Callback = function()
    if CurrentTrack then
        CurrentTrack:Stop(0.1)
        CurrentTrack = nil
    end

    if RigidTrack then
        RigidTrack:Stop(0.1)
        RigidTrack = nil
    end

    SkyboxActive = false
    t1.value102.Remotes.ResetCharacterAppearance:FireServer()
    task.wait(0.3)
    char = t1.value93.Character

    if char then
        hum = char:FindFirstChildOfClass("Humanoid")

        if hum then
            hum.Health = 100
        end
    end

    print("")
end
})
t1.value121 = 1
t1.value122 = false
t1.value123 = nil
SkyBoxTab:AddSlider({
	Name = "اختار سرعة دوران",
	Min = 1,
	Max = 100,
	Default = 1,
	Increment = 1,
	ValueName = "Speed",
	Callback = function(p145)
    t1.value121 = p145
end
})
SkyBoxTab:AddToggle({
	Name = "اضغط لي تشغيل الدوران",
	Default = false,
	Callback = function(p146)
    t1.value122 = p146

    if t1.value122 then
        if t1.value123 then
            t1.value123:Disconnect()
        end

        t1.value123 = t1.value94.Heartbeat:Connect(function(dt)
            local Character = t1.value93.Character

            if not Character then
                return
            end

            local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

            if not HumanoidRootPart then
                return
            end

            local v1315 = t1.value121 * 3.141592653589793 * dt

            HumanoidRootPart.CFrame = HumanoidRootPart.CFrame * CFrame.Angles(0, v1315, 0)
        end)

        return
    end

    if t1.value123 then
        t1.value123:Disconnect()
    end
end
})
SkyBoxTab:AddSection({ "سكاء بوكس اقوي من حق الاول" })
SkyBoxTab:AddToggle({
	Name = "سكاء بوكس  قوي مرااااا",
	Default = false,
	Callback = function(p147)
    t1.value113 = game:GetService("Players")

    local ReplicatedStorage5 = game:GetService("ReplicatedStorage")

    t1.value93 = t1.value113.LocalPlayer
    ChangeCharacterBody = ReplicatedStorage5:WaitForChild("Remotes"):WaitForChild("ChangeCharacterBody")
    ANIM_ID = "rbxassetid://70883871260184"
    t1.value116 = {
			96655874457685,
			123402086843885,
			78300682916056,
			86276701020724,
			78409653958165,
			120668655481070
		}

    if not _G.NukeSkyboxV2 then
        _G.NukeSkyboxV2 = {}
    end

    data = _G.NukeSkyboxV2

    function getHumanoid()
        local Character = t1.value93.Character

        if not Character then
            return
        end

        return Character:FindFirstChildOfClass("Humanoid")
    end

    if p147 then
        humanoid = getHumanoid()

        if not humanoid then
            return
        end

        d = humanoid:GetAppliedDescription()
        data.savedBody = {
				d.Torso,
				d.RightArm,
				d.LeftArm,
				d.RightLeg,
				d.LeftLeg,
				d.Head
			}
        pcall(function()
            ChangeCharacterBody:InvokeServer(t1.value116)
        end)
        task.wait(0.3)
        anim = Instance.new("Animation")
        anim.AnimationId = ANIM_ID
        data.track = humanoid:LoadAnimation(anim)
        data.track.Priority = Enum.AnimationPriority.Action4
        data.track:Play(0.1, 1, 1)
        data.track:AdjustSpeed(0.0001)

        return
    end

    if data.track then
        pcall(function()
            data.track:Stop()
            data.track:Destroy()
        end)
        data.track = nil
    end

    if data.savedBody then
        task.wait(0.2)
        pcall(function()
            ChangeCharacterBody:InvokeServer(data.savedBody)
        end)
    end
end
})
SkyBoxTab:AddToggle({
	Name = "فلاش يعمي عين الفي سرفر حرفيا",
	Default = false,
	Callback = function(p148)
    t1.value113 = game:GetService("Players")

    local ReplicatedStorage6 = game:GetService("ReplicatedStorage")

    t1.value93 = t1.value113.LocalPlayer
    ChangeCharacterBody = ReplicatedStorage6:WaitForChild("Remotes"):WaitForChild("ChangeCharacterBody")
    ANIM_ID = "rbxassetid://70883871260184"
    t1.value116 = {
			96655874457685,
			123402086843880,
			78300682916056,
			86276701020724,
			78409653958165,
			120668655481070
		}

    if not _G.NukeSkyboxV2 then
        _G.NukeSkyboxV2 = {}
    end

    data = _G.NukeSkyboxV2

    function getHumanoid()
        local Character = t1.value93.Character

        if not Character then
            return
        end

        return Character:FindFirstChildOfClass("Humanoid")
    end

    if p148 then
        humanoid = getHumanoid()

        if not humanoid then
            return
        end

        d = humanoid:GetAppliedDescription()
        data.savedBody = {
				d.Torso,
				d.RightArm,
				d.LeftArm,
				d.RightLeg,
				d.LeftLeg,
				d.Head
			}
        pcall(function()
            ChangeCharacterBody:InvokeServer(t1.value116)
        end)
        task.wait(0.3)
        anim = Instance.new("Animation")
        anim.AnimationId = ANIM_ID
        data.track = humanoid:LoadAnimation(anim)
        data.track.Priority = Enum.AnimationPriority.Action4
        data.track:Play(0.1, 1, 1)
        data.track:AdjustSpeed(_G.NukeAnimSpeed or 0.01)

        return
    end

    if data.track then
        pcall(function()
            data.track:Stop()
            data.track:Destroy()
        end)
        data.track = nil
    end

    if data.savedBody then
        task.wait(0.2)
        pcall(function()
            ChangeCharacterBody:InvokeServer(data.savedBody)
        end)
    end
end
})
_G.NukeAnimSpeed = 0.01
SkyBoxTab:AddSlider({
	Name = "سرعة الفلاش",
	Min = 1,
	Max = 2000,
	Default = 1,
	Increment = 1,
	ValueName = "Speed",
	Callback = function(p149)
    local v780 = p149 / 1000

    _G.NukeAnimSpeed = v780

    if _G.NukeSkyboxV2 and _G.NukeSkyboxV2.track then
        pcall(function()
            _G.NukeSkyboxV2.track:AdjustSpeed(v780)
        end)
    end
end
})
SkyBoxTab:AddSection({ " " })

local v81 = t1.value4:MakeTab({
	Title = "المتعة",
	Icon = "rbxassetid://76144975356652"
})
v81:AddSection({ "كره تلف حوليك          " })
OrbitSettings = {
	Speed = 2,
	Distance = 6,
	Height = 0,
	Fling = false
}
v81:AddSlider({
	Name = "سرعة دوران الكرة",
	Min = 1,
	Max = 20,
	Default = 2,
	Callback = function(p150)
    OrbitSettings.Speed = p150
end
})
v81:AddSlider({
	Name = "بعد الكرة",
	Min = 1,
	Max = 20,
	Default = 6,
	Callback = function(p151)
    OrbitSettings.Distance = p151
end
})
v81:AddSlider({
	Name = "ارتفاع الكرة",
	Min = -10,
	Max = 10,
	Default = 0,
	Callback = function(p152)
    OrbitSettings.Height = p152
end
})
v81:AddToggle({
	Name = "فعل ميزة الفلنق من يقربو عليك",
	Default = false,
	Callback = function(p153)
    OrbitSettings.Fling = p153
end
})
t1.value124 = game:GetService("Players")

local UserInputService = game:GetService("UserInputService")

t1.value125 = game:GetService("Workspace")

local LocalPlayer = t1.value124.LocalPlayer
t1.value126 = nil
t1.value127 = LocalPlayer
t1.value128 = nil
t1.value128 = nil
t1.value126 = nil
t1.value129 = false
function t1.value130()
    if t1.value128 then
        t1.value128:Disconnect()
        t1.value128 = nil
    end

    if t1.value126 then
        t1.value126:Destroy()
        t1.value126 = nil
    end
end
function orbitBall(p154, p155)
    if not p154 or not p154:FindFirstChild("HumanoidRootPart") then
        return
    end

    local LocalPlayer3 = game:GetService("Players").LocalPlayer
    local v788 = LocalPlayer3.Character or LocalPlayer3.CharacterAdded:Wait()
    local Backpack = LocalPlayer3:WaitForChild("Backpack")
    local v790 = workspace:WaitForChild("WorkspaceCom"):WaitForChild("001_SoccerBalls")

    if not Backpack:FindFirstChild("SoccerBall") and not v788:FindFirstChild("SoccerBall") then
        game:GetService("ReplicatedStorage").RE:FindFirstChild("1Too1l"):InvokeServer("PickingTools", "SoccerBall")
    end

    if not Backpack:FindFirstChild("SoccerBall") then
        v788:FindFirstChild("SoccerBall")
    end

    repeat
        task.wait()
    until Backpack:FindFirstChild("SoccerBall") or v788:FindFirstChild("SoccerBall")

    local SoccerBall = Backpack:FindFirstChild("SoccerBall")

    if SoccerBall then
        SoccerBall.Parent = v788
    end

    v790:FindFirstChild("Soccer" .. LocalPlayer3.Name)

    repeat
        task.wait()
    until v790:FindFirstChild("Soccer" .. LocalPlayer3.Name)

    local v792 = v790:FindFirstChild("Soccer" .. LocalPlayer3.Name)

    if not v792 then
        return
    end

    v792.Name = p155
    v792.CanCollide = false
    v792.Massless = true
    v792.CustomPhysicalProperties = PhysicalProperties.new(0.0001, 0, 0)

    if v792:FindFirstChild("FlingPower") then
        v792.FlingPower:Destroy()
    end

    if OrbitSettings.Fling then
        local BodyVelocity = Instance.new("BodyVelocity")

        BodyVelocity.Name = "FlingPower"
        BodyVelocity.Velocity = Vector3.new(900000000, 900000000, 900000000)
        BodyVelocity.MaxForce = Vector3.new(1e999, 1e999, 1e999)
        BodyVelocity.P = 1e999
        BodyVelocity.Parent = v792
    end

    local BindableEvent = Instance.new("BindableEvent")

    BindableEvent.Name = p155 .. "Loop"
    BindableEvent.Parent = v788
    task.spawn(function()
        while true do
            local BindableEventParent = BindableEvent.Parent

            if BindableEventParent then
                BindableEventParent = v792

                if BindableEventParent then
                    BindableEventParent = v792.Parent and (p154 and p154.Parent)
                end
            end

            if not BindableEventParent then
                break
            end

            local v1319 = tick() * OrbitSettings.Speed
            local cFrame = CFrame.new(math.cos(v1319) * OrbitSettings.Distance, OrbitSettings.Height, math.sin(v1319) * OrbitSettings.Distance)

            v792.CFrame = p154.HumanoidRootPart.CFrame * cFrame
            task.wait(0.016666666666667)
        end
    end)
end
local function v84(p156)
    if not t1.value129 then
        return
    end

    t1.value130()

    if not p156 or not p156:FindFirstChild("HumanoidRootPart") then
        return
    end

    local OrbitTarget = t1.value125.WorkspaceCom["001_SoccerBalls"]:FindFirstChild("OrbitTarget")

    if not OrbitTarget then
        return
    end

    t1.value126 = OrbitTarget:Clone()
    t1.value126.Name = "OrbitTargetLoop"
    t1.value126.Parent = t1.value125

    local n20 = 0
    local Distance = OrbitSettings.Distance
    local OrbitSettingsSpeed = OrbitSettings.Speed
    local OrbitSettingsHeight = OrbitSettings.Height

    game:GetService("RunService").Heartbeat:Connect(function(dt)
        n20 += OrbitSettingsSpeed * dt

        local HumanoidRootPart = p156:FindFirstChild("HumanoidRootPart")

        if HumanoidRootPart then
            t1.value126.Position = HumanoidRootPart.Position + Vector3.new(math.cos(n20) * Distance, OrbitSettingsHeight, math.sin(n20) * Distance)
        end
    end)
end
UserInputService.InputBegan:Connect(function(input, gameProcessed)
    if gameProcessed then
        return
    end

    if t1.value129 and input.UserInputType == Enum.UserInputType.Touch then
        local inputPosition = input.Position
        local v804 = t1.value125.CurrentCamera:ScreenPointToRay(inputPosition.X, inputPosition.Y)
        local part, _ = t1.value125:FindPartOnRayWithIgnoreList(v804, { t1.value127.Character })

        if part and part.Parent then
            for _, player in ipairs(t1.value124:GetPlayers()) do
                if player.Character and player.Character:FindFirstChild("HumanoidRootPart") and part:IsDescendantOf(player.Character) then
                    v84(player.Character)

                    return
                end
            end
        end
    end
end)
v81:AddToggle({
	Name = "تفعيل هالة الكرة دون فلنق",
	Default = false,
	Callback = function(p157)
    local Character = t1.value127.Character
    local v811 = Character and Character:FindFirstChild("OrbitBallLoop")

    if p157 then
        orbitBall(Character, "OrbitBall")

        return
    end

    if v811 then
        v811:Destroy()

        local OrbitBall = workspace.WorkspaceCom["001_SoccerBalls"]:FindFirstChild("OrbitBall")

        if OrbitBall then
            OrbitBall:Destroy()
        end
    end
end
})
v81:AddToggle({
	Name = "المس اي لاعب لتفعيل هالة الكرة عليه",
	Default = false,
	Callback = function(p158)
    t1.value129 = p158

    if not p158 then
        t1.value130()
    end
end
})
v81:AddSection({
	Name = "كشف اللاعبين          ",
	Icon = "rbxassetid://10723346959"
})
t1.value131 = false
t1.value132 = Instance.new("Folder", workspace)
t1.value132.Name = "BloodESP"
t1.value133 = nil
function t1.value133(p159)
    if not p159.Character or not p159.Character:FindFirstChild("Head") then
        return
    end

    local BillboardGui = Instance.new("BillboardGui")

    BillboardGui.Name = "ESPTag"
    BillboardGui.AlwaysOnTop = true
    BillboardGui.Size = UDim2.new(0, 200, 0, 50)
    BillboardGui.StudsOffset = Vector3.new(0, 3, 0)
    BillboardGui.Adornee = p159.Character.Head
    BillboardGui.Parent = t1.value132

    local TextLabel = Instance.new("TextLabel")

    TextLabel.Size = UDim2.new(1, 0, 0.33, 0)
    TextLabel.BackgroundTransparency = 1
    TextLabel.Text = p159.Name
    TextLabel.TextColor3 = Color3.fromRGB(255, 0, 0)
    TextLabel.TextStrokeColor3 = Color3.fromRGB(139, 0, 0)
    TextLabel.TextStrokeTransparency = 0
    TextLabel.Font = Enum.Font.GothamBold
    TextLabel.TextScaled = true
    TextLabel.Parent = BillboardGui

    local TextLabel2 = Instance.new("TextLabel")

    TextLabel2.Size = UDim2.new(1, 0, 0.33, 0)
    TextLabel2.Position = UDim2.new(0, 0, 0.33, 0)
    TextLabel2.BackgroundTransparency = 1

    local AccountAge = p159.AccountAge

    TextLabel2.Text = "عمر: " .. if not (AccountAge >= 365) then AccountAge .. " يوم" else math.floor(AccountAge / 365) .. " سنة"
    TextLabel2.TextColor3 = Color3.fromRGB(255, 0, 0)
    TextLabel2.TextStrokeColor3 = Color3.fromRGB(139, 0, 0)
    TextLabel2.TextStrokeTransparency = 0
    TextLabel2.Font = Enum.Font.Gotham
    TextLabel2.TextScaled = true
    TextLabel2.Parent = BillboardGui

    local TextLabel3 = Instance.new("TextLabel")

    TextLabel3.Size = UDim2.new(1, 0, 0.33, 0)
    TextLabel3.Position = UDim2.new(0, 0, 0.66, 0)
    TextLabel3.BackgroundTransparency = 1
    TextLabel3.TextColor3 = Color3.fromRGB(255, 0, 0)
    TextLabel3.TextStrokeColor3 = Color3.fromRGB(139, 0, 0)
    TextLabel3.TextStrokeTransparency = 0
    TextLabel3.Font = Enum.Font.Gotham
    TextLabel3.TextScaled = true
    TextLabel3.Parent = BillboardGui
    task.spawn(function()
        while true do
            local BillboardGuiParent = BillboardGui.Parent

            if BillboardGuiParent then
                BillboardGuiParent = t1.value131 and (p159.Character and p159.Character:FindFirstChild("Head"))
            end

            if not BillboardGuiParent then
                break
            end

            TextLabel3.Text = "البعد: " .. math.floor((game.Players.LocalPlayer.Character.Head.Position - p159.Character.Head.Position).Magnitude) .. "m"

            local v1324 = math.sin(tick() * 5) * 0.5 + 0.5

            TextLabel.TextTransparency = v1324 * 0.5
            TextLabel2.TextTransparency = v1324 * 0.5
            TextLabel3.TextTransparency = v1324 * 0.5
            TextLabel.TextStrokeTransparency = v1324 * 0.2
            task.wait(0.05)
        end

        BillboardGui:Destroy()
    end)
end
function t1.value134()
    for _, player in ipairs(game.Players:GetPlayers()) do
        if player ~= game.Players.LocalPlayer then
            t1.value133(player)
        end
    end

    game.Players.PlayerAdded:Connect(function(player)
        task.wait(2)

        if t1.value131 then
            t1.value133(player)
        end
    end)
end
function t1.value135()
    for _, child in ipairs(t1.value132:GetChildren()) do
        child:Destroy()
    end
end
v81:AddToggle({
	Name = "كشف اللاعبين",
	Default = false,
	Callback = function(p160)
    t1.value131 = p160

    if p160 then
        t1.value134()

        return
    end

    t1.value135()
end
})
t1.value136 = game:GetService("Players")
t1.value137 = t1.value136.LocalPlayer
t1.value138 = false
t1.value139 = Instance.new("Folder", workspace)
t1.value139.Name = "BloodHitboxESP"
t1.value140 = nil
function t1.value140(p161)
    if not p161 or not p161:FindFirstChild("HumanoidRootPart") then
        return
    end

    local SelectionBox = Instance.new("SelectionBox")

    SelectionBox.Name = "HitboxESP"
    SelectionBox.Adornee = p161
    SelectionBox.LineThickness = 0.15
    SelectionBox.Color3 = Color3.fromRGB(255, 0, 0)
    SelectionBox.SurfaceColor3 = Color3.fromRGB(255, 0, 0)
    SelectionBox.SurfaceTransparency = 0.7
    SelectionBox.Parent = t1.value139
    task.spawn(function()
        while SelectionBox.Parent and (t1.value138 and p161.Parent) do
            local v1326 = math.sin(tick() * 8) * 0.4 + 0.4

            SelectionBox.SurfaceTransparency = v1326
            SelectionBox.LineTransparency = v1326 * 0.5
            task.wait(0.03)
        end

        SelectionBox:Destroy()
    end)
end
function t1.value141()
    for _, player in ipairs(t1.value136:GetPlayers()) do
        if player ~= t1.value137 and player.Character then
            t1.value140(player.Character)
        end
    end

    t1.value136.PlayerAdded:Connect(function(player)
        player.CharacterAdded:Connect(function(character2)
            task.wait(1)

            if t1.value138 then
                t1.value140(character2)
            end
        end)
    end)
end
function t1.value142()
    for _, child in ipairs(t1.value139:GetChildren()) do
        child:Destroy()
    end
end
v81:AddToggle({
	Name = "V2 كشف ",
	Default = false,
	Callback = function(p162)
    t1.value138 = p162

    if p162 then
        t1.value141()

        return
    end

    t1.value142()
end
})
v81:AddSection({
	Name = "سبام قوارب في البداية          ",
	Icon = "rbxassetid://10734941354"
})
v81:AddToggle({
	Name = "سبام قوارب في البداية",
	Default = false,
	Callback = function(p163)
    getgenv().Toggle = p163

    if p163 then
        local LocalPlayer4 = game:GetService("Players").LocalPlayer
        local v836 = LocalPlayer4.Character or LocalPlayer4.CharacterAdded:Wait()
        local HumanoidRootPart = v836:WaitForChild("HumanoidRootPart")
        local Humanoid = v836:FindFirstChildOfClass("Humanoid")
        local Button = workspace:WaitForChild("WorkspaceCom"):WaitForChild("001_CanoeCloneButton").Button

        task.spawn(function()
            while getgenv().Toggle do
                task.wait()
                HumanoidRootPart.CFrame = Button.CFrame
                task.wait(0.1)
                fireclickdetector(Button:FindFirstChild("ClickDetector"))
                task.wait(0.5)

                local Canoe = workspace.WorkspaceCom["001_CanoeStorage"]:FindFirstChild("Canoe")

                if Canoe and Canoe:FindFirstChild("VehicleSeat") then
                    local _ = Humanoid.Sit

                    repeat
                        HumanoidRootPart.CFrame = Canoe.VehicleSeat.CFrame + Vector3.new(0, math.random(-1, 1), 0)
                        task.wait()
                    until Humanoid.Sit

                    task.wait(0.2)
                    HumanoidRootPart.CFrame = CFrame.new(math.random(-40, 40), 4.549, math.random(-40, 40))
                    task.wait(0.2)
                    Humanoid.Sit = false
                    Canoe.Name = "CanoeMolestaHavens"
                end
            end
        end)
    end
end
})
v81:AddSection({ "اعصار السفينة" })
v81:AddToggle({
	Name = "[انتظر ينزلك او لو مانزلك انزل بنفسك] سفينه تقعد تلف بل بدايه",
	Default = false,
	Callback = function(p164)
    if p164 then
        loadstring(game:HttpGet("https://raw.githubusercontent.com/Mohammed-12344/-/refs/heads/main/FKZXK.LUA"))()

        return
    end

    local v841 = game:GetService("ReplicatedStorage"):WaitForChild("RE"):WaitForChild("1Ca1r")
    local t66 = { unpack({ "DeleteAllVehicles" }) }

    v841:FireServer(v2(t66))
end
})
pcall(function()
    local v843 = t1.value4:MakeTab({
		Title = "الجوده",
		Icon = "rbxassetid://76144975356652"
	})
    v843:AddSection({
		Name = "تحسين الجودة لك (Shaders)"
	})
    v843:AddButton({
		Name = "تشغيل الشيدر (Shaders)",
		Callback = function()
        pcall(function()
            t1.value4:Dialog({
					Title = "ما هو هذا السكربت؟",
					Text = "بيحسن لك الجوده و كمان بيحطلك شيدر اصوات",
					Options = {
						{
							"تشغيل",
							function()
                pcall(function()
                    loadstring(game:HttpGet("https://raw.githubusercontent.com/realgengar/scripts/refs/heads/main/free", true))()

                    local s30 = "REX-M"

                    pcall(function()
                        t1.value114:SetCore("SendNotification", {
											Title = "مضاد الفلاش والسماء",
											Text = s30,
											Duration = 4
										})
                    end)
                end)
            end
						},
						{
							"إلغاء",
							function()
            end
						}
					}
				})
        end)
    end
	})
    local Lighting = game:GetService("Lighting")
    local u845 = Lighting
    local function v846()
        pcall(function()
            for _, child in pairs(u845:GetChildren()) do
                if child:IsA("PostEffect") or (child:IsA("Sky") or child:IsA("Atmosphere")) then
                    child:Destroy()
                end
            end

            u845.Brightness = 2
            u845.ClockTime = 14
            u845.FogEnd = 100000
            u845.ExposureCompensation = 0
            u845.OutdoorAmbient = Color3.fromRGB(128, 128, 128)
            u845.GlobalShadows = true
        end)
    end
    local function v847(p165, p166)
        local u1334 = p165
        local u1333 = p166

        return pcall(function()
            local v1571 = Instance.new(u1334, u845)

            for k, v in pairs(u1333) do
                v1571[k] = v
            end

            return v1571
        end)
    end
    v843:AddSection({
		Name = "☀\239\184\143 تحسين الظلال والأشعة"
	})
    local u848
    v843:AddDropdown({
		Name = "اختار التاثير",
		Options = {
			"❌ إعادة تعيين الظلال",
			"أشعة إلهية",
			"شمس ذهبية",
			"ظلال قوية",
			"بدون ظلال (رفع FPS)",
			"توهج ناعم",
			"ضوء سماوي",
			"ظلال داكنة",
			"ضوء حجمي",
			"وميض العدسة",
			"أشعة الغروب",
			"تعريض ضوئي عالي"
		},
		Default = "",
		Callback = function(p167)
        u848 = p167
    end
	})
    v843:AddButton({
		Name = "تشغيل التاثير",
		Callback = function()
        pcall(function()
            if u848 == "❌ إعادة تعيين الظلال" then
                for _, child in pairs(u845:GetChildren()) do
                    if child:IsA("SunRaysEffect") or child:IsA("BloomEffect") then
                        child:Destroy()
                    end
                end

                u845.GlobalShadows = true
            elseif u848 == "أشعة إلهية" then
                local t67 = {
						Intensity = 0.2,
						Spread = 1
					}
                local s31 = "SunRaysEffect"
                local u1577 = t67
                pcall(function()
                    local v1735 = Instance.new(s31, u845)

                    for k, v in pairs(u1577) do
                        v1735[k] = v
                    end

                    return v1735
                end)
            elseif u848 == "شمس ذهبية" then
                local t68 = {
						Intensity = 0.15
					}
                local s32 = "SunRaysEffect"
                local u1580 = t68
                pcall(function()
                    local v1738 = Instance.new(s32, u845)

                    for k, v in pairs(u1580) do
                        v1738[k] = v
                    end

                    return v1738
                end)
                v847("ColorCorrectionEffect", {
						TintColor = Color3.fromRGB(255, 230, 150)
					})
            elseif u848 == "ظلال قوية" then
                u845.GlobalShadows = true
                u845.Brightness = 3
            elseif u848 == "بدون ظلال (رفع FPS)" then
                u845.GlobalShadows = false
            elseif u848 == "توهج ناعم" then
                local t69 = {
						Intensity = 1,
						Size = 20,
						Threshold = 0.5
					}
                local s33 = "BloomEffect"
                local u1583 = t69
                pcall(function()
                    local v1741 = Instance.new(s33, u845)

                    for k, v in pairs(u1583) do
                        v1741[k] = v
                    end

                    return v1741
                end)
            elseif u848 == "ضوء سماوي" then
                local t70 = {
						Intensity = 0.4
					}
                local s34 = "SunRaysEffect"
                local u1586 = t70
                pcall(function()
                    local v1744 = Instance.new(s34, u845)

                    for k, v in pairs(u1586) do
                        v1744[k] = v
                    end

                    return v1744
                end)
                local t71 = {
						Intensity = 0.8
					}
                local s35 = "BloomEffect"
                local u1589 = t71
                pcall(function()
                    local v1747 = Instance.new(s35, u845)

                    for k, v in pairs(u1589) do
                        v1747[k] = v
                    end

                    return v1747
                end)
            elseif u848 == "ظلال داكنة" then
                u845.OutdoorAmbient = Color3.new(0, 0, 0)
            elseif u848 == "ضوء حجمي" then
                local t72 = {
						Density = 0.3,
						Glare = 0.5,
						Haze = 1
					}
                local s36 = "Atmosphere"
                local u1592 = t72
                pcall(function()
                    local v1750 = Instance.new(s36, u845)

                    for k, v in pairs(u1592) do
                        v1750[k] = v
                    end

                    return v1750
                end)
            elseif u848 == "وميض العدسة" then
                local t73 = {
						Intensity = 0.1
					}
                local s37 = "SunRaysEffect"
                local u1595 = t73
                pcall(function()
                    local v1753 = Instance.new(s37, u845)

                    for k, v in pairs(u1595) do
                        v1753[k] = v
                    end

                    return v1753
                end)
                local t74 = {
						Intensity = 2,
						Threshold = 0.9
					}
                local s38 = "BloomEffect"
                local u1598 = t74
                pcall(function()
                    local v1756 = Instance.new(s38, u845)

                    for k, v in pairs(u1598) do
                        v1756[k] = v
                    end

                    return v1756
                end)
            elseif u848 == "أشعة الغروب" then
                u845.ClockTime = 17.8
                local t75 = {
						Intensity = 0.25
					}
                local s39 = "SunRaysEffect"
                local u1601 = t75
                pcall(function()
                    local v1759 = Instance.new(s39, u845)

                    for k, v in pairs(u1601) do
                        v1759[k] = v
                    end

                    return v1759
                end)
            elseif u848 == "تعريض ضوئي عالي" then
                u845.ExposureCompensation = 1.5
            end

            local s40 = "REX-M"

            pcall(function()
                t1.value114:SetCore("SendNotification", {
						Title = "مضاد الفلاش والسماء",
						Text = s40,
						Duration = 4
					})
            end)
        end)
    end
	})
    v843:AddSection({
		Name = "اضاءه RTX"
	})
    local u849
    v843:AddDropdown({
		Name = "اختار التاثير",
		Options = {
			"❌ إزالة جميع التأثيرات",
			"RTX متقدم",
			"ألوان زاهية",
			"حلم ناعم",
			"صباح بارد",
			"الساعة الذهبية",
			"سينمائي 4K",
			"حرارة الصيف",
			"ظلال عميقة",
			"ليل مضيء",
			"سماء وردية",
			"تشبع ألوان قوي"
		},
		Default = "",
		Callback = function(p168)
        u849 = p168
    end
	})
    v843:AddButton({
		Name = "تشغيل التاثير",
		Callback = function()
        pcall(function()
            if u849 == "❌ إزالة جميع التأثيرات" then
                v846()
            elseif u849 == "RTX متقدم" then
                v846()
                local t76 = {
						Saturation = 0.2,
						Contrast = 0.2
					}
                local s41 = "ColorCorrectionEffect"
                local u1605 = t76
                pcall(function()
                    local v1762 = Instance.new(s41, u845)

                    for k, v in pairs(u1605) do
                        v1762[k] = v
                    end

                    return v1762
                end)
                local t77 = {
						Intensity = 0.5
					}
                local s42 = "BloomEffect"
                local u1608 = t77
                pcall(function()
                    local v1765 = Instance.new(s42, u845)

                    for k, v in pairs(u1608) do
                        v1765[k] = v
                    end

                    return v1765
                end)
                local t78 = {
						Intensity = 0.1
					}
                local s43 = "SunRaysEffect"
                local u1611 = t78
                pcall(function()
                    local v1768 = Instance.new(s43, u845)

                    for k, v in pairs(u1611) do
                        v1768[k] = v
                    end

                    return v1768
                end)
            elseif u849 == "ألوان زاهية" then
                v846()
                local t79 = {
						Saturation = 1.5
					}
                local s44 = "ColorCorrectionEffect"
                local u1614 = t79
                pcall(function()
                    local v1771 = Instance.new(s44, u845)

                    for k, v in pairs(u1614) do
                        v1771[k] = v
                    end

                    return v1771
                end)
            elseif u849 == "حلم ناعم" then
                v846()
                local t80 = {
						Intensity = 1,
						Size = 50
					}
                local s45 = "BloomEffect"
                local u1617 = t80
                pcall(function()
                    local v1774 = Instance.new(s45, u845)

                    for k, v in pairs(u1617) do
                        v1774[k] = v
                    end

                    return v1774
                end)
            elseif u849 == "صباح بارد" then
                v846()
                u845.ClockTime = 7
                v847("ColorCorrectionEffect", {
						TintColor = Color3.fromRGB(200, 230, 255)
					})
            elseif u849 == "الساعة الذهبية" then
                v846()
                u845.ClockTime = 17.5
                local t81 = {
						Saturation = 0.5
					}
                local s46 = "ColorCorrectionEffect"
                local u1620 = t81
                pcall(function()
                    local v1777 = Instance.new(s46, u845)

                    for k, v in pairs(u1620) do
                        v1777[k] = v
                    end

                    return v1777
                end)
            elseif u849 == "سينمائي 4K" then
                v846()
                local t82 = {
						Contrast = 0.4,
						Saturation = 0.1
					}
                local s47 = "ColorCorrectionEffect"
                local u1623 = t82
                pcall(function()
                    local v1780 = Instance.new(s47, u845)

                    for k, v in pairs(u1623) do
                        v1780[k] = v
                    end

                    return v1780
                end)
            elseif u849 == "حرارة الصيف" then
                v846()
                u845.Brightness = 4
                v847("ColorCorrectionEffect", {
						TintColor = Color3.fromRGB(255, 240, 200)
					})
            elseif u849 == "ظلال عميقة" then
                v846()
                u845.GlobalShadows = true
                local t83 = {
						Contrast = 0.6
					}
                local s48 = "ColorCorrectionEffect"
                local u1626 = t83
                pcall(function()
                    local v1783 = Instance.new(s48, u845)

                    for k, v in pairs(u1626) do
                        v1783[k] = v
                    end

                    return v1783
                end)
            elseif u849 == "ليل مضيء" then
                v846()
                u845.ClockTime = 0
                u845.Brightness = 5
            elseif u849 == "سماء وردية" then
                v846()
                v847("ColorCorrectionEffect", {
						TintColor = Color3.fromRGB(255, 200, 255)
					})
            elseif u849 == "تشبع ألوان قوي" then
                v846()
                local t84 = {
						Saturation = 3
					}
                local s49 = "ColorCorrectionEffect"
                local u1629 = t84
                pcall(function()
                    local v1786 = Instance.new(s49, u845)

                    for k, v in pairs(u1629) do
                        v1786[k] = v
                    end

                    return v1786
                end)
            end

            local s50 = "REX-M"

            pcall(function()
                t1.value114:SetCore("SendNotification", {
						Title = "مضاد الفلاش والسماء",
						Text = s50,
						Duration = 4
					})
            end)
        end)
    end
	})
    v843:AddSection({
		Name = "تاثيرات العالم (بركان و كدا)"
	})
    local u850
    v843:AddDropdown({
		Name = "اختار التاثير",
		Options = {
			"❌ العودة للوضع الطبيعي",
			"شتاء نووي",
			"عاصفة رملية",
			"ضباب سام",
			"Silent Hill",
			"نيران الجحيم",
			"عالم النباتات",
			"عالم الصدأ",
			"إشعاع أزرق",
			"سقوط الرماد",
			"جفاف شديد",
			"نهاية العالم"
		},
		Default = "",
		Callback = function(p169)
        u850 = p169
    end
	})
    v843:AddButton({
		Name = "تشغيل التاثير",
		Callback = function()
        pcall(function()
            if u850 == "❌ العودة للوضع الطبيعي" then
                v846()
            elseif u850 == "شتاء نووي" then
                v846()
                local s51 = "Concrete"
                pcall(function()
                    for _, descendant in pairs(workspace:GetDescendants()) do
                        if descendant:IsA("BasePart") and descendant.Transparency < 1 then
                            descendant.Material = s51
                        end
                    end
                end)
                u845.FogEnd = 400
                local t85 = {
						Saturation = -0.8
					}
                local s52 = "ColorCorrectionEffect"
                local u1634 = t85
                pcall(function()
                    local v1791 = Instance.new(s52, u845)

                    for k, v in pairs(u1634) do
                        v1791[k] = v
                    end

                    return v1791
                end)
            elseif u850 == "عاصفة رملية" then
                v846()

                local s53 = "Sand"

                pcall(function()
                    for _, descendant in pairs(workspace:GetDescendants()) do
                        if descendant:IsA("BasePart") and descendant.Transparency < 1 then
                            descendant.Material = s53
                        end
                    end
                end)
                u845.FogEnd = 200
                u845.FogColor = Color3.fromRGB(180, 140, 80)
            elseif u850 == "ضباب سام" then
                v846()
                u845.FogEnd = 300
                u845.FogColor = Color3.fromRGB(100, 255, 100)
            elseif u850 == "Silent Hill" then
                v846()
                u845.FogEnd = 150
                local t86 = {
						Saturation = -1
					}
                local s54 = "ColorCorrectionEffect"
                local u1638 = t86
                pcall(function()
                    local v1796 = Instance.new(s54, u845)

                    for k, v in pairs(u1638) do
                        v1796[k] = v
                    end

                    return v1796
                end)
            elseif u850 == "نيران الجحيم" then
                v846()
                u845.ClockTime = 18
                v847("ColorCorrectionEffect", {
						TintColor = Color3.fromRGB(255, 50, 50)
					})
            elseif u850 == "عالم النباتات" then
                v846()
                local s55 = "Grass"
                pcall(function()
                    for _, descendant in pairs(workspace:GetDescendants()) do
                        if descendant:IsA("BasePart") and descendant.Transparency < 1 then
                            descendant.Material = s55
                        end
                    end
                end)
                local t87 = {
						Saturation = 1
					}
                local s56 = "ColorCorrectionEffect"
                local u1642 = t87
                pcall(function()
                    local v1801 = Instance.new(s56, u845)

                    for k, v in pairs(u1642) do
                        v1801[k] = v
                    end

                    return v1801
                end)
            elseif u850 == "عالم الصدأ" then
                v846()

                local s57 = "CorrodedMetal"

                pcall(function()
                    for _, descendant in pairs(workspace:GetDescendants()) do
                        if descendant:IsA("BasePart") and descendant.Transparency < 1 then
                            descendant.Material = s57
                        end
                    end
                end)
            elseif u850 == "إشعاع أزرق" then
                v846()
                v847("ColorCorrectionEffect", {
						TintColor = Color3.fromRGB(0, 255, 255),
						Brightness = 0.2
					})
            elseif u850 == "سقوط الرماد" then
                v846()
                u845.FogEnd = 500
                u845.FogColor = Color3.fromRGB(50, 50, 50)
            elseif u850 == "جفاف شديد" then
                v846()

                local s58 = "Slate"

                pcall(function()
                    for _, descendant in pairs(workspace:GetDescendants()) do
                        if descendant:IsA("BasePart") and descendant.Transparency < 1 then
                            descendant.Material = s58
                        end
                    end
                end)

                local v1646 = v847
                local color3 = Color3.fromRGB(255, 220, 180)

                v1646("ColorCorrectionEffect", {
						Saturation = -0.2,
						TintColor = color3
					})
            elseif u850 == "نهاية العالم" then
                v846()
                u845.ClockTime = 20
                local t88 = {
						Contrast = 0.8,
						Saturation = 0.5
					}
                local s59 = "ColorCorrectionEffect"
                local u1649 = t88
                pcall(function()
                    local v1808 = Instance.new(s59, u845)

                    for k, v in pairs(u1649) do
                        v1808[k] = v
                    end

                    return v1808
                end)
            end

            local s60 = "REX-M"

            pcall(function()
                t1.value114:SetCore("SendNotification", {
						Title = "مضاد الفلاش والسماء",
						Text = s60,
						Duration = 4
					})
            end)
        end)
    end
	})
    v843:AddSection({
		Name = "تغير الطقس"
	})
    local u851
    v843:AddDropdown({
		Name = "اختار التاثير",
		Options = {
			"❌ تصفية السماء",
			"مطر غزير",
			"عاصفة ثلجية",
			"عاصفة رعدية",
			"يوم غائم",
			"ضباب خفيف",
			"مطر منتصف الليل",
			"أجواء الخريف",
			"ازدهار الربيع",
			"موجة حر",
			"سماء الإعصار",
			"كسوف الشمس"
		},
		Default = "",
		Callback = function(p170)
        u851 = p170
    end
	})
    v843:AddButton({
		Name = "تشغيل التاثير",
		Callback = function()
        pcall(function()
            if u851 == "❌ تصفية السماء" then
                v846()
            elseif u851 == "مطر غزير" then
                v846()
                local t89 = {
						Size = 5
					}
                local s61 = "BlurEffect"
                local u1653 = t89
                pcall(function()
                    local v1811 = Instance.new(s61, u845)

                    for k, v in pairs(u1653) do
                        v1811[k] = v
                    end

                    return v1811
                end)
                u845.FogEnd = 500
            elseif u851 == "عاصفة ثلجية" then
                v846()

                local s62 = "Snow"

                pcall(function()
                    for _, descendant in pairs(workspace:GetDescendants()) do
                        if descendant:IsA("BasePart") and descendant.Transparency < 1 then
                            descendant.Material = s62
                        end
                    end
                end)
                u845.FogEnd = 200
            elseif u851 == "عاصفة رعدية" then
                v846()
                u845.Brightness = 0.3
                task.spawn(function()
                    while task.wait(5) do
                        u845.Brightness = 10
                        task.wait(0.1)
                        u845.Brightness = 0.3
                    end
                end)
            elseif u851 == "يوم غائم" then
                v846()
                u845.Brightness = 1
                local t90 = {
						Contrast = 0.1
					}
                local s63 = "ColorCorrectionEffect"
                local u1657 = t90
                pcall(function()
                    local v1816 = Instance.new(s63, u845)

                    for k, v in pairs(u1657) do
                        v1816[k] = v
                    end

                    return v1816
                end)
            elseif u851 == "ضباب خفيف" then
                v846()
                u845.FogEnd = 1000
                u845.FogColor = Color3.fromRGB(200, 200, 200)
            elseif u851 == "مطر منتصف الليل" then
                v846()
                u845.ClockTime = 0
                local t91 = {
						Size = 2
					}
                local s64 = "BlurEffect"
                local u1660 = t91
                pcall(function()
                    local v1819 = Instance.new(s64, u845)

                    for k, v in pairs(u1660) do
                        v1819[k] = v
                    end

                    return v1819
                end)
            elseif u851 == "أجواء الخريف" then
                v846()
                v847("ColorCorrectionEffect", {
						TintColor = Color3.fromRGB(255, 150, 50)
					})
            elseif u851 == "ازدهار الربيع" then
                v846()

                local v1662 = v847
                local color3 = Color3.fromRGB(255, 255, 200)

                v1662("ColorCorrectionEffect", {
						Saturation = 0.4,
						TintColor = color3
					})
            elseif u851 == "موجة حر" then
                v846()
                local t92 = {
						Brightness = 0.1,
						Contrast = 0.2
					}
                local s65 = "ColorCorrectionEffect"
                local u1665 = t92
                pcall(function()
                    local v1822 = Instance.new(s65, u845)

                    for k, v in pairs(u1665) do
                        v1822[k] = v
                    end

                    return v1822
                end)
            elseif u851 == "سماء الإعصار" then
                v846()
                u845.FogColor = Color3.fromRGB(70, 70, 80)
                u845.FogEnd = 600
            elseif u851 == "كسوف الشمس" then
                v846()
                u845.ClockTime = 14
                u845.Brightness = 0.1
                u845.OutdoorAmbient = Color3.new(0, 0, 0)
            end

            local s66 = "REX-M"

            pcall(function()
                t1.value114:SetCore("SendNotification", {
						Title = "مضاد الفلاش والسماء",
						Text = s66,
						Duration = 4
					})
            end)
        end)
    end
	})
    v843:AddSection({
		Name = "تاثيرات جرافكس"
	})
    local u852
    v843:AddDropdown({
		Name = "اختار التاثير",
		Options = {
			"❌ إيقاف التأثيرات",
			"VHS 1980",
			"GameBoy",
			"Matrix",
			"أبيض وأسود",
			"ضبابية سكران",
			"رؤية ليلية",
			"مظهر 8-Bit",
			"ألوان معكوسة",
			"تحت الماء",
			"صورة قديمة",
			"ضبابية بنفسجية"
		},
		Default = "",
		Callback = function(p171)
        u852 = p171
    end
	})
    v843:AddButton({
		Name = "تشغيل التاثير",
		Callback = function()
        pcall(function()
            if u852 == "❌ إيقاف التأثيرات" then
                v846()
            elseif u852 == "VHS 1980" then
                v846()
                local t93 = {
						Size = 2
					}
                local s67 = "BlurEffect"
                local u1669 = t93
                pcall(function()
                    local v1825 = Instance.new(s67, u845)

                    for k, v in pairs(u1669) do
                        v1825[k] = v
                    end

                    return v1825
                end)
                local t94 = {
						Contrast = 0.3,
						Saturation = -0.2
					}
                local s68 = "ColorCorrectionEffect"
                local u1672 = t94
                pcall(function()
                    local v1828 = Instance.new(s68, u845)

                    for k, v in pairs(u1672) do
                        v1828[k] = v
                    end

                    return v1828
                end)
            elseif u852 == "GameBoy" then
                v846()
                v847("ColorCorrectionEffect", {
						TintColor = Color3.fromRGB(155, 188, 15),
						Saturation = -1,
						Contrast = 2
					})
            elseif u852 == "Matrix" then
                v846()
                v847("ColorCorrectionEffect", {
						TintColor = Color3.fromRGB(0, 255, 0),
						Contrast = 0.5
					})
            elseif u852 == "أبيض وأسود" then
                v846()
                local t95 = {
						Saturation = -1,
						Contrast = 0.2
					}
                local s69 = "ColorCorrectionEffect"
                local u1675 = t95
                pcall(function()
                    local v1831 = Instance.new(s69, u845)

                    for k, v in pairs(u1675) do
                        v1831[k] = v
                    end

                    return v1831
                end)
            elseif u852 == "ضبابية سكران" then
                local t96 = {
						Size = 0
					}
                local s70 = "BlurEffect"
                local u1678 = t96
                local ok = pcall(function()
                    local v1834 = Instance.new(s70, u845)

                    for k, v in pairs(u1678) do
                        v1834[k] = v
                    end

                    return v1834
                end)
                task.spawn(function()
                    while ok and ok.Parent do
                        for i = 0, 10 do
                            if not ok or not ok.Parent then
                                break
                            end

                            ok.Size = i
                            task.wait(0.05)
                        end

                        for i = 10, 0, -1 do
                            if not ok or not ok.Parent then
                                break
                            end

                            ok.Size = i
                            task.wait(0.05)
                        end
                    end
                end)
            elseif u852 == "رؤية ليلية" then
                v846()
                u845.Brightness = 4
                v847("ColorCorrectionEffect", {
						TintColor = Color3.fromRGB(0, 255, 0)
					})
            elseif u852 == "مظهر 8-Bit" then
                v846()
                local t97 = {
						Contrast = 0.8,
						Saturation = 0.5
					}
                local s71 = "ColorCorrectionEffect"
                local u1682 = t97
                pcall(function()
                    local v1839 = Instance.new(s71, u845)

                    for k, v in pairs(u1682) do
                        v1839[k] = v
                    end

                    return v1839
                end)
            elseif u852 == "ألوان معكوسة" then
                v846()
                v847("ColorCorrectionEffect", {
						TintColor = Color3.fromRGB(0, 0, 0),
						Brightness = 1
					})
            elseif u852 == "تحت الماء" then
                v846()
                v847("ColorCorrectionEffect", {
						TintColor = Color3.fromRGB(0, 100, 255)
					})
                local t98 = {
						Size = 4
					}
                local s72 = "BlurEffect"
                local u1685 = t98
                pcall(function()
                    local v1842 = Instance.new(s72, u845)

                    for k, v in pairs(u1685) do
                        v1842[k] = v
                    end

                    return v1842
                end)
            elseif u852 == "صورة قديمة" then
                v846()
                v847("ColorCorrectionEffect", {
						TintColor = Color3.fromRGB(112, 66, 20),
						Saturation = -0.5
					})
            elseif u852 == "ضبابية بنفسجية" then
                v846()
                v847("ColorCorrectionEffect", {
						TintColor = Color3.fromRGB(150, 0, 255),
						Saturation = 0.5
					})
            end

            local s73 = "REX-M"

            pcall(function()
                t1.value114:SetCore("SendNotification", {
						Title = "مضاد الفلاش والسماء",
						Text = s73,
						Duration = 4
					})
            end)
        end)
    end
	})
end)
ChildTab = t1.value4:MakeTab({
	Title = "الاطفال",
	Icon = "rbxassetid://76144975356652"
})
t1.value136 = game:GetService("Players")
t1.value94 = game:GetService("RunService")
t1.value102 = game:GetService("ReplicatedStorage")
t1.value137 = t1.value136.LocalPlayer
getgenv().Selec7tedPlayerNOme = nil
function GetPlayersList()
    list = {}

    for _, player in ipairs(t1.value136:GetPlayers()) do
        if player ~= t1.value137 then
            table.insert(list, player.Name)
        end
    end

    if #list == 0 then
        return { "لا يوجد لاعبين" }
    end

    return list
end
ChildTab:AddSection({
	Name = "احسن من حق الاول (تحديث)"
})
local _ChildTab = ChildTab
local AddDropdown2 = _ChildTab.AddDropdown
local v87 = GetPlayersList()
t1.value17 = AddDropdown2(_ChildTab, {
	Name = "اختيار اللاعب",
	Options = v87,
	Default = "لا يوجد لاعبين",
	Callback = function(p172)
    if p172 == "لا يوجد لاعبين" then
        getgenv().Selec7tedPlayerNOme = nil

        return
    end

    getgenv().Selec7tedPlayerNOme = p172
end
})
ChildTab:AddButton({
	Name = "تحديث اللاعبين",
	Callback = function()
    t1.value17:Set(GetPlayersList())
end
})
ChildTab:AddToggle({
	Name = "المراقبة",
	Default = false,
	Callback = function(p173)
    camera = workspace.CurrentCamera

    if p173 then
        if not getgenv().Selec7tedPlayerNOme then
            return
        end

        if getgenv().SpyConnection then
            getgenv().SpyConnection:Disconnect()
        end

        getgenv().SpyConnection = t1.value94.Heartbeat:Connect(function()
            local Selec7tedPlayerNOme = t1.value136:FindFirstChild(getgenv().Selec7tedPlayerNOme)

            if Selec7tedPlayerNOme and Selec7tedPlayerNOme.Character then
                camera.CameraSubject = Selec7tedPlayerNOme.Character:FindFirstChild("Humanoid") or camera.CameraSubject
            end
        end)

        return
    end

    if getgenv().SpyConnection then
        getgenv().SpyConnection:Disconnect()
        getgenv().SpyConnection = nil
    end

    camera.CameraSubject = t1.value137.Character and t1.value137.Character:FindFirstChild("Humanoid") or camera.CameraSubject
end
})
ChildTab:AddButton({
	Name = "حذف الطفل",
	Callback = function()
    args = { "DeleteFollowCharacter" }
    game:GetService("ReplicatedStorage"):WaitForChild("RE"):WaitForChild("1Bab1yFollo1w"):FireServer(unpack(args))
end
})
ChildTab:AddToggle({
	Name = "ارسال الطفل",
	Default = false,
	Callback = function(p174)
    pl = t1.value136.LocalPlayer
    t1.value36 = getgenv().Selec7tedPlayerNOme

    if not t1.value36 then
        warn("No player selected!")

        return
    end

    if p174 then
        args = {
				"SpawnChild",
				"BabyBoy"
			}

        local v858 = game:GetService("ReplicatedStorage"):WaitForChild("RE"):WaitForChild("1Bab1yFollo1w")
        local t99 = { unpack(args) }

        v858:FireServer(v2(t99))
        wait(0.8)

        if not workspace:FindFirstChild(pl.Name) or not workspace[pl.Name]:FindFirstChild("FollowCharacter") then
            args = {
					"CharacterFollowSpawnPlayer",
					"BabyBoy"
				}
            t1.value85 = t1.value102.RE:FindFirstChild("1Bab1yFollo1w")

            if t1.value85 then
                local value85 = t1.value85
                local t100 = { unpack(args) }

                value85:FireServer(v2(t100))
            end
        end

        task.wait(0.2)

        if workspace:FindFirstChild(pl.Name) then
            for _, child in pairs(workspace[pl.Name]:GetChildren()) do
                if child:IsA("BasePart") then
                    child.CanCollide = true
                end
            end
        end

        target = t1.value36

        local target2 = workspace:FindFirstChild(target)

        if target2 then
            target2 = workspace:FindFirstChild(pl.Name) and workspace[pl.Name]:FindFirstChild("FollowCharacter")
        end

        if target2 then
            workspace[pl.Name].FollowCharacter.Parent = workspace[target]

            if getgenv().RunService then
                getgenv().RunService:Disconnect()
            end

            getgenv().RunService = t1.value94.Heartbeat:Connect(function()
                followCharacter = workspace[target]:FindFirstChild("FollowCharacter")
                humanoidRootPart = workspace[target]:FindFirstChild("HumanoidRootPart")

                if followCharacter and (followCharacter:FindFirstChild("Torso") and (followCharacter.Torso:FindFirstChild("BodyPosition") and humanoidRootPart)) then
                    followCharacter.Torso.BodyPosition.Position = humanoidRootPart.Position - humanoidRootPart.CFrame.LookVector * 3
                    followCharacter.Torso.BodyGyro.CFrame = humanoidRootPart.CFrame
                end
            end)

            return
        end
    else
        if getgenv().RunService then
            getgenv().RunService:Disconnect()
            getgenv().RunService = nil
        end

        args = {
				"SpawnChild",
				"BabyBoy"
			}
        t1.value85 = t1.value102:WaitForChild("RE"):WaitForChild("1Bab1yFollo1w")
        t1.value85:FireServer(unpack(args))
    end
end
})
getgenv().BangSpeed = 1
local _ChildTab2 = ChildTab
local BangSpeed = getgenv().BangSpeed
_ChildTab2:AddSlider({
	Name = "سرعة البانق",
	MinValue = 0.1,
	MaxValue = 2,
	Default = BangSpeed,
	Increase = 0.1,
	Callback = function(p175)
    getgenv().BangSpeed = p175
end
})
function BangChild1()
    bangActive = false
    local connection
    togglePosition = false
    ChildTab:AddToggle({
		Name = "بانق الطفل ",
		Default = false,
		Callback = function(p176)
        bangActive = p176
        plr = t1.value136.LocalPlayer
        char = plr.Character

        if not char then
            return
        end

        model = workspace:FindFirstChild(plr.Name)

        if p176 then
            if not model or not model:FindFirstChild("FollowCharacter") then
                args = {
						"CharacterFollowSpawnPlayer",
						"BabyBoy"
					}
                t1.value85 = t1.value102:FindFirstChild("RE")

                if not (t1.value85 and t1.value85:FindFirstChild("1Bab1yFollo1w")) then
                    return
                end

                local v1342 = t1.value85:FindFirstChild("1Bab1yFollo1w")
                local t101 = { unpack(args) }

                v1342:FireServer(v2(t101))
            end

            model = workspace:WaitForChild(plr.Name, 5)

            if not model then
                return
            end

            baby = model:WaitForChild("FollowCharacter", 5)

            if not baby then
                return
            end

            if connection then
                connection:Disconnect()
            end

            connection = t1.value94.Heartbeat:Connect(function()
                if bangActive and getgenv().Selec7tedPlayerNOme then
                    targetPlayer = t1.value136:FindFirstChild(getgenv().Selec7tedPlayerNOme)

                    if targetPlayer and (targetPlayer.Character and targetPlayer.Character.PrimaryPart) then
                        head = targetPlayer.Character:FindFirstChild("Head")

                        if head then
                            offset = not togglePosition and 4 or 1
                            baby:SetPrimaryPartCFrame(head.CFrame * CFrame.new(0, -1, offset))
                            togglePosition = not togglePosition
                            task.wait(getgenv().BangSpeed)
                        end
                    end
                end
            end)

            return
        end

        if connection then
            connection:Disconnect()
        end
    end
	})
end
BangChild1()
function FaceBang1()
    bangActive = false
    local connection
    togglePosition = false
    ChildTab:AddToggle({
		Name = "بانق وجه الطفل ",
		Default = false,
		Callback = function(p177)
        bangActive = p177
        plr = t1.value136.LocalPlayer
        char = plr.Character

        if not char then
            return
        end

        model = workspace:FindFirstChild(plr.Name)

        if p177 then
            if not model or not model:FindFirstChild("FollowCharacter") then
                args = {
						"CharacterFollowSpawnPlayer",
						"BabyBoy"
					}
                t1.value85 = t1.value102:FindFirstChild("RE")

                if not (t1.value85 and t1.value85:FindFirstChild("1Bab1yFollo1w")) then
                    return
                end

                local v1345 = t1.value85:FindFirstChild("1Bab1yFollo1w")
                local t102 = { unpack(args) }

                v1345:FireServer(v2(t102))
            end

            model = workspace:WaitForChild(plr.Name, 5)

            if not model then
                return
            end

            baby = model:WaitForChild("FollowCharacter", 5)

            if not baby then
                return
            end

            if connection then
                connection:Disconnect()
            end

            connection = t1.value94.Heartbeat:Connect(function()
                if bangActive and getgenv().Selec7tedPlayerNOme then
                    targetPlayer = t1.value136:FindFirstChild(getgenv().Selec7tedPlayerNOme)

                    if targetPlayer and (targetPlayer.Character and targetPlayer.Character.PrimaryPart) then
                        head = targetPlayer.Character:FindFirstChild("Head")

                        if head then
                            offset = not togglePosition and 4 or 1
                            baby:SetPrimaryPartCFrame(head.CFrame * CFrame.new(0, 1, -offset) * CFrame.Angles(0, math.rad(180), 0))
                            togglePosition = not togglePosition
                            task.wait(getgenv().BangSpeed)
                        end
                    end
                end
            end)

            return
        end

        if connection then
            connection:Disconnect()
        end
    end
	})
end
FaceBang1()