-- Lynd Deobfuscator & Dumper | https://discord.gg/SRvRc2XF6s
-- Gustavo Lularphed
-- Deobf by lynd

local coreGui = game:GetService("CoreGui")
local stats = game:GetService("Stats")
local runService = game:GetService("RunService")
local v1 = game:GetService("Workspace")
local userInputService = game:GetService("UserInputService")
local textChatService = game:GetService("TextChatService")
local teleportService = game:GetService("TeleportService")
local players = game:GetService("Players")
local getChildren = coreGui.GetChildren
local localPlayer = players.LocalPlayer
local v2 = {
}
for index, value in ipairs(getChildren(coreGui)) do
    if value:IsA("ScreenGui") then
        v2[value] =  true
    end
end
for index2, value2 in ipairs(localPlayer.PlayerGui:GetChildren()) do
    if value2:IsA("ScreenGui") then
        v2[value2] =  true
    end
end
pcall(function()
    loadstring(game:HttpGet("https://pastebin.com/raw/tkJDDJPG"))()
end
)
task.wait(0.5)
local v3
for index3, value3 in ipairs(coreGui:GetChildren()) do
    if value3:IsA("ScreenGui") and not v2[value3] then
        v3 = value3
        break
    end
end
if not v3 then
    for index4, value4 in ipairs(localPlayer.PlayerGui:GetChildren()) do
        if value4:IsA("ScreenGui") and not v2[value4] then
            v3 = value4
            break
        end
    end
end
if v3 then
    while true do
        task.wait(0.2)
        if not v3:IsDescendantOf(game) then
            break
        end
    end
else
    task.wait(6)
end
local window = loadstring(game:HttpGet("https://pastebin.com/raw/XqZsnzRQ"))():MakeWindow({
    Title = "Gustavo Hub | Brookhaven",
    SubTitle = "By gustavohh",
    SaveFolder = "GustavoHub_Brookhaven",
}
)
window:AddMinimizeButton({
    Button = {
        Image = "rbxassetid://119984950733111",
        BackgroundTransparency = 0
    },
    Corner = {
        CornerRadius = UDim.new(35,
        1)
    },
}
)
local tab = window:MakeTab({
    "Info",
    "info"
}
)
local tab2 = window:MakeTab({
    "Fun",
    "check"
}
)
window:MakeTab({
    "Shaders",
    "server"
}
)
window:MakeTab({
    "Troll Players",
    Icon = "rbxassetid://131153193945220"
}
)
local tab3 = window:MakeTab({
    "Protector",
    "shield"
}
)
window:MakeTab({
    "Avatar",
    "shirt"
}
)
window:MakeTab({
    "Nomes",
    "paper"
}
)
window:MakeTab({
    "House",
    "home"
}
)
window:MakeTab({
    "Painel Admin",
    "shield"
}
)
window:MakeTab({
    "Scripts",
    "scroll"
}
)
window:MakeTab({
    "Portal",
    "tp"
}
)
tab:AddSection({
    "Information"
}
)
tab:AddSection({
    "Credits"
}
)
tab:AddParagraph({
    "Programmer:",
    ":Gusttavin"
}
)
tab:AddParagraph({
    "Team:",
    "Gustavo Hub"
}
)
tab:AddSection({
    "Internet Things"
}
)
tab:AddDiscordInvite({
    Title = "Gustavo Hub Update",
    Desc = "Discord Gustavo Hub",
    Logo = "rbxassetid://119984950733111",
    Invite = "https://discord.gg/NfZWpvdt9",
}
)
local function f1()
    return identifyexecutor and identifyexecutor() or "Unknown"
end
local function f2()
    local dataPing = stats.Network.ServerStatsItem["Data Ping"]
    return tostring((math.floor(dataPing:GetValue()))).. " ms"
end
tab:AddSection({
    "Information"
}
)
tab:AddParagraph({
    "You Username:",
    localPlayer.Name
}
)
tab:AddParagraph({
    "You Ping:",
    f2()
}
)
tab:AddParagraph({
    "You User Id:",
    tostring(localPlayer.UserId)
}
)
tab:AddParagraph({
    "You Executor:",
    f1()
}
)
tab:AddParagraph({
    "You Display Name:",
    localPlayer.DisplayName
}
)
tab:AddParagraph({
    "You Account Age:",
    tostring(localPlayer.AccountAge).. " days"
}
)
tab:AddParagraph({
    "You Language:",
    "Português"
}
)
tab:AddParagraph({
    "You are Playing:",
    "Brookhaven RP"
}
)
tab:AddParagraph({
    "You are Using:",
    "Gustavo Hub"
}
)
tab:AddParagraph({
    "You are Using Version:",
    "1.0 Updated"
}
)
tab:AddSection({
    "Warns"
}
)
tab:AddSection({
    "Others"
}
)
tab:AddButton({
    Name = "Rejoin",
    Callback = function()
        teleportService:TeleportToPlaceInstance(game.PlaceId,
        game.JobId,
        localPlayer)
    end
,
}
)
local function f3()
    return localPlayer.Character and localPlayer.Character:FindFirstChildOfClass("Humanoid")
end
tab2:AddSlider({
    Name = "Speed Player",
    Min = 16,
    Max = 888,
    Default = 16,
    Callback = function(value5)
        if f3() then
            f3().WalkSpeed = value5
        end
    end
,
}
)
tab2:AddSlider({
    Name = "JumpPower",
    Min = 50,
    Max = 500,
    Default = 50,
    Callback = function(value6)
        if f3() then
            f3().JumpPower = value6
        end
    end
,
}
)
tab2:AddSlider({
    Name = "Gravity",
    Min = 10,
    Max = 10000,
    Default = 196,
    Callback = function(value7)
        workspace.Gravity = value7
    end
,
}
)
local infiniteJump =  false
tab2:AddToggle({
    Name = "Infinite Jump",
    Callback = function(value8)
        infiniteJump = value8
    end
}
)
userInputService.JumpRequest:Connect(function()
    if infiniteJump and f3() then
        f3():ChangeState(Enum.HumanoidStateType.Jumping)
    end
end
)
local function f4(canCollide)
    local character = localPlayer.Character
    if not character then
        return
    end
    for index5, value9 in ipairs(character:GetDescendants()) do
        if value9:IsA("BasePart") then
            value9.CanCollide = canCollide
        end
    end
end
tab2:AddButton({
    Name = "Reset Speed/Gravity/Jumppower.✅",
    Callback = function()
        workspace.Gravity = 196
        if f3() then
            f3().WalkSpeed = 16
            f3().JumpPower = 50
        end
    end
,
}
)
local v5 =  false
local function f5()
    local character2 = localPlayer.Character
    if not character2 then
        return
    else
        local humanoid = character2:FindFirstChildOfClass("Humanoid")
        local humanoidRootPart = character2:FindFirstChild("HumanoidRootPart")
        if not(humanoid and humanoidRootPart) then
            return
        else
            local raycastParams = RaycastParams.new()
            raycastParams.FilterType = Enum.RaycastFilterType.Exclude
            raycastParams.FilterDescendantsInstances = {
                character2
            }
            raycastParams.IgnoreWater =  true
            local raycast = v1:Raycast(humanoidRootPart.Position, Vector3.new(0,  - 100, 0), raycastParams)
            if raycast then
                humanoidRootPart.CFrame = CFrame.new(humanoidRootPart.Position.X, raycast.Position.Y + humanoidRootPart.Size.Y / 2, humanoidRootPart.Position.Z)
            end
            humanoidRootPart.AssemblyLinearVelocity = Vector3.zero
            humanoid:ChangeState(Enum.HumanoidStateType.Running)
            return
        end
    end
end
local connect
tab2:AddToggle({
    Name = "Ultimate Noclip",
    Description = "Noclip com ajuste ao solo",
    Callback = function(value10)
        v4 = value10
        if connect then
            connect:Disconnect()
            connect =  nil
        end
        if v5 then
            connect = runService.Heartbeat:Connect(function()
                f4( false)
            end
)
        else
            f4( true)
            task.wait()
            f5()
        end
    end
,
}
)
tab2:AddButton({
    Name = "Ativar Fly GUI",
    Description = "Carrega um GUI de fly universal",
    Callback = function()
        loadstring(game:HttpGet("https://rawscripts.net/raw/Universal-Script-fly-Gui-v5-64340"))()
    end
,
}
)
tab2:AddSection({
    "Chat"
}
)
local enterText = ""
getgenv().GustavoHubEnviarDelay = 1
getgenv().GustavoHubSpawnText =  false
tab2:AddTextBox({
    Name = "Enter Text",
    PlaceholderText = "Uh... Hi!",
    Callback = function(value11)
        enterText = tostring(value11 or "")
    end
,
}
)
local function f6(p1)
    if not p1 or p1 == "" then
        return
    end
    local rbxGeneral
    if textChatService and textChatService.TextChannels then
        rbxGeneral = textChatService.TextChannels:FindFirstChild("RBXGeneral") or textChatService.TextChannels:GetChildren()[1]
        if rbxGeneral and rbxGeneral.SendAsync then
            pcall(function()
                rbxGeneral:SendAsync(tostring(p1))
            end
)
        end
    end
end
tab2:AddButton({
    Name = "Send Chat",
    Callback = function()
        f6(enterText)
    end
}
)
tab2:AddSlider({
    Name = "Delay Spam",
    Min = 0.4,
    Max = 10,
    Default = 1,
    Increase = 0.1,
    Callback = function(value12)
        getgenv().GustavoHubEnviarDelay = value12
    end
,
}
)
tab2:AddToggle({
    Name = "Spam Chat",
    Default =  false,
    Callback = function(value13)
        getgenv().GustavoHubSpawnText = value13
        if value13 then
            task.spawn(function()
                while getgenv().GustavoHubSpawnText do
                    if enterText ~= "" then
                        f6(enterText)
                    end
                    task.wait(getgenv().GustavoHubEnviarDelay)
                end
            end
)
        end
    end
,
}
)
tab2:AddButton({
    Name = "Spam: Hacked by S4turn Hub",
    Callback = function()
        f6("System: Hacked by S4turn Hub")
    end
,
}
)
tab2:AddButton({
    Name = "Clear Chat",
    Callback = function()
        f6("Server: Chat Cleared")
    end
}
)
local v6 = setmetatable({
}, {
    __mode = "k"
}
)
local function f7(p2)
    if not p2 or not p2:IsA("Sound") then
        return
    end
    if v6[p2] ==  nil then
        local v7, v8 = pcall(function()
            return p2.Volume
        end
)
        if v7 then
            v6[p2] = v8
        end
    end
end
local function f8(p3)
    if not p3 then
        return
    end
    pcall(function()
        p3:SetStateEnabled(Enum.HumanoidStateType.Seated,  false)
    end
)
    pcall(function()
        p3.Sit =  false
    end
)
    pcall(function()
        p3.PlatformStand =  false
    end
)
end
local function f9()
    for key, value14 in pairs(v6) do
        local v9 = key
        local volume = value14
        if v9 and v9:IsA("Sound") then
            pcall(function()
                v9.Volume = volume
            end
)
        end
    end
    v6 = setmetatable({
    }, {
        __mode = "k"
    }
)
end
local function f10()
    local character3 = localPlayer.Character
    if not character3 then
        return
    end
    return character3, character3:FindFirstChildOfClass("Humanoid"), character3:FindFirstChild("HumanoidRootPart")
end
tab3:AddSection({
    "Proteção"
}
)
tab3:AddToggle({
    Name = "Anti Bug",
    Callback = function(value15)
    end
}
)
tab3:AddToggle({
    Name = "Anti Void",
    Callback = function(value16)
    end
}
)
tab3:AddToggle({
    Name = "Anti-Sit",
    Callback = function(value17)
        local v10,
        v11 = f10()
        if v11 then
            if value17 then
                f8(v11)
            else
                pcall(function()
                    v11:SetStateEnabled(Enum.HumanoidStateType.Seated,
                    true)
                end
)
            end
        end
    end
,
}
)
tab3:AddToggle({
    Name = "Anti-Áudio",
    Callback = function(value18)
        if value18 then
            for index6,
            value19 in ipairs(workspace:GetDescendants()) do
                local v12 = value19
                if v12:IsA("Sound") then
                    f7(v12)
                    pcall(function()
                        v12.Volume = 0
                    end
)
                end
            end
            local character4 = localPlayer.Character
            if character4 then
                for index7,
                value20 in ipairs(character4:GetDescendants()) do
                    local v13 = value20
                    if v13:IsA("Sound") then
                        f7(v13)
                        pcall(function()
                            v13.Volume = 0
                        end
)
                    end
                end
            end
        else
            f9()
        end
    end
,
}
)
runService.Heartbeat:Connect(function()
    local v14, v15, v16 = f10()
    if not v14 then
        return
    end
    if false then
        f8(v15)
    end
    if false and v16 and v16.Position and v16.Position.Y and v16.Position.Y <  - 20 then
        if v15 and v15.Health and v15.MaxHealth then
            pcall(function()
                v15.Health = v15.MaxHealth
            end
)
        end
        pcall(function()
            v16.Velocity = Vector3.new(0, 40, 0)
            v16.CFrame = CFrame.new(v16.Position.X, 10, v16.Position.Z)
        end
)
    end
    if false then
        for index8, value21 in ipairs(workspace:GetDescendants()) do
            local v17 = value21
            if v17:IsA("Sound") then
                if v6[v17] ==  nil then
                    f7(v17)
                    pcall(function()
                        v17.Volume = 0
                    end
)
                else
                    pcall(function()
                        v17.Volume = 0
                    end
)
                end
            end
        end
        for index9, value22 in ipairs(v14:GetDescendants()) do
            local v18 = value22
            if v18:IsA("Sound") then
                if v6[v18] ==  nil then
                    f7(v18)
                    pcall(function()
                        v18.Volume = 0
                    end
)
                else
                    pcall(function()
                        v18.Volume = 0
                    end
)
                end
            end
        end
    end
end
)
localPlayer.CharacterAdded:Connect(function(character5)
    task.wait(0.5)
    local humanoid2 = character5:WaitForChild("Humanoid")
    if false then
        f8(humanoid2)
    end
    humanoid2.Seated:Connect(function(p4)
        if false then
            f8(humanoid2)
        end
    end
)
    if false then
        for index10, value23 in ipairs(character5:GetDescendants()) do
            local v19 = value23
            if v19:IsA("Sound") then
                f7(v19)
                pcall(function()
                    v19.Volume = 0
                end
)
            end
        end
    end
end
)