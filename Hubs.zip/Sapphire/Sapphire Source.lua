-- Lynd Deobfuscator & Dumper | https://discord.gg/SRvRc2XF6s
-- Sapphire Lularphed
-- Deobf by lynd

local replicatedStorage = game:GetService("ReplicatedStorage")
local runService = game:GetService("RunService")
local userInputService = game:GetService("UserInputService")
local players = game:GetService("Players")
local v1 = game:GetService("Workspace")
local teleportService = game:GetService("TeleportService")
local turtle2520Hub = loadstring(game:HttpGet("https://gist.githubusercontent.com/xNico013/22d6491ee1aa72bff4b81033d13ce853/raw/f4d0435df3ecc1165b92c2bd9a15ea12f3866e8d/Turtle%2520Hub"))()
local scripts = turtle2520Hub:Window("Scripts")
game.StarterGui:SetCore("SendNotification", {
    Title = "Made By Sapphire Hub",
    Text = "Copy the features and make a good hub <3",
    Icon = "",
    Duration = "2",
}
)
scripts:Label("Lag Commands", Color3.fromRGB(127, 143, 166))
scripts:Button("Lag Server", function()
    while wait() do
        replicatedStorage.RemoteEvents.Car:FireServer(unpack({
            [1] = "PickingCar",
            [2] = "RV"
        }
))
        wait()
        replicatedStorage.RemoteEvents.Car:FireServer("PickingCar", "FordGT")
        wait()
        replicatedStorage.RemoteEvents.Car:FireServer(unpack({
            [1] = "PickingCar",
            [2] = "FoodTruck"
        }
))
        wait()
        replicatedStorage.RemoteEvents.Car:FireServer("PickingCar", "CopSUV")
        wait()
        replicatedStorage.RemoteEvents.Car:FireServer(unpack({
            [1] = "PickingCar",
            [2] = "Van"
        }
))
        wait()
        replicatedStorage.RemoteEvents.Car:FireServer("PickingCar", "FireTruck")
        wait()
        replicatedStorage.RemoteEvents.Car:FireServer(unpack({
            [1] = "PickingCar",
            [2] = "Ambulance"
        }
))
        wait()
        replicatedStorage.RemoteEvents.Car:FireServer("PickingCar", "Bus")
        wait()
        replicatedStorage.RemoteEvents.Car:FireServer("PickingCar", "CopUnderCoverSUV")
        wait()
        replicatedStorage.RemoteEvents.Car:FireServer("PickingCar", "QuadStock")
        wait()
        replicatedStorage.RemoteEvents.Car:FireServer("PickingCar", "Challenger")
        wait()
        replicatedStorage.RemoteEvents.Car:FireServer("PickingCar", "Jeep")
        wait()
        replicatedStorage.RemoteEvents.Car:FireServer("PickingCar", "CopChallenger")
        wait()
        replicatedStorage.RemoteEvents.Car:FireServer("PickingCar", "Cadillac")
        wait()
        replicatedStorage.RemoteEvents.Car:FireServer(unpack({
            [1] = "PickingCar",
            [2] = "GolfCart"
        }
))
        wait()
        replicatedStorage.RemoteEvents.Car:FireServer(unpack({
            [1] = "PickingCar",
            [2] = "NPHarleyDavison",
        }
))
        wait()
        replicatedStorage.RemoteEvents.Car:FireServer(unpack({
            [1] = "PickingCar",
            [2] = "Horse"
        }
))
        wait()
        replicatedStorage.RemoteEvents.Car:FireServer(unpack({
            [1] = "PickingCar",
            [2] = "ScooterVehicle",
        }
))
        wait()
        replicatedStorage.RemoteEvents.Car:FireServer(unpack({
            [1] = "PickingCar",
            [2] = "SmartCar"
        }
))
    end
end
)
scripts:Label("Fun Commands", Color3.fromRGB(127, 143, 166))
scripts:Button("0 Gravity Unanchored Things", function()
    spawn(function()
        while true do
            game.Players.LocalPlayer.MaximumSimulationRadius = math.pow(math.huge, math.huge) * math.huge
            game.Players.LocalPlayer.SimulationRadius = math.pow(math.huge, math.huge) * math.huge
            runService.Stepped:wait()
        end
    end
)
    local function f1(p1)
        if p1:FindFirstChild("BodyForce") then
            return
        else
            local bodyForce = Instance.new("BodyForce")
            bodyForce.Force = p1:GetMass() * Vector3.new(0, workspace.Gravity, 0)
            bodyForce.Parent = p1
            return
        end
    end
    for index, value in ipairs(workspace:GetDescendants()) do
        if value:IsA("Part") and value.Anchored ==  false then
            if not value:IsDescendantOf(game.Players.LocalPlayer.Character) then
                f1(value)
            end
        end
    end
    workspace.DescendantAdded:Connect(function(descendant)
        if descendant:IsA("Part") and descendant.Anchored ==  false then
            if not descendant:IsDescendantOf(game.Players.LocalPlayer.Character) then
                f1(descendant)
            end
        end
    end
)
end
)
scripts:Button("Bring Unanchored Bricks [E]", function()
    local getMouse = players.LocalPlayer:GetMouse()
    local v2 = game
    local instance = Instance.new("Folder", v2:GetService("Workspace"))
    local instance2 = Instance.new("Part", instance)
    local instance3 = Instance.new("Attachment", instance2)
    instance2.Anchored =  true
    instance2.CanCollide =  false
    instance2.Transparency = 1
    local worldCFrame = getMouse.Hit + Vector3.new(0, 5, 0)
    local v3 = coroutine.create(function()
        settings().Physics.AllowSleep =  false
        while true do
            if not runService.RenderStepped:Wait() then
                break
            end
            local v4, v5 = players:GetPlayers()
            for key, value2 in next, v4, v5 do
                if value2 ~= players.LocalPlayer then
                    value2.MaximumSimulationRadius = 0
                    sethiddenproperty(value2, "SimulationRadius", 0)
                end
            end
            local v6 = game
            v6:GetService("Players").LocalPlayer.MaximumSimulationRadius = math.pow(math.huge, math.huge)
            setsimulationradius(math.huge)
        end
    end
)
    coroutine.resume(v3)
    local function f2(p2)
        if p2:IsA("Part") and p2.Anchored ==  false and p2.Parent:FindFirstChild("Humanoid") ==  nil and p2.Parent:FindFirstChild("Head") ==  nil and p2.Name ~= "Handle" then
            getMouse.TargetFilter = p2
            local v7, v8 = p2:GetChildren()
            for key2, value3 in next, v7, v8 do
                if value3:IsA("BodyAngularVelocity") or value3:IsA("BodyForce") or value3:IsA("BodyGyro") or value3:IsA("BodyPosition") or value3:IsA("BodyThrust") or value3:IsA("BodyVelocity") or value3:IsA("RocketPropulsion") then
                    value3:Destroy()
                end
            end
            if p2:FindFirstChild("Attachment") then
                p2:FindFirstChild("Attachment"):Destroy()
            end
            if p2:FindFirstChild("AlignPosition") then
                p2:FindFirstChild("AlignPosition"):Destroy()
            end
            if p2:FindFirstChild("Torque") then
                p2:FindFirstChild("Torque"):Destroy()
            end
            p2.CanCollide =  false
            local instance4 = Instance.new("Torque", p2)
            instance4.Torque = Vector3.new(100000, 100000, 100000)
            local instance5 = Instance.new("AlignPosition", p2)
            local instance6 = Instance.new("Attachment", p2)
            instance4.Attachment0 = instance6
            instance5.MaxForce = 10000000000000000
            instance5.MaxVelocity = math.huge
            instance5.Responsiveness = 200
            instance5.Attachment0 = instance6
            instance5.Attachment1 = instance3
        end
    end
    local v9, v10 = v1:GetDescendants()
    for key3, value4 in next, v9, v10 do
        f2(value4)
    end
    v1.DescendantAdded:Connect(function(descendant2)
        f2(descendant2)
    end
)
    userInputService.InputBegan:Connect(function(input, p3)
        if input.KeyCode == Enum.KeyCode.E and not p3 then
            worldCFrame = getMouse.Hit + Vector3.new(0, 5, 0)
        end
    end
)
    spawn(function()
        while true do
            if not runService.RenderStepped:Wait() then
                break
            end
            instance3.WorldCFrame = worldCFrame
        end
    end
)
end
)
scripts:Label("Tool Commands", Color3.fromRGB(127, 143, 166))
scripts:Box("Tool Kill Player", function(p4, p5)
    if p5 then
        local humanoidRootPart = game.Players.LocalPlayer.Character.HumanoidRootPart
        local position = players.LocalPlayer.Character.HumanoidRootPart.Position
        runService.RenderStepped:Wait()
        local v11 = game
        local v12 = game
        v11:GetService("Players").LocalPlayer.Character.HumanoidRootPart.CFrame = v12:GetService("Players")[p4].Character.HumanoidRootPart.CFrame * CFrame.Angles(0, math.rad(0), 0) * CFrame.new(0, 0, 5.5)
        wait()
        replicatedStorage.RemoteEvents.Tools:InvokeServer("PickingTools", "Stretcher")
        wait(0)
        local character = game.Players.LocalPlayer.Character
        local backpack = game.Players.LocalPlayer.Backpack
        character.Humanoid:EquipTool(backpack.Stretcher)
        wait(3)
        character.Humanoid:UnequipTools()
        wait(0.1)
        humanoidRootPart.CFrame = CFrame.new( - 13612, 444,  - 2855)
        wait(1)
        character.Humanoid:EquipTool(backpack.Stretcher)
        wait(0.1)
        replicatedStorage.RemoteEvents.Tools:InvokeServer("PickingTools", "Stretcher")
        wait(0.2)
        humanoidRootPart.CFrame = CFrame.new(position)
    end
end
)
scripts:Box("Tool Bring Player", function(p6, p7)
    if p7 then
        local humanoidRootPart2 = game.Players.LocalPlayer.Character.HumanoidRootPart
        local position2 = players.LocalPlayer.Character.HumanoidRootPart.Position
        runService.RenderStepped:Wait()
        local v13 = game
        local v14 = game
        v13:GetService("Players").LocalPlayer.Character.HumanoidRootPart.CFrame = v14:GetService("Players")[p6].Character.HumanoidRootPart.CFrame * CFrame.Angles(0, math.rad(0), 0) * CFrame.new(0, 0, 5.5)
        wait()
        replicatedStorage.RemoteEvents.Tools:InvokeServer("PickingTools", "Stretcher")
        wait(0)
        local character2 = game.Players.LocalPlayer.Character
        local backpack2 = game.Players.LocalPlayer.Backpack
        character2.Humanoid:EquipTool(backpack2.Stretcher)
        wait(3)
        character2.Humanoid:UnequipTools()
        wait(0.1)
        humanoidRootPart2.CFrame = CFrame.new(position2)
        wait(0.1)
        character2.Humanoid:EquipTool(backpack2.Stretcher)
        wait(0.3)
        character2.Humanoid:UnequipTools()
    end
end
)
scripts:Button("Spawn Item to Brick Spam", function()
    while wait() do
        replicatedStorage.RemoteEvents.Tools:InvokeServer(unpack({
            [1] = "PickingTools",
            [2] = "Taser",
        }
))
    end
end
)
scripts:Toggle("Brick Spam",  false, function(p8)
    drop = p8
    while drop ==  true and wait() do
        for key4, value5 in pairs(game.Players.LocalPlayer.Backpack:GetChildren()) do
            game.Players.LocalPlayer.Character.Humanoid:EquipTool(value5)
            value5.Handle.Mesh:Destroy()
            value5.Parent = workspace
        end
    end
end
)
scripts:Label("FE Music Commands", Color3.fromRGB(127, 143, 166))
scripts:Box("Gun Play Song", function(p9, p10)
    if p10 then
        replicatedStorage.RemoteEvents.Tools:InvokeServer(unpack({
            [1] = "PickingTools",
            [2] = "Sniper",
        }
))
        wait(0.1)
        game.Players.LocalPlayer.Character.Humanoid:EquipTool(game.Players.LocalPlayer.Backpack.Sniper)
        wait(0.1)
        replicatedStorage.GunSounds:FireServer(unpack({
            [1] = players.LocalPlayer.Character.Sniper.Handle,
            [2] = p9,
            [3] = 1,
        }
))
    end
end
)
scripts:Box("House Play Song", function(p11, p12)
    if p12 then
        replicatedStorage.RemoteEvents.PlayersHouse:FireServer(unpack({
            [1] = "PickingHouseMusicText",
            [2] = p11,
        }
))
    end
end
)
local scripts2 = turtle2520Hub:Window("Scripts")
scripts2:Label("Admin Commands", Color3.fromRGB(127, 143, 166))
scripts2:Button("Jump All", function()
    Players = players
    for key5, value6 in pairs(Players:GetPlayers()) do
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "DropButtonStopAll",
            [2] = players[value6.name],
        }
))
    end
end
)
scripts2:Toggle("Loop Jump All",  false, function(p13)
    jump = p13
    Players = players
    while jump ==  true and wait() do
        for key6, value7 in pairs(Players:GetPlayers()) do
            replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
                [1] = "DropButtonStopAll",
                [2] = players[value7.name],
            }
))
        end
    end
end
)
scripts2:Box("Jump Player", function(p14, p15)
    if p15 then
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "DropButtonStopAll",
            [2] = players[p14],
        }
))
    end
end
)
scripts2:Box("Mega Jump Plr", function(p16, p17)
    if p17 then
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "DropButtonStopAll",
            [2] = players[p16],
        }
))
        wait(0.1)
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "DropButtonStopAll",
            [2] = players[p16],
        }
))
        wait(0.1)
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "DropButtonStopAll",
            [2] = players[p16],
        }
))
        wait(0.1)
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "DropButtonStopAll",
            [2] = players[p16],
        }
))
        wait(0.1)
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "DropButtonStopAll",
            [2] = players[p16],
        }
))
    end
end
)
scripts2:Button("Kill All v1", function()
    Players = players
    game.Players.LocalPlayer.Character.Head:Destroy()
    for key7, value8 in pairs(Players:GetPlayers()) do
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "Client2Client",
            [2] = "Request: Piggyback!",
            [3] = players[value8.name],
        }
))
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "BothWantPiggyBackRide",
            [2] = players[value8.name],
        }
))
    end
end
)
scripts2:Button("Kill All v2", function()
    game.workspace.Camera:Destroy()
    Players = players
    game.Players.LocalPlayer.Character.Head:Destroy()
    for key8, value9 in pairs(Players:GetPlayers()) do
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "Client2Client",
            [2] = "Request: Piggyback!",
            [3] = players[value9.name],
        }
))
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "BothWantPiggyBackRide",
            [2] = players[value9.name],
        }
))
    end
end
)
scripts2:Box("Kill Any Player", function(p18, p19)
    if p19 then
        game.Players.LocalPlayer.Character.Head:Destroy()
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer("Client2Client", "Request: Piggyback!", players[game.Players.LocalPlayer.name])
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "BothWantPiggyBackRide",
            [2] = players[p18],
        }
))
    end
end
)
scripts2:Box("Freeze Player", function(p20, p21)
    if p21 then
        local name = game.Players.LocalPlayer.name
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer("Client2Client", "Request: Piggyback!", players[name])
        wait()
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "BothWantPiggyBackRide",
            [2] = players[p20],
        }
))
        wait()
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "BothWantPiggyBackRide",
            [2] = players[p20],
        }
))
        wait()
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "DropButtonStopAll",
            [2] = players[p20],
        }
))
        wait()
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "BothWantPiggyBackRide",
            [2] = players[name],
        }
))
        wait()
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "DropButtonStopAll",
            [2] = players[name],
        }
))
        wait(0.1)
        game.Players.LocalPlayer.Character.HumanoidRootPart.Anchored =  true
    end
end
)
scripts2:Box("Skydive Player", function(p22, p23)
    if p23 then
        local name2 = game.Players.LocalPlayer.name
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer("Client2Client", "Request: Carry!", players[name2])
        wait()
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "BothWantCarryHurt",
            [2] = players[p22],
        }
))
        wait()
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "BothWantCarryHurt",
            [2] = players[p22],
        }
))
        wait()
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "DropButtonStopAll",
            [2] = players[p22],
        }
))
        wait()
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "BothWantCarryHurt",
            [2] = players[name2],
        }
))
        wait()
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "DropButtonStopAll",
            [2] = players[name2],
        }
))
        wait(0.1)
        game.Players.LocalPlayer.Character.HumanoidRootPart.Anchored =  true
        wait(0.025)
        game.Players.LocalPlayer.Character.HumanoidRootPart.Anchored =  false
        wait(0.1)
        game.Players.LocalPlayer.Character.Humanoid:Destroy()
        wait(0.1)
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame * CFrame.new(0, 20000, 0)
    end
end
)
scripts2:Box("Carry Player", function(p24, p25)
    if p25 then
        local name3 = game.Players.LocalPlayer.name
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer("Client2Client", "Request: Carry!", players[name3])
        wait()
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "BothWantCarryHurt",
            [2] = players[p24],
        }
))
        wait()
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "BothWantCarryHurt",
            [2] = players[p24],
        }
))
        wait()
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "DropButtonStopAll",
            [2] = players[p24],
        }
))
        wait()
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "BothWantCarryHurt",
            [2] = players[name3],
        }
))
        wait()
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "DropButtonStopAll",
            [2] = players[name3],
        }
))
        wait(0.1)
        game.Players.LocalPlayer.Character.HumanoidRootPart.Anchored =  true
        wait(0.05)
        game.Players.LocalPlayer.Character.HumanoidRootPart.Anchored =  false
    end
end
)
scripts2:Box("Bring Player", function(p26, p27)
    if p27 then
        local position3 = players.LocalPlayer.Character.HumanoidRootPart.Position
        local name4 = game.Players.LocalPlayer.name
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer("Client2Client", "Request: Carry!", players[name4])
        wait()
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "BothWantCarryHurt",
            [2] = players[p26],
        }
))
        wait()
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "BothWantCarryHurt",
            [2] = players[p26],
        }
))
        wait()
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "DropButtonStopAll",
            [2] = players[p26],
        }
))
        wait()
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "BothWantCarryHurt",
            [2] = players[name4],
        }
))
        wait()
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "DropButtonStopAll",
            [2] = players[name4],
        }
))
        wait(0.1)
        game.Players.LocalPlayer.Character.HumanoidRootPart.Anchored =  true
        wait(0.05)
        game.Players.LocalPlayer.Character.HumanoidRootPart.Anchored =  false
        wait(0.1)
        game.Players.LocalPlayer.Character.Humanoid:Destroy()
        wait(0.1)
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(position3)
        wait(6)
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(position3)
    end
end
)
scripts2:Toggle("Loop Teleport+Annoy",  false, function(p28)
    annoy = p28
    while annoy and wait(0.1) do
        Players = players
        for key9, value10 in pairs(Players:GetPlayers()) do
            replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
                [1] = "Client2Client",
                [2] = "Request: Piggyback!",
                [3] = players[value10.name],
            }
))
            replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
                [1] = "BothWantPiggyBackRide",
                [2] = players[value10.name],
            }
))
        end
    end
end
)
scripts2:Toggle("Rainbow House",  false, function(p29)
    rainbowh = p29
    while rainbowh and wait() do
        local color = Color3.new(1, 0, 0.0531912)
        replicatedStorage.RemoteEvents.PlayersHouse:FireServer("PickingHouseColor", color)
        wait(0.1)
        local color2 = Color3.new(1, 0, 0.723851)
        replicatedStorage.RemoteEvents.PlayersHouse:FireServer("PickingHouseColor", color2)
        wait(0.1)
        local color3 = Color3.new(0.529121, 0, 1)
        replicatedStorage.RemoteEvents.PlayersHouse:FireServer("PickingHouseColor", color3)
        wait(0.1)
        local color4 = Color3.new(0, 0.192412, 1)
        replicatedStorage.RemoteEvents.PlayersHouse:FireServer("PickingHouseColor", color4)
        wait(0.1)
        local color5 = Color3.new(0.0693014, 1, 0.953011)
        replicatedStorage.RemoteEvents.PlayersHouse:FireServer("PickingHouseColor", color5)
        wait(0.1)
        local color6 = Color3.new(0, 1, 0.188863)
        replicatedStorage.RemoteEvents.PlayersHouse:FireServer("PickingHouseColor", color6)
        wait(0.1)
        local color7 = Color3.new(1, 0.969094, 0.0636657)
        replicatedStorage.RemoteEvents.PlayersHouse:FireServer("PickingHouseColor", color7)
        wait(0.1)
        local color8 = Color3.new(1, 0.969094, 0.0636657)
        replicatedStorage.RemoteEvents.PlayersHouse:FireServer("PickingHouseColor", color8)
        wait(0)
    end
end
)
scripts2:Label("Car Upgrade Gamepass", Color3.fromRGB(127, 143, 166))
scripts2:Toggle("Rainbow Car",  false, function(p30)
    rainbowc = p30
    while rainbowc and wait() do
        local color9 = Color3.new(1, 0, 0.0531912)
        replicatedStorage.RemoteEvents.PlayersCar:FireServer("PickingCarColor", color9)
        wait(0.1)
        local color10 = Color3.new(1, 0, 0.723851)
        replicatedStorage.RemoteEvents.PlayersCar:FireServer("PickingCarColor", color10)
        wait(0.1)
        local color11 = Color3.new(0.529121, 0, 1)
        replicatedStorage.RemoteEvents.PlayersCar:FireServer("PickingCarColor", color11)
        wait(0.1)
        local color12 = Color3.new(0, 0.192412, 1)
        replicatedStorage.RemoteEvents.PlayersCar:FireServer("PickingCarColor", color12)
        wait(0.1)
        local color13 = Color3.new(0.0693014, 1, 0.953011)
        replicatedStorage.RemoteEvents.PlayersCar:FireServer("PickingCarColor", color13)
        wait(0.1)
        local color14 = Color3.new(0, 1, 0.188863)
        replicatedStorage.RemoteEvents.PlayersCar:FireServer("PickingCarColor", color14)
        wait(0.1)
        local color15 = Color3.new(1, 0.969094, 0.0636657)
        replicatedStorage.RemoteEvents.PlayersCar:FireServer("PickingCarColor", color15)
        wait(0.1)
        local color16 = Color3.new(1, 0.969094, 0.0636657)
        replicatedStorage.RemoteEvents.PlayersCar:FireServer("PickingCarColor", color16)
        wait(0)
    end
end
)
local localPlayer = turtle2520Hub:Window("LocalPlayer")
localPlayer:Button("FE Clown Head", function()
    replicatedStorage.RemoteEvents.UpdateAvatar:FireServer("wear", 4272833564)
end
)
localPlayer:Slider("Walkspeed", 16, 120, 0, function(walkSpeed)
    game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = walkSpeed
end
)
localPlayer:Slider("JumpPower", 50, 300, 0, function(jumpPower)
    game.Players.LocalPlayer.Character.Humanoid.JumpPower = jumpPower
end
)
localPlayer:Button("Rejoin Server", function()
    local v15 = game
    teleportService:TeleportToPlaceInstance(game.PlaceId, game.JobId, v15:GetService("Players").LocalPlayer)
end
)
noclip =  false
localPlayer:Toggle("Noclip",  false, function(p31)
    noclip = p31
    runService.Stepped:connect(function()
        if noclip then
            game.Players.LocalPlayer.Character.Humanoid:ChangeState(11)
        end
    end
)
    plr = game.Players.LocalPlayer
    mouse = plr:GetMouse()
    mouse.KeyDown:connect(function(p32)
        if p32 == "e" then
            noclip =  not noclip
            game.Players.LocalPlayer.Character.Humanoid:ChangeState(11)
        end
    end
)
end
)
localPlayer:Button("Reset Character", function()
    game.Players.LocalPlayer.Character.Humanoid:Destroy()
end
)
local giveToolToPlayer = turtle2520Hub:Window("Give Tool To Player")
giveToolToPlayer:Label("Give To All Players", Color3.fromRGB(127, 143, 166))
giveToolToPlayer:Button("Give Money Bag [ALL]", function()
    Players = players
    for key10, value11 in pairs(Players:GetPlayers()) do
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "ToolGiveToServer",
            [2] = players[value11.name],
            [3] = "http://www.roblox.com/asset/?id=4535110571",
            [4] = "Money",
        }
))
    end
end
)
giveToolToPlayer:Button("Give Big Money Bag [ALL]", function()
    Players = players
    for key11, value12 in pairs(Players:GetPlayers()) do
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "ToolGiveToServer",
            [2] = players[value12.name],
            [3] = "http://www.roblox.com/asset/?id=4587924680",
            [4] = "DuffleBagMoney",
        }
))
    end
end
)
giveToolToPlayer:Button("Give Coca Cola [ALL]", function()
    Players = players
    for key12, value13 in pairs(Players:GetPlayers()) do
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "ToolGiveToServer",
            [2] = players[value13.name],
            [3] = "http://www.roblox.com/asset/?id=4548052009",
            [4] = "Coke",
        }
))
    end
end
)
giveToolToPlayer:Button("Give Stroller [ALL]", function()
    Players = players
    for key13, value14 in pairs(Players:GetPlayers()) do
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "ToolGiveToServer",
            [2] = players[value14.name],
            [3] = "http://www.roblox.com/asset/?id=4529218345",
            [4] = "Stroller",
        }
))
    end
end
)
giveToolToPlayer:Button("Give Hairbrush [ALL]", function()
    Players = players
    for key14, value15 in pairs(Players:GetPlayers()) do
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "ToolGiveToServer",
            [2] = players[value15.name],
            [3] = "http://www.roblox.com/asset/?id=5480682123",
            [4] = "Hairbrush",
        }
))
    end
end
)
giveToolToPlayer:Button("Give Sign [ALL]", function()
    Players = players
    for key15, value16 in pairs(Players:GetPlayers()) do
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "ToolGiveToServer",
            [2] = players[value16.name],
            [3] = "http://www.roblox.com/asset/?id=6001822792",
            [4] = "Sign",
        }
))
    end
end
)
giveToolToPlayer:Button("Give Rose [ALL]", function()
    Players = players
    for key16, value17 in pairs(Players:GetPlayers()) do
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "ToolGiveToServer",
            [2] = players[value17.name],
            [3] = "http://www.roblox.com/asset/?id=5211788490",
            [4] = "Roses",
        }
))
    end
end
)
giveToolToPlayer:Button("Give Soccer Ball [ALL]", function()
    Players = players
    for key17, value18 in pairs(Players:GetPlayers()) do
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "ToolGiveToServer",
            [2] = players[value18.name],
            [3] = "http://www.roblox.com/asset/?id=4598172149",
            [4] = "SoccerBall",
        }
))
    end
end
)
giveToolToPlayer:Button("Give Gun [ALL]", function()
    Players = players
    for key18, value19 in pairs(Players:GetPlayers()) do
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "ToolGiveToServer",
            [2] = players[value19.name],
            [3] = "http://www.roblox.com/asset/?id=4529288610",
            [4] = "Assault",
        }
))
    end
end
)
giveToolToPlayer:Button("Give C4 [ALL]", function()
    Players = players
    for key19, value20 in pairs(Players:GetPlayers()) do
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "ToolGiveToServer",
            [2] = players[value20.name],
            [3] = "http://www.roblox.com/asset/?id=4587924290",
            [4] = "Bomb",
        }
))
    end
end
)
giveToolToPlayer:Button("Give Shovel [ALL]", function()
    Players = players
    for key20, value21 in pairs(Players:GetPlayers()) do
        replicatedStorage.RemoteEvents.PlayerTriggerEvent:FireServer(unpack({
            [1] = "ToolGiveToServer",
            [2] = players[value21.name],
            [3] = "http://www.roblox.com/asset/?id=4617189079",
            [4] = "Shovel",
        }
))
    end
end
)
giveToolToPlayer:Label("Give To Yourself", Color3.fromRGB(127, 143, 166))
giveToolToPlayer:Dropdown("Give Yourself Item", {
    "Iphone",
    "Camcorder",
    "BabyBoy",
    "BabyGirl",
    "Wagon",
    "Sign",
    "Syringe",
    "Ear",
    "Trophy",
    "Taser",
    "SWATShield",
    "Cuffs",
    "Glock",
    "Shotgun",
    "Assault",
    "Sniper",
    "Bomb",
    "DuffleBagMoney",
    "Money",
    "CreditCardBoy",
    "CreditCardGirl",
    "Umbrella",
    "Roses",
    "Present",
    "SoccerBall",
    "Apple",
    "Chips",
    "Bloxaide",
    "Milk",
}, function(p33)
    replicatedStorage.RemoteEvents.Tools:InvokeServer(unpack({
        [1] = "PickingTools",
        [2] = p33
    }
))
end
)
local spawnCars = turtle2520Hub:Window("Spawn Cars")
spawnCars:Label("Instant Spawn Cars", Color3.fromRGB(127, 143, 166))
spawnCars:Button("Scooter", function()
    replicatedStorage.RemoteEvents.Car:FireServer(unpack({
        [1] = "PickingCar",
        [2] = "ScooterVehicle",
    }
))
end
)
spawnCars:Button("NPHarleyDavison", function()
    replicatedStorage.RemoteEvents.Car:FireServer(unpack({
        [1] = "PickingCar",
        [2] = "NPHarleyDavison",
    }
))
end
)
spawnCars:Button("Cadillac", function()
    replicatedStorage.RemoteEvents.Car:FireServer(unpack({
        [1] = "PickingCar",
        [2] = "Cadillac"
    }
))
end
)
spawnCars:Button("CopChallenger", function()
    replicatedStorage.RemoteEvents.Car:FireServer(unpack({
        [1] = "PickingCar",
        [2] = "CopChallenger",
    }
))
end
)
spawnCars:Button("Challenger", function()
    replicatedStorage.RemoteEvents.Car:FireServer(unpack({
        [1] = "PickingCar",
        [2] = "Challenger"
    }
))
end
)
spawnCars:Button("Bus", function()
    replicatedStorage.RemoteEvents.Car:FireServer(unpack({
        [1] = "PickingCar",
        [2] = "Bus"
    }
))
end
)
spawnCars:Button("Jeep", function()
    replicatedStorage.RemoteEvents.Car:FireServer(unpack({
        [1] = "PickingCar",
        [2] = "Jeep"
    }
))
end
)
spawnCars:Button("FireTruck", function()
    replicatedStorage.RemoteEvents.Car:FireServer(unpack({
        [1] = "PickingCar",
        [2] = "FireTruck"
    }
))
end
)
spawnCars:Button("CopUnderCoverSUV", function()
    replicatedStorage.RemoteEvents.Car:FireServer(unpack({
        [1] = "PickingCar",
        [2] = "CopUnderCoverSUV",
    }
))
end
)
spawnCars:Button("GolfCart", function()
    replicatedStorage.RemoteEvents.Car:FireServer(unpack({
        [1] = "PickingCar",
        [2] = "GolfCart"
    }
))
end
)
spawnCars:Button("Van", function()
    replicatedStorage.RemoteEvents.Car:FireServer(unpack({
        [1] = "PickingCar",
        [2] = "Van"
    }
))
end
)
spawnCars:Button("FordGT", function()
    replicatedStorage.RemoteEvents.Car:FireServer(unpack({
        [1] = "PickingCar",
        [2] = "FordGT"
    }
))
end
)
spawnCars:Button("CopSUV", function()
    replicatedStorage.RemoteEvents.Car:FireServer(unpack({
        [1] = "PickingCar",
        [2] = "CopSUV"
    }
))
end
)
spawnCars:Button("RV", function()
    replicatedStorage.RemoteEvents.Car:FireServer(unpack({
        [1] = "PickingCar",
        [2] = "RV"
    }
))
end
)
local serverSideFunTags = turtle2520Hub:Window("Server-Side Fun Tags")
serverSideFunTags:Button("Admin Tag 1", function()
    replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
        [1] = "GiveJobUIMenu",
        [2] = "782790468",
        [3] = "Made by Sapphire Hub",
        [4] =  true,
    }
))
end
)
serverSideFunTags:Button("Admin Tag 2", function()
    replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
        [1] = "GiveJobUIMenu",
        [2] = "105095367",
        [3] = "Made by Sapphire Hub",
        [4] =  true,
    }
))
end
)
serverSideFunTags:Button("Normal VIP Tag", function()
    replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
        [1] = "GiveJobUIMenu",
        [2] = "1292335373",
        [3] = "Made by Sapphire Hub",
        [4] =  true,
    }
))
end
)
serverSideFunTags:Button("Mega VIP Tag", function()
    replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
        [1] = "GiveJobUIMenu",
        [2] = "1255544221",
        [3] = "Made by Sapphire Hub",
        [4] =  true,
    }
))
end
)
serverSideFunTags:Button("Ultra VIP Tag", function()
    replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
        [1] = "GiveJobUIMenu",
        [2] = "1292342698",
        [3] = "Made by Sapphire Hub",
        [4] =  true,
    }
))
end
)
serverSideFunTags:Button("VIP Tag", function()
    replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
        [1] = "GiveJobUIMenu",
        [2] = "32578003",
        [3] = "Made by Sapphire Hub",
        [4] =  true,
    }
))
end
)
serverSideFunTags:Button("Moderator Tag", function()
    replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
        [1] = "GiveJobUIMenu",
        [2] = "415986666",
        [3] = "Made by Sapphire Hub",
        [4] =  true,
    }
))
end
)
serverSideFunTags:Button("Owner Tag", function()
    replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
        [1] = "GiveJobUIMenu",
        [2] = "2980546857",
        [3] = "Made by Sapphire Hub",
        [4] =  true,
    }
))
end
)
serverSideFunTags:Button("Creator Tag", function()
    replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
        [1] = "GiveJobUIMenu",
        [2] = "2497143214",
        [3] = "Made by Sapphire Hub",
        [4] =  true,
    }
))
end
)
serverSideFunTags:Button("Brookhaven Logo Tag", function()
    replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
        [1] = "GiveJobUIMenu",
        [2] = "6336646536",
        [3] = "Made by Sapphire Hub",
        [4] =  true,
    }
))
end
)
serverSideFunTags:Button("Pikachu Tag", function()
    replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
        [1] = "GiveJobUIMenu",
        [2] = "1473416194",
        [3] = "Made by Sapphire Hub",
        [4] =  true,
    }
))
end
)
serverSideFunTags:Button("Hacker Face Tag", function()
    replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
        [1] = "GiveJobUIMenu",
        [2] = "3284478282",
        [3] = "Made by Sapphire Hub",
        [4] =  true,
    }
))
end
)
serverSideFunTags:Button("Scary Pikachu Tag", function()
    replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
        [1] = "GiveJobUIMenu",
        [2] = "127039538",
        [3] = "Made by Sapphire Hub",
        [4] =  true,
    }
))
end
)
serverSideFunTags:Button("HD Tag", function()
    replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
        [1] = "GiveJobUIMenu",
        [2] = "2821573888",
        [3] = "Made by Sapphire Hub",
        [4] =  true,
    }
))
end
)
serverSideFunTags:Button("Old Roblox Logo Tag", function()
    replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
        [1] = "GiveJobUIMenu",
        [2] = "148012526",
        [3] = "Made by Sapphire Hub",
        [4] =  true,
    }
))
end
)
serverSideFunTags:Button("Roblox Admin Logo Tag", function()
    replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
        [1] = "GiveJobUIMenu",
        [2] = "1151106808",
        [3] = "Made by Sapphire Hub",
        [4] =  true,
    }
))
end
)
serverSideFunTags:Button("Diamond Tag", function()
    replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
        [1] = "GiveJobUIMenu",
        [2] = "4424298",
        [3] = "Made by Sapphire Hub",
        [4] =  true,
    }
))
end
)
serverSideFunTags:Button("Hacking Tag", function()
    replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
        [1] = "GiveJobUIMenu",
        [2] = "626372353",
        [3] = "Made by Sapphire Hub",
        [4] =  true,
    }
))
end
)
serverSideFunTags:Button("Nascar Car Tag", function()
    replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
        [1] = "GiveJobUIMenu",
        [2] = "463277467",
        [3] = "Made by Sapphire Hub",
        [4] =  true,
    }
))
end
)
serverSideFunTags:Button("Girl Face Tag", function()
    replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
        [1] = "GiveJobUIMenu",
        [2] = "555878469",
        [3] = "Made by Sapphire Hub",
        [4] =  true,
    }
))
end
)
serverSideFunTags:Button("Wall Tag", function()
    replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
        [1] = "GiveJobUIMenu",
        [2] = "1844422643",
        [3] = "Made by Sapphire Hub",
        [4] =  true,
    }
))
end
)
serverSideFunTags:Button("Meme Tag", function()
    replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
        [1] = "GiveJobUIMenu",
        [2] = "261677904",
        [3] = "Made by Sapphire Hub",
        [4] =  true,
    }
))
end
)
serverSideFunTags:Button("Coffee Meme Tag", function()
    replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
        [1] = "GiveJobUIMenu",
        [2] = "261676710",
        [3] = "Made by Sapphire Hub",
        [4] =  true,
    }
))
end
)
serverSideFunTags:Label("Scary", Color3.fromRGB(127, 143, 166))
serverSideFunTags:Button("Scary Face Tag", function()
    replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
        [1] = "GiveJobUIMenu",
        [2] = "1243374078",
        [3] = "Made by Sapphire Hub",
        [4] =  true,
    }
))
end
)
serverSideFunTags:Button("2 Eye Tag", function()
    replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
        [1] = "GiveJobUIMenu",
        [2] = "5839301773",
        [3] = "Made by Sapphire Hub",
        [4] =  true,
    }
))
end
)
serverSideFunTags:Button("Scary Tag", function()
    replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
        [1] = "GiveJobUIMenu",
        [2] = "2120834873",
        [3] = "Made by Sapphire Hub",
        [4] =  true,
    }
))
end
)
serverSideFunTags:Button("Smiley Face Tag", function()
    replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
        [1] = "GiveJobUIMenu",
        [2] = "333476199",
        [3] = "Made by Sapphire Hub",
        [4] =  true,
    }
))
end
)
serverSideFunTags:Button("Scary Dog Tag", function()
    replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
        [1] = "GiveJobUIMenu",
        [2] = "5817435822",
        [3] = "Made by Sapphire Hub",
        [4] =  true,
    }
))
end
)
serverSideFunTags:Button("Scary Cat", function()
    replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
        [1] = "GiveJobUIMenu",
        [2] = "23355113",
        [3] = "Made by Sapphire Hub",
        [4] =  true,
    }
))
end
)
serverSideFunTags:Box("Custom Image", function(p34, p35)
    if p35 then
        replicatedStorage.RemoteEvents.Jobs:FireServer(unpack({
            [1] = "GiveJobUIMenu",
            [2] = p34,
            [3] = "Made by Sapphire Hub",
            [4] =  true,
        }
))
    end
end
)
turtle2520Hub:Keybind("Tab")