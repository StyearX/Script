-- Lynd Deobfuscator & Dumper | https://discord.gg/SRvRc2XF6s
-- Rinkaza Lularphed
-- Deobf by lynd

local players = game:GetService("Players")
local coreGui = game:GetService("CoreGui")
local tweenService = game:GetService("TweenService")
local soundService = game:GetService("SoundService")
local runService = game:GetService("RunService")
local userInputService = game:GetService("UserInputService")
local lighting = game:GetService("Lighting")
local teleportService = game:GetService("TeleportService")
local virtualUser = game:GetService("VirtualUser")
local replicatedStorage = game:GetService("ReplicatedStorage")
print("RINKAZE PANEL v4.5 Loading...")
local v1, v2 = pcall(function()
    local localPlayer = players.LocalPlayer
    local getMouse = localPlayer:GetMouse()
    local rinkazePanelGui = Instance.new("ScreenGui")
    rinkazePanelGui.Name = "RinkazePanelGui"
    rinkazePanelGui.ResetOnSpawn =  false
    rinkazePanelGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
    pcall(function()
        if gethui then
            rinkazePanelGui.Parent = gethui()
        else
            rinkazePanelGui.Parent = coreGui
        end
    end
)
    if not rinkazePanelGui.Parent then
        rinkazePanelGui.Parent = localPlayer:WaitForChild("PlayerGui")
    end
    local v3 = {
        Y4XYT2 =  true,
        CRYPTONXRAY =  true,
        Deepanshi1306 =  true,
        Priya_98976 =  true,
        VAMPIRE_BLOX82 =  true,
        ITSMEREALEVI =  true,
        VOLMELXH7JRYASH =  true,
        bloxcola821 =  true,
        Itsfact620 =  true,
        shah_moksh054 =  true,
        Youlight2 =  true,
    }
    local function f1(p1)
        if not p1 then
            return false
        end
        return v3[p1.Name] ==  true
    end
    local sound = Instance.new("Sound")
    sound.SoundId = "rbxassetid://6895079853"
    sound.Volume = 1.5
    sound.Parent = soundService
    local sound2 = Instance.new("Sound")
    sound2.SoundId = "rbxassetid://6895079853"
    sound2.PlaybackSpeed = 0.75
    sound2.Volume = 1.2
    sound2.Parent = soundService
    local sound3 = Instance.new("Sound")
    sound3.SoundId = "rbxassetid://6518811702"
    sound3.Volume = 1.5
    sound3.Parent = soundService
    local frame = Instance.new("Frame")
    frame.Parent = rinkazePanelGui
    frame.BackgroundColor3 = Color3.fromRGB(10, 20, 35)
    frame.BorderSizePixel = 0
    frame.Position = UDim2.new(1, 260, 0.82, 0)
    frame.Size = UDim2.new(0, 250, 0, 60)
    frame.AnchorPoint = Vector2.new(0, 0.5)
    Instance.new("UICorner", frame).CornerRadius = UDim.new(0, 10)
    Instance.new("UIStroke", frame).Color = Color3.fromRGB(0, 170, 255)
    local instance = Instance.new("TextLabel", frame)
    instance.BackgroundTransparency = 1
    instance.Position = UDim2.new(0, 12, 0, 8)
    instance.Size = UDim2.new(1,  - 24, 0, 18)
    instance.Font = Enum.Font.GothamBold
    instance.Text = "TARGET LEFT!"
    instance.TextColor3 = Color3.fromRGB(0, 195, 255)
    instance.TextSize = 13
    instance.TextXAlignment = Enum.TextXAlignment.Left
    local instance2 = Instance.new("TextLabel", frame)
    instance2.BackgroundTransparency = 1
    instance2.Position = UDim2.new(0, 12, 0, 28)
    instance2.Size = UDim2.new(1,  - 24, 0, 24)
    instance2.Font = Enum.Font.GothamMedium
    instance2.Text = "Player left the game."
    instance2.TextColor3 = Color3.fromRGB(180, 225, 255)
    instance2.TextSize = 11
    instance2.TextXAlignment = Enum.TextXAlignment.Left
    local function f2(p2, p3)
        instance2.Text = p2.. " ("..p3.. ") left the server!"
        sound3:Play()
        tweenService:Create(frame, TweenInfo.new(0.4, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
            Position = UDim2.new(1,
            -             265,
            0.82,
            0)
        }
):Play()
        task.delay(3.5, function()
            tweenService:Create(frame, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
                Position = UDim2.new(1,
                260,
                0.82,
                0)
            }
):Play()
        end
)
    end
    local mainFrame = Instance.new("Frame")
    mainFrame.Name = "MainFrame"
    mainFrame.Parent = rinkazePanelGui
    mainFrame.BackgroundColor3 = Color3.fromRGB(8, 14, 26)
    mainFrame.BorderSizePixel = 0
    mainFrame.Position = UDim2.new(0.5, 0, 0.5, 0)
    mainFrame.Size = UDim2.new(0, 520, 0, 330)
    mainFrame.AnchorPoint = Vector2.new(0.5, 0.5)
    mainFrame.Active =  true
    mainFrame.Draggable =  true
    mainFrame.ClipsDescendants =  true
    mainFrame.Visible =  false
    Instance.new("UICorner", mainFrame).CornerRadius = UDim.new(0, 12)
    local instance3 = Instance.new("UIStroke", mainFrame)
    instance3.Color = Color3.fromRGB(0, 150, 255)
    instance3.Thickness = 1.5
    local instance4 = Instance.new("Frame", mainFrame)
    instance4.BackgroundColor3 = Color3.fromRGB(5, 9, 18)
    instance4.BorderSizePixel = 0
    instance4.Size = UDim2.new(1, 0, 0, 38)
    local instance5 = Instance.new("TextLabel", instance4)
    instance5.BackgroundTransparency = 1
    instance5.Position = UDim2.new(0, 14, 0, 0)
    instance5.Size = UDim2.new(1,  - 50, 1, 0)
    instance5.Font = Enum.Font.GothamBold
    instance5.Text = "RINKAZE PANEL"
    instance5.TextColor3 = Color3.fromRGB(0, 195, 255)
    instance5.TextSize = 16
    instance5.TextXAlignment = Enum.TextXAlignment.Left
    local instance6 = Instance.new("TextLabel", instance4)
    instance6.BackgroundTransparency = 1
    instance6.Position = UDim2.new(0, 135, 0, 1)
    instance6.Size = UDim2.new(0, 120, 1, 0)
    instance6.Font = Enum.Font.GothamMedium
    instance6.Text = "| Brookhaven RP"
    instance6.TextColor3 = Color3.fromRGB(80, 140, 180)
    instance6.TextSize = 12
    instance6.TextXAlignment = Enum.TextXAlignment.Left
    local instance7 = Instance.new("TextButton", instance4)
    instance7.BackgroundTransparency = 1
    instance7.Position = UDim2.new(1,  - 35, 0, 4)
    instance7.Size = UDim2.new(0, 30, 0, 30)
    instance7.Font = Enum.Font.GothamBold
    instance7.Text = "X"
    instance7.TextColor3 = Color3.fromRGB(120, 190, 255)
    instance7.TextSize = 14
    local instance8 = Instance.new("Frame", mainFrame)
    instance8.BackgroundColor3 = Color3.fromRGB(5, 10, 20)
    instance8.BorderSizePixel = 0
    instance8.Position = UDim2.new(0, 0, 0, 38)
    instance8.Size = UDim2.new(0, 125, 1,  - 38)
    local instance9 = Instance.new("UIListLayout", instance8)
    instance9.SortOrder = Enum.SortOrder.LayoutOrder
    instance9.Padding = UDim.new(0, 3)
    local instance10 = Instance.new("UIPadding", instance8)
    instance10.PaddingTop = UDim.new(0, 6)
    instance10.PaddingLeft = UDim.new(0, 6)
    instance10.PaddingRight = UDim.new(0, 6)
    local instance11 = Instance.new("Frame", mainFrame)
    instance11.BackgroundColor3 = Color3.fromRGB(10, 18, 32)
    instance11.BorderSizePixel = 0
    instance11.Position = UDim2.new(0, 125, 0, 38)
    instance11.Size = UDim2.new(1,  - 125, 1,  - 38)
    local instance12 = Instance.new("UIPadding", instance11)
    instance12.PaddingTop = UDim.new(0, 10)
    instance12.PaddingLeft = UDim.new(0, 12)
    instance12.PaddingRight = UDim.new(0, 12)
    local v4 = {
    }
    local function f3(p4)
        local frame2 = Instance.new("Frame")
        frame2.Name = p4.. "Frame"
        frame2.Parent = instance11
        frame2.BackgroundTransparency = 1
        frame2.Size = UDim2.new(1, 0, 1, 0)
        frame2.Visible =  false
        v4[p4] = frame2
        return frame2
    end
    local home = f3("Home")
    home.Visible =  true
    local instance13 = Instance.new("Frame", home)
    instance13.BackgroundColor3 = Color3.fromRGB(14, 26, 46)
    instance13.Size = UDim2.new(1, 0, 0, 65)
    Instance.new("UICorner", instance13).CornerRadius = UDim.new(0, 8)
    local instance14 = Instance.new("ImageLabel", instance13)
    instance14.Position = UDim2.new(0, 8, 0, 8)
    instance14.Size = UDim2.new(0, 48, 0, 48)
    instance14.BackgroundColor3 = Color3.fromRGB(20, 40, 70)
    instance14.Image = "https://www.roblox.com/headshot-thumbnail/image?userId="..localPlayer.UserId.. "&width=420&height=420&format=png"
    Instance.new("UICorner", instance14).CornerRadius = UDim.new(1, 0)
    local instance15 = Instance.new("TextLabel", instance13)
    instance15.BackgroundTransparency = 1
    instance15.Position = UDim2.new(0, 64, 0, 10)
    instance15.Size = UDim2.new(1,  - 150, 0, 20)
    instance15.Font = Enum.Font.GothamBold
    instance15.Text = "Welcome, "..localPlayer.DisplayName
    instance15.TextColor3 = Color3.fromRGB(180, 225, 255)
    instance15.TextSize = 13
    instance15.TextXAlignment = Enum.TextXAlignment.Left
    local instance16 = Instance.new("TextLabel", instance13)
    instance16.BackgroundTransparency = 1
    instance16.Position = UDim2.new(0, 64, 0, 30)
    instance16.Size = UDim2.new(1,  - 150, 0, 18)
    instance16.Font = Enum.Font.GothamMedium
    instance16.Text = "@"..localPlayer.Name
    instance16.TextColor3 = Color3.fromRGB(80, 140, 190)
    instance16.TextSize = 11
    instance16.TextXAlignment = Enum.TextXAlignment.Left
    local instance17 = Instance.new("Frame", home)
    instance17.BackgroundColor3 = Color3.fromRGB(12, 22, 38)
    instance17.Position = UDim2.new(0, 0, 0, 80)
    instance17.Size = UDim2.new(1, 0, 0, 180)
    Instance.new("UICorner", instance17).CornerRadius = UDim.new(0, 8)
    local instance18 = Instance.new("TextLabel", instance17)
    instance18.BackgroundTransparency = 1
    instance18.Position = UDim2.new(0, 12, 0, 8)
    instance18.Size = UDim2.new(1,  - 24, 0, 18)
    instance18.Font = Enum.Font.GothamBold
    instance18.Text = "🔥 RINKAZE PANEL v4.5"
    instance18.TextColor3 = Color3.fromRGB(0, 195, 255)
    instance18.TextSize = 13
    instance18.TextXAlignment = Enum.TextXAlignment.Left
    local instance19 = Instance.new("TextLabel", instance17)
    instance19.BackgroundTransparency = 1
    instance19.Position = UDim2.new(0, 12, 0, 32)
    instance19.Size = UDim2.new(1,  - 24, 0, 140)
    instance19.Font = Enum.Font.GothamMedium
    instance19.Text = "• CHOCO BANG Fixed (No self fling)\n• Bus/Couch Fling Improved\n• Protected Players System\n• MADE BY YASH"
    instance19.TextColor3 = Color3.fromRGB(160, 210, 255)
    instance19.TextSize = 12
    instance19.TextWrapped =  true
    instance19.TextXAlignment = Enum.TextXAlignment.Left
    instance19.TextYAlignment = Enum.TextYAlignment.Top
    local v5 = f3("Game")
    local instance20 = Instance.new("ScrollingFrame", v5)
    instance20.BackgroundTransparency = 1
    instance20.Size = UDim2.new(1, 0, 1, 0)
    instance20.CanvasSize = UDim2.new(0, 0, 0, 280)
    instance20.ScrollBarThickness = 4
    instance20.ScrollBarImageColor3 = Color3.fromRGB(0, 150, 255)
    Instance.new("UIListLayout", instance20).Padding = UDim.new(0, 8)
    local function f4(text)
        local instance21 = Instance.new("TextButton", instance20)
        instance21.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
        instance21.Size = UDim2.new(1,  - 10, 0, 38)
        instance21.Font = Enum.Font.GothamBold
        instance21.Text = text
        instance21.TextColor3 = Color3.fromRGB(255, 255, 255)
        instance21.TextSize = 13
        Instance.new("UICorner", instance21).CornerRadius = UDim.new(0, 8)
        return instance21
    end
    local antiFlingOFF = f4("Anti Fling: OFF")
    local antiAFKOFF = f4("Anti AFK: OFF")
    local shadersOFF = f4("Shaders: OFF")
    local rejoin = f4("Rejoin")
    local v6 =  false
    local v7 =  false
    local v8 =  false
    local v9 = {
    }
    local connect
    antiFlingOFF.MouseButton1Click:Connect(function()
        v6 =  not v6
        if v6 then
            antiFlingOFF.Text = "Anti Fling: ON"
            antiFlingOFF.BackgroundColor3 = Color3.fromRGB(0, 180, 120)
            connect = runService.Heartbeat:Connect(function()
                local character = localPlayer.Character
                if character then
                    for index, value in ipairs(character:GetDescendants()) do
                        if value:IsA("BasePart") then
                            if value.AssemblyLinearVelocity.Magnitude > 120 then
                                value.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
                                value.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
                            end
                        end
                    end
                end
            end
)
        else
            antiFlingOFF.Text = "Anti Fling: OFF"
            antiFlingOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
            if connect then
                connect:Disconnect()
                connect =  nil
            end
        end
    end
)
    local connect2
    antiAFKOFF.MouseButton1Click:Connect(function()
        v7 =  not v7
        if v7 then
            antiAFKOFF.Text = "Anti AFK: ON"
            antiAFKOFF.BackgroundColor3 = Color3.fromRGB(0, 180, 120)
            connect2 = localPlayer.Idled:Connect(function()
                virtualUser:CaptureController()
                virtualUser:ClickButton2(Vector2.new())
            end
)
        else
            antiAFKOFF.Text = "Anti AFK: OFF"
            antiAFKOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
            if connect2 then
                connect2:Disconnect()
                connect2 =  nil
            end
        end
    end
)
    shadersOFF.MouseButton1Click:Connect(function()
        v8 =  not v8
        if v8 then
            shadersOFF.Text = "Shaders: ON"
            shadersOFF.BackgroundColor3 = Color3.fromRGB(0, 180, 120)
            local sky = Instance.new("Sky")
            sky.SkyboxBk = "http://www.roblox.com/asset/?id=144933338"
            sky.SkyboxDn = "http://www.roblox.com/asset/?id=144931530"
            sky.SkyboxFt = "http://www.roblox.com/asset/?id=144933262"
            sky.SkyboxLf = "http://www.roblox.com/asset/?id=144933244"
            sky.SkyboxRt = "http://www.roblox.com/asset/?id=144933299"
            sky.SkyboxUp = "http://www.roblox.com/asset/?id=144931564"
            sky.StarCount = 5000
            sky.Parent = lighting
            table.insert(v9, sky)
            local bloomEffect = Instance.new("BloomEffect")
            bloomEffect.Intensity = 0.3
            bloomEffect.Size = 10
            bloomEffect.Threshold = 0.8
            bloomEffect.Parent = lighting
            table.insert(v9, bloomEffect)
            local colorCorrectionEffect = Instance.new("ColorCorrectionEffect")
            colorCorrectionEffect.Contrast = 0.1
            colorCorrectionEffect.Saturation = 0.25
            colorCorrectionEffect.Parent = lighting
            table.insert(v9, colorCorrectionEffect)
            lighting.Brightness = 2.25
            lighting.ClockTime = 17.55
        else
            shadersOFF.Text = "Shaders: OFF"
            shadersOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
            for index2, value2 in ipairs(v9) do
            end
            v9 = {
            }
            lighting.Brightness = 2
        end
    end
)
    rejoin.MouseButton1Click:Connect(function()
        teleportService:TeleportToPlaceInstance(game.PlaceId, game.JobId, localPlayer)
    end
)
    local character2 = f3("Character")
    local instance22 = Instance.new("ScrollingFrame", character2)
    instance22.BackgroundTransparency = 1
    instance22.Size = UDim2.new(1, 0, 1, 0)
    instance22.CanvasSize = UDim2.new(0, 0, 0, 480)
    instance22.ScrollBarThickness = 4
    instance22.ScrollBarImageColor3 = Color3.fromRGB(0, 150, 255)
    Instance.new("UIListLayout", instance22).Padding = UDim.new(0, 8)
    local function f5(text2)
        local instance23 = Instance.new("TextButton", instance22)
        instance23.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
        instance23.Size = UDim2.new(1,  - 10, 0, 36)
        instance23.Font = Enum.Font.GothamBold
        instance23.Text = text2
        instance23.TextColor3 = Color3.fromRGB(255, 255, 255)
        instance23.TextSize = 13
        Instance.new("UICorner", instance23).CornerRadius = UDim.new(0, 8)
        return instance23
    end
    local instance24 = Instance.new("Frame", instance22)
    instance24.BackgroundColor3 = Color3.fromRGB(12, 22, 38)
    instance24.Size = UDim2.new(1,  - 10, 0, 40)
    Instance.new("UICorner", instance24).CornerRadius = UDim.new(0, 8)
    local instance25 = Instance.new("TextButton", instance24)
    instance25.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
    instance25.Position = UDim2.new(0, 6, 0, 5)
    instance25.Size = UDim2.new(0, 110, 0, 30)
    instance25.Font = Enum.Font.GothamBold
    instance25.Text = "Walk Speed"
    instance25.TextColor3 = Color3.fromRGB(255, 255, 255)
    instance25.TextSize = 12
    Instance.new("UICorner", instance25).CornerRadius = UDim.new(0, 6)
    local instance26 = Instance.new("TextBox", instance24)
    instance26.BackgroundColor3 = Color3.fromRGB(20, 35, 55)
    instance26.Position = UDim2.new(0, 125, 0, 5)
    instance26.Size = UDim2.new(1,  - 135, 0, 30)
    instance26.Font = Enum.Font.Gotham
    instance26.PlaceholderText = "16"
    instance26.Text = ""
    instance26.TextColor3 = Color3.fromRGB(255, 255, 255)
    instance26.TextSize = 13
    Instance.new("UICorner", instance26).CornerRadius = UDim.new(0, 6)
    instance25.MouseButton1Click:Connect(function()
        local walkSpeed = tonumber(instance26.Text) or 16
        if localPlayer.Character and localPlayer.Character:FindFirstChildOfClass("Humanoid") then
            local character3 = localPlayer.Character
            character3:FindFirstChildOfClass("Humanoid").WalkSpeed = walkSpeed
        end
    end
)
    local instance27 = Instance.new("Frame", instance22)
    instance27.BackgroundColor3 = Color3.fromRGB(12, 22, 38)
    instance27.Size = UDim2.new(1,  - 10, 0, 40)
    Instance.new("UICorner", instance27).CornerRadius = UDim.new(0, 8)
    local instance28 = Instance.new("TextButton", instance27)
    instance28.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
    instance28.Position = UDim2.new(0, 6, 0, 5)
    instance28.Size = UDim2.new(0, 110, 0, 30)
    instance28.Font = Enum.Font.GothamBold
    instance28.Text = "Jump Power"
    instance28.TextColor3 = Color3.fromRGB(255, 255, 255)
    instance28.TextSize = 12
    Instance.new("UICorner", instance28).CornerRadius = UDim.new(0, 6)
    local instance29 = Instance.new("TextBox", instance27)
    instance29.BackgroundColor3 = Color3.fromRGB(20, 35, 55)
    instance29.Position = UDim2.new(0, 125, 0, 5)
    instance29.Size = UDim2.new(1,  - 135, 0, 30)
    instance29.Font = Enum.Font.Gotham
    instance29.PlaceholderText = "50"
    instance29.Text = ""
    instance29.TextColor3 = Color3.fromRGB(255, 255, 255)
    instance29.TextSize = 13
    Instance.new("UICorner", instance29).CornerRadius = UDim.new(0, 6)
    instance28.MouseButton1Click:Connect(function()
        local jumpPower = tonumber(instance29.Text) or 50
        if localPlayer.Character and localPlayer.Character:FindFirstChildOfClass("Humanoid") then
            local character4 = localPlayer.Character
            character4:FindFirstChildOfClass("Humanoid").JumpPower = jumpPower
        end
    end
)
    local flyOFF = f5("Fly: OFF")
    local instance30 = Instance.new("Frame", instance22)
    instance30.BackgroundColor3 = Color3.fromRGB(12, 22, 38)
    instance30.Size = UDim2.new(1,  - 10, 0, 40)
    instance30.Visible =  false
    Instance.new("UICorner", instance30).CornerRadius = UDim.new(0, 8)
    local instance31 = Instance.new("TextLabel", instance30)
    instance31.BackgroundTransparency = 1
    instance31.Position = UDim2.new(0, 12, 0, 5)
    instance31.Size = UDim2.new(0, 120, 0, 30)
    instance31.Font = Enum.Font.GothamBold
    instance31.Text = "Fly Speed: 50"
    instance31.TextColor3 = Color3.fromRGB(160, 220, 255)
    instance31.TextSize = 13
    instance31.TextXAlignment = Enum.TextXAlignment.Left
    local instance32 = Instance.new("TextButton", instance30)
    instance32.BackgroundColor3 = Color3.fromRGB(0, 100, 180)
    instance32.Position = UDim2.new(1,  - 90, 0, 5)
    instance32.Size = UDim2.new(0, 36, 0, 30)
    instance32.Font = Enum.Font.GothamBold
    instance32.Text = "-"
    instance32.TextColor3 = Color3.fromRGB(255, 255, 255)
    instance32.TextSize = 18
    Instance.new("UICorner", instance32).CornerRadius = UDim.new(0, 6)
    local instance33 = Instance.new("TextButton", instance30)
    instance33.BackgroundColor3 = Color3.fromRGB(0, 100, 180)
    instance33.Position = UDim2.new(1,  - 45, 0, 5)
    instance33.Size = UDim2.new(0, 36, 0, 30)
    instance33.Font = Enum.Font.GothamBold
    instance33.Text = "+"
    instance33.TextColor3 = Color3.fromRGB(255, 255, 255)
    instance33.TextSize = 18
    Instance.new("UICorner", instance33).CornerRadius = UDim.new(0, 6)
    local noclipOFF = f5("Noclip: OFF")
    local nositOFF = f5("Nosit: OFF")
    local voidProtectionOFF = f5("Void Protection: OFF")
    local respawn = f5("Respawn")
    local v10 =  false
    local v11 = 50
    local bodyGyro, bodyVelocity, connect3
    local function f6()
        local character5 = localPlayer.Character
        if not character5 then
            return
        end
        local humanoidRootPart = character5:FindFirstChild("HumanoidRootPart")
        local humanoid = character5:FindFirstChildOfClass("Humanoid")
        if not humanoidRootPart or not humanoid then
            return
        end
        humanoid.PlatformStand =  true
        bodyGyro = Instance.new("BodyGyro")
        bodyGyro.P = 90000
        bodyGyro.maxTorque = Vector3.new(9000000000, 9000000000, 9000000000)
        bodyGyro.cframe = humanoidRootPart.CFrame
        bodyGyro.Parent = humanoidRootPart
        bodyVelocity = Instance.new("BodyVelocity")
        bodyVelocity.velocity = Vector3.new(0, 0, 0)
        bodyVelocity.maxForce = Vector3.new(9000000000, 9000000000, 9000000000)
        bodyVelocity.Parent = humanoidRootPart
        connect3 = runService.RenderStepped:Connect(function()
            if not v10 or not humanoidRootPart or not humanoid then
                return
            else
                local currentCamera = workspace.CurrentCamera
                bodyGyro.cframe = currentCamera.CFrame
                local moveDirection = humanoid.MoveDirection
                local vector = Vector3.new(0, 0, 0)
                if moveDirection.Magnitude > 0 then
                    local cframe = currentCamera.CFrame
                    local vectorToObjectSpace = cframe:VectorToObjectSpace(moveDirection)
                    vector =(cframe.LookVector *  - vectorToObjectSpace.Z + cframe.RightVector * vectorToObjectSpace.X) * v11
                end
                if userInputService:IsKeyDown(Enum.KeyCode.Space) then
                    vector = vector + Vector3.new(0, v11 * 0.8, 0)
                end
                if userInputService:IsKeyDown(Enum.KeyCode.LeftShift) then
                    vector = vector - Vector3.new(0, v11 * 0.8, 0)
                end
                bodyVelocity.velocity = vector
                return
            end
        end
)
    end
    local function f7()
        v10 =  false
        instance30.Visible =  false
        if connect3 then
            connect3:Disconnect()
            connect3 =  nil
        end
        if bodyGyro then
            bodyGyro:Destroy()
            bodyGyro =  nil
        end
        if bodyVelocity then
            bodyVelocity:Destroy()
            bodyVelocity =  nil
        end
        if localPlayer.Character then
            local humanoid2 = localPlayer.Character:FindFirstChildOfClass("Humanoid")
            if humanoid2 then
                humanoid2.PlatformStand =  false
            end
        end
    end
    flyOFF.MouseButton1Click:Connect(function()
        v10 =  not v10
        if v10 then
            flyOFF.Text = "Fly: ON"
            flyOFF.BackgroundColor3 = Color3.fromRGB(0, 180, 120)
            instance30.Visible =  true
            f6()
        else
            flyOFF.Text = "Fly: OFF"
            flyOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
            f7()
        end
    end
)
    instance32.MouseButton1Click:Connect(function()
        v11 = math.clamp(v11 - 10, 20, 150)
        instance31.Text = "Fly Speed: "..v11
    end
)
    instance33.MouseButton1Click:Connect(function()
        v11 = math.clamp(v11 + 10, 20, 150)
        instance31.Text = "Fly Speed: "..v11
    end
)
    local v12 =  false
    local connect4
    noclipOFF.MouseButton1Click:Connect(function()
        v12 =  not v12
        if v12 then
            noclipOFF.Text = "Noclip: ON"
            noclipOFF.BackgroundColor3 = Color3.fromRGB(0, 180, 120)
            connect4 = runService.Stepped:Connect(function()
                if localPlayer.Character then
                    for index3, value3 in ipairs(localPlayer.Character:GetDescendants()) do
                        if value3:IsA("BasePart") then
                            value3.CanCollide =  false
                        end
                    end
                end
            end
)
        else
            noclipOFF.Text = "Noclip: OFF"
            noclipOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
            if connect4 then
                connect4:Disconnect()
                connect4 =  nil
            end
        end
    end
)
    local v13 =  false
    local connect5
    nositOFF.MouseButton1Click:Connect(function()
        v13 =  not v13
        if v13 then
            nositOFF.Text = "Nosit: ON"
            nositOFF.BackgroundColor3 = Color3.fromRGB(0, 180, 120)
            connect5 = runService.Heartbeat:Connect(function()
                if localPlayer.Character then
                    local humanoid3 = localPlayer.Character:FindFirstChildOfClass("Humanoid")
                    if humanoid3 then
                        humanoid3:SetStateEnabled(Enum.HumanoidStateType.Seated,  false)
                        if humanoid3.Sit then
                            humanoid3.Sit =  false
                        end
                    end
                end
            end
)
        else
            nositOFF.Text = "Nosit: OFF"
            nositOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
            if connect5 then
                connect5:Disconnect()
                connect5 =  nil
            end
            if localPlayer.Character then
                local humanoid4 = localPlayer.Character:FindFirstChildOfClass("Humanoid")
                if humanoid4 then
                    humanoid4:SetStateEnabled(Enum.HumanoidStateType.Seated,  true)
                end
            end
        end
    end
)
    local v14 =  false
    voidProtectionOFF.MouseButton1Click:Connect(function()
        v14 =  not v14
        if v14 then
            voidProtectionOFF.Text = "Void Protection: ON"
            voidProtectionOFF.BackgroundColor3 = Color3.fromRGB(0, 180, 120)
            workspace.FallenPartsDestroyHeight =(0 / 0)
        else
            voidProtectionOFF.Text = "Void Protection: OFF"
            voidProtectionOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
            workspace.FallenPartsDestroyHeight =  - 500
        end
    end
)
    respawn.MouseButton1Click:Connect(function()
        local character6 = localPlayer.Character
        if character6 and character6:FindFirstChild("HumanoidRootPart") then
            local position = character6.HumanoidRootPart.Position
            local humanoid5 = character6:FindFirstChildOfClass("Humanoid")
            if humanoid5 then
                humanoid5.Health = 0
                localPlayer.CharacterAdded:Wait()
                task.wait(0.4)
                if localPlayer.Character and localPlayer.Character:FindFirstChild("HumanoidRootPart") then
                    localPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(position)
                end
            end
        end
    end
)
    local target = f3("Target")
    local instance34 = Instance.new("ScrollingFrame", target)
    instance34.BackgroundTransparency = 1
    instance34.Size = UDim2.new(1, 0, 1, 0)
    instance34.CanvasSize = UDim2.new(0, 0, 0, 580)
    instance34.ScrollBarThickness = 4
    instance34.ScrollBarImageColor3 = Color3.fromRGB(0, 150, 255)
    local instance35 = Instance.new("TextBox", instance34)
    instance35.BackgroundColor3 = Color3.fromRGB(14, 26, 46)
    instance35.Position = UDim2.new(0, 0, 0, 0)
    instance35.Size = UDim2.new(1,  - 52, 0, 34)
    instance35.Font = Enum.Font.GothamMedium
    instance35.PlaceholderText = "Target name..."
    instance35.PlaceholderColor3 = Color3.fromRGB(80, 130, 170)
    instance35.Text = ""
    instance35.TextColor3 = Color3.fromRGB(255, 255, 255)
    instance35.TextSize = 13
    Instance.new("UICorner", instance35).CornerRadius = UDim.new(0, 8)
    local instance36 = Instance.new("TextButton", instance34)
    instance36.BackgroundColor3 = Color3.fromRGB(0, 140, 255)
    instance36.Position = UDim2.new(1,  - 48, 0, 0)
    instance36.Size = UDim2.new(0, 40, 0, 34)
    instance36.Font = Enum.Font.GothamBold
    instance36.Text = "🎯"
    instance36.TextColor3 = Color3.fromRGB(255, 255, 255)
    instance36.TextSize = 16
    Instance.new("UICorner", instance36).CornerRadius = UDim.new(0, 8)
    local instance37 = Instance.new("Frame", instance34)
    instance37.BackgroundColor3 = Color3.fromRGB(12, 22, 38)
    instance37.Position = UDim2.new(0, 0, 0, 42)
    instance37.Size = UDim2.new(1,  - 10, 0, 54)
    Instance.new("UICorner", instance37).CornerRadius = UDim.new(0, 8)
    local instance38 = Instance.new("ImageLabel", instance37)
    instance38.Position = UDim2.new(0, 8, 0, 7)
    instance38.Size = UDim2.new(0, 40, 0, 40)
    instance38.BackgroundColor3 = Color3.fromRGB(20, 38, 65)
    instance38.Image = ""
    Instance.new("UICorner", instance38).CornerRadius = UDim.new(1, 0)
    local instance39 = Instance.new("TextLabel", instance37)
    instance39.BackgroundTransparency = 1
    instance39.Position = UDim2.new(0, 56, 0, 8)
    instance39.Size = UDim2.new(1,  - 65, 0, 18)
    instance39.Font = Enum.Font.GothamBold
    instance39.Text = "No Target Locked"
    instance39.TextColor3 = Color3.fromRGB(150, 215, 255)
    instance39.TextSize = 13
    instance39.TextXAlignment = Enum.TextXAlignment.Left
    local instance40 = Instance.new("TextLabel", instance37)
    instance40.BackgroundTransparency = 1
    instance40.Position = UDim2.new(0, 56, 0, 28)
    instance40.Size = UDim2.new(1,  - 65, 0, 18)
    instance40.Font = Enum.Font.GothamMedium
    instance40.Text = "Type name or use 🎯 tool"
    instance40.TextColor3 = Color3.fromRGB(80, 130, 170)
    instance40.TextSize = 11
    instance40.TextXAlignment = Enum.TextXAlignment.Left
    local instance41 = Instance.new("Frame", instance34)
    instance41.BackgroundTransparency = 1
    instance41.Position = UDim2.new(0, 0, 0, 105)
    instance41.Size = UDim2.new(1,  - 10, 0, 320)
    local instance42 = Instance.new("UIGridLayout", instance41)
    instance42.CellSize = UDim2.new(0.48, 0, 0, 34)
    instance42.CellPadding = UDim2.new(0.04, 0, 0, 7)
    local function f8(text3)
        local instance43 = Instance.new("TextButton", instance41)
        instance43.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
        instance43.Font = Enum.Font.GothamBold
        instance43.Text = text3
        instance43.TextColor3 = Color3.fromRGB(255, 255, 255)
        instance43.TextSize = 12
        Instance.new("UICorner", instance43).CornerRadius = UDim.new(0, 6)
        return instance43
    end
    local viewOFF = f8("View: OFF")
    local teleport = f8("Teleport")
    local headSitOFF = f8("Head Sit: OFF")
    local bangOFF = f8("Bang: OFF")
    local opBANGOFF = f8("OP BANG: OFF")
    local chocoBANGOFF = f8("CHOCO BANG: OFF")
    local flingOFF = f8("Fling: OFF")
    local busFlingOFF = f8("Bus Fling: OFF")
    local busBringOFF = f8("Bus Bring: OFF")
    local couchFlingOFF = f8("Couch Fling: OFF")
    local instance44 = Instance.new("Frame", instance34)
    instance44.BackgroundColor3 = Color3.fromRGB(12, 22, 38)
    instance44.Position = UDim2.new(0, 0, 0, 440)
    instance44.Size = UDim2.new(1,  - 10, 0, 48)
    instance44.Visible =  false
    Instance.new("UICorner", instance44).CornerRadius = UDim.new(0, 8)
    local instance45 = Instance.new("TextButton", instance44)
    instance45.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
    instance45.Position = UDim2.new(0, 8, 0, 9)
    instance45.Size = UDim2.new(0, 140, 0, 30)
    instance45.Font = Enum.Font.GothamBold
    instance45.Text = "Style: Front"
    instance45.TextColor3 = Color3.fromRGB(255, 255, 255)
    instance45.TextSize = 12
    Instance.new("UICorner", instance45).CornerRadius = UDim.new(0, 6)
    local instance46 = Instance.new("TextLabel", instance44)
    instance46.BackgroundTransparency = 1
    instance46.Position = UDim2.new(0, 155, 0, 9)
    instance46.Size = UDim2.new(0, 80, 0, 30)
    instance46.Font = Enum.Font.GothamBold
    instance46.Text = "Speed: 10x"
    instance46.TextColor3 = Color3.fromRGB(160, 220, 255)
    instance46.TextSize = 12
    instance46.TextXAlignment = Enum.TextXAlignment.Left
    local instance47 = Instance.new("TextButton", instance44)
    instance47.BackgroundColor3 = Color3.fromRGB(0, 100, 180)
    instance47.Position = UDim2.new(1,  - 78, 0, 9)
    instance47.Size = UDim2.new(0, 30, 0, 30)
    instance47.Font = Enum.Font.GothamBold
    instance47.Text = "-"
    instance47.TextColor3 = Color3.fromRGB(255, 255, 255)
    instance47.TextSize = 16
    Instance.new("UICorner", instance47).CornerRadius = UDim.new(0, 6)
    local instance48 = Instance.new("TextButton", instance44)
    instance48.BackgroundColor3 = Color3.fromRGB(0, 100, 180)
    instance48.Position = UDim2.new(1,  - 40, 0, 9)
    instance48.Size = UDim2.new(0, 30, 0, 30)
    instance48.Font = Enum.Font.GothamBold
    instance48.Text = "+"
    instance48.TextColor3 = Color3.fromRGB(255, 255, 255)
    instance48.TextSize = 16
    Instance.new("UICorner", instance48).CornerRadius = UDim.new(0, 6)
    local v15 =  false
    local v16 =  false
    local v17 =  false
    local v18 =  false
    local v19 =  false
    local v20 = 1
    local v21 = 10
    local v22 =  false
    local v23 =  false
    local v24 =  false
    local v25 =  false
    local function f9(p5)
        if p5 and p5.Character and p5.Character:FindFirstChild("HumanoidRootPart") then
            return p5.Character.HumanoidRootPart
        end
    end
    local function f10(p6)
        if not p6 or p6 == "" then
            return nil
        else
            local v26 = string.lower(p6)
            for index4, value4 in ipairs(players:GetPlayers()) do
                if string.lower(value4.Name) == v26 or string.lower(value4.DisplayName) == v26 then
                    return value4
                end
            end
            for index5, value5 in ipairs(players:GetPlayers()) do
                if string.find(string.lower(value5.Name), v26) or string.find(string.lower(value5.DisplayName), v26) then
                    return value5
                end
            end
            return nil
        end
    end
    local v27
    local function f11(p7)
        if p7 then
            v27 = p7
            instance39.Text = p7.DisplayName
            instance40.Text = "@"..p7.Name
            task.spawn(function()
                local v28, image = pcall(function()
                    return players:GetUserThumbnailAsync(p7.UserId, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size420x420)
                end
)
                if v28 then
                    instance38.Image = image
                end
            end
)
        else
            v27 =  nil
            instance39.Text = "No Target Locked"
            instance40.Text = "Type name or use 🎯 tool"
            instance38.Image = ""
        end
    end
    instance35:GetPropertyChangedSignal("Text"):Connect(function()
        f11((f10(instance35.Text)))
    end
)
    instance36.MouseButton1Click:Connect(function()
        local rinkazeTarget = Instance.new("Tool")
        rinkazeTarget.Name = "Rinkaze Target"
        rinkazeTarget.RequiresHandle =  false
        rinkazeTarget.ToolTip = "Click a player to select"
        rinkazeTarget.TextureId = "rbxassetid://6031094678"
        rinkazeTarget.Activated:Connect(function()
            local target2 = getMouse.Target
            if target2 then
                local getPlayerFromCharacter = players:GetPlayerFromCharacter(target2.Parent)
                if not getPlayerFromCharacter and target2.Parent:IsA("Accessory") then
                    getPlayerFromCharacter = players:GetPlayerFromCharacter(target2.Parent.Parent)
                end
                if getPlayerFromCharacter and getPlayerFromCharacter ~= localPlayer then
                    f11(getPlayerFromCharacter)
                end
            end
        end
)
        rinkazeTarget.Parent = localPlayer.Backpack
    end
)
    players.PlayerRemoving:Connect(function(player)
        if v27 == player then
            f2(player.DisplayName, "@"..player.Name)
            f11( nil)
            instance35.Text = ""
        end
    end
)
    local connect6
    viewOFF.MouseButton1Click:Connect(function()
        if v15 then
            v15 =  false
            viewOFF.Text = "View: OFF"
            viewOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
            if connect6 then
                connect6:Disconnect()
                connect6 =  nil
            end
            if localPlayer.Character and localPlayer.Character:FindFirstChildOfClass("Humanoid") then
                workspace.CurrentCamera.CameraSubject = localPlayer.Character.Humanoid
            end
        elseif v27 and v27.Character and v27.Character:FindFirstChildOfClass("Humanoid") then
            v15 =  true
            viewOFF.Text = "View: ON"
            viewOFF.BackgroundColor3 = Color3.fromRGB(0, 180, 120)
            connect6 = runService.RenderStepped:Connect(function()
                if v15 and v27 and v27.Character and v27.Character:FindFirstChildOfClass("Humanoid") then
                    workspace.CurrentCamera.CameraSubject = v27.Character.Humanoid
                else
                    v15 =  false
                    viewOFF.Text = "View: OFF"
                    viewOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
                    if connect6 then
                        connect6:Disconnect()
                        connect6 =  nil
                    end
                end
            end
)
        end
    end
)
    teleport.MouseButton1Click:Connect(function()
        if v27 and f9(v27) and f9(localPlayer) then
            f9(localPlayer).CFrame = f9(v27).CFrame * CFrame.new(0, 2, 0)
        end
    end
)
    local connect7
    headSitOFF.MouseButton1Click:Connect(function()
        if f1(v27) then
            return
        end
        if v16 then
            v16 =  false
            headSitOFF.Text = "Head Sit: OFF"
            headSitOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
            if connect7 then
                connect7:Disconnect()
                connect7 =  nil
            end
            if localPlayer.Character and localPlayer.Character:FindFirstChildOfClass("Humanoid") then
                localPlayer.Character.Humanoid.Sit =  false
            end
        elseif v27 and v27.Character and v27.Character:FindFirstChild("Head") then
            v16 =  true
            headSitOFF.Text = "Head Sit: ON"
            headSitOFF.BackgroundColor3 = Color3.fromRGB(0, 180, 120)
            connect7 = runService.Heartbeat:Connect(function()
                if v16 and v27 and v27.Character and v27.Character:FindFirstChild("Head") then
                    local character7 = localPlayer.Character
                    if character7 and character7:FindFirstChild("HumanoidRootPart") and character7:FindFirstChildOfClass("Humanoid") then
                        character7.Humanoid.Sit =  true
                        character7.HumanoidRootPart.CFrame = v27.Character.Head.CFrame * CFrame.new(0, 1.8, 0)
                    end
                else
                    v16 =  false
                    headSitOFF.Text = "Head Sit: OFF"
                    headSitOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
                    if connect7 then
                        connect7:Disconnect()
                        connect7 =  nil
                    end
                end
            end
)
        end
    end
)
    local connect8, loadAnimation
    bangOFF.MouseButton1Click:Connect(function()
        if f1(v27) then
            return
        end
        if v17 then
            v17 =  false
            bangOFF.Text = "Bang: OFF"
            bangOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
            if connect8 then
                connect8:Disconnect()
                connect8 =  nil
            end
            if loadAnimation then
                loadAnimation:Stop()
                loadAnimation =  nil
            end
        elseif v27 and f9(v27) then
            v17 =  true
            bangOFF.Text = "Bang: ON"
            bangOFF.BackgroundColor3 = Color3.fromRGB(0, 180, 120)
            local character8 = localPlayer.Character
            local humanoid6 = character8
            humanoid6 = character8 and localPlayer.Character:FindFirstChildOfClass("Humanoid")
            if humanoid6 then
                local animation = Instance.new("Animation")
                animation.AnimationId = "rbxassetid://5918726674"
                loadAnimation = humanoid6:LoadAnimation(animation)
                loadAnimation:Play()
            end
            connect8 = runService.Heartbeat:Connect(function()
                if v17 and v27 and f9(v27) and f9(localPlayer) then
                    f9(localPlayer).CFrame = f9(v27).CFrame * CFrame.new(0, 0, 1.1)
                else
                    v17 =  false
                    bangOFF.Text = "Bang: OFF"
                    bangOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
                    if connect8 then
                        connect8:Disconnect()
                        connect8 =  nil
                    end
                    if loadAnimation then
                        loadAnimation:Stop()
                        loadAnimation =  nil
                    end
                end
            end
)
        end
    end
)
    instance45.MouseButton1Click:Connect(function()
        v20 = v20 + 1
        if v20 > 2 then
            v20 = 1
        end
        if v20 == 1 then
            instance45.Text = "Style: Front"
        else
            instance45.Text = "Style: Head Sit"
        end
    end
)
    local loadAnimation2
    instance47.MouseButton1Click:Connect(function()
        v21 = math.clamp(v21 - 5, 5, 50)
        instance46.Text = "Speed: "..v21.. "x"
        if loadAnimation2 then
            loadAnimation2:AdjustSpeed(v21)
        end
    end
)
    instance48.MouseButton1Click:Connect(function()
        v21 = math.clamp(v21 + 5, 5, 50)
        instance46.Text = "Speed: "..v21.. "x"
        if loadAnimation2 then
            loadAnimation2:AdjustSpeed(v21)
        end
    end
)
    local connect9
    opBANGOFF.MouseButton1Click:Connect(function()
        if f1(v27) then
            return
        end
        if v18 then
            v18 =  false
            opBANGOFF.Text = "OP BANG: OFF"
            opBANGOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
            instance44.Visible =  false
            if connect9 then
                connect9:Disconnect()
                connect9 =  nil
            end
            if loadAnimation2 then
                loadAnimation2:Stop()
                loadAnimation2 =  nil
            end
        elseif v27 and f9(v27) then
            v18 =  true
            opBANGOFF.Text = "OP BANG: ON"
            opBANGOFF.BackgroundColor3 = Color3.fromRGB(0, 180, 120)
            instance44.Visible =  true
            local character9 = localPlayer.Character
            local humanoid7 = character9
            humanoid7 = character9 and localPlayer.Character:FindFirstChildOfClass("Humanoid")
            if humanoid7 then
                local animation2 = Instance.new("Animation")
                animation2.AnimationId = "rbxassetid://72114267321096"
                loadAnimation2 = humanoid7:LoadAnimation(animation2)
                loadAnimation2.Looped =  true
                loadAnimation2:Play()
                loadAnimation2:AdjustSpeed(v21)
            end
            connect9 = runService.Heartbeat:Connect(function()
                if v18 and v27 and v27.Character then
                    local character10 = localPlayer.Character
                    if character10 and character10:FindFirstChild("HumanoidRootPart") and character10:FindFirstChildOfClass("Humanoid") then
                        character10.Humanoid.Sit =  true
                        if v20 == 1 then
                            local humanoidRootPart2 = v27.Character:FindFirstChild("HumanoidRootPart")
                            if humanoidRootPart2 then
                                character10.HumanoidRootPart.CFrame = humanoidRootPart2.CFrame * CFrame.new(0, 0,  - 1.2) * CFrame.Angles(0, math.rad(180), 0)
                            end
                        else
                            local head = v27.Character:FindFirstChild("Head")
                            if head then
                                character10.HumanoidRootPart.CFrame = head.CFrame * CFrame.new(0, 1.8, 0)
                            end
                        end
                    end
                else
                    v18 =  false
                    opBANGOFF.Text = "OP BANG: OFF"
                    opBANGOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
                    instance44.Visible =  false
                    if connect9 then
                        connect9:Disconnect()
                        connect9 =  nil
                    end
                    if loadAnimation2 then
                        loadAnimation2:Stop()
                        loadAnimation2 =  nil
                    end
                end
            end
)
        end
    end
)
    local connect10, loadAnimation3
    chocoBANGOFF.MouseButton1Click:Connect(function()
        if f1(v27) then
            return
        end
        if v19 then
            v19 =  false
            chocoBANGOFF.Text = "CHOCO BANG: OFF"
            chocoBANGOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
            if connect10 then
                connect10:Disconnect()
                connect10 =  nil
            end
            if loadAnimation3 then
                loadAnimation3:Stop()
                loadAnimation3 =  nil
            end
            local character11 = localPlayer.Character
            if character11 then
                local humanoid8 = character11:FindFirstChildOfClass("Humanoid")
                local humanoidRootPart3 = character11:FindFirstChild("HumanoidRootPart")
                if humanoid8 then
                    humanoid8.Sit =  false
                    humanoid8:ChangeState(Enum.HumanoidStateType.GettingUp)
                end
                if humanoidRootPart3 then
                    humanoidRootPart3.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
                    humanoidRootPart3.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
                    humanoidRootPart3.CFrame = humanoidRootPart3.CFrame + Vector3.new(0, 3, 0)
                end
            end
        elseif v27 and v27.Character and v27.Character:FindFirstChild("Head") then
            v19 =  true
            chocoBANGOFF.Text = "CHOCO BANG: ON"
            chocoBANGOFF.BackgroundColor3 = Color3.fromRGB(0, 180, 120)
            local character12 = localPlayer.Character
            local humanoid9 = character12
            humanoid9 = character12 and localPlayer.Character:FindFirstChildOfClass("Humanoid")
            if humanoid9 then
                local animation3 = Instance.new("Animation")
                animation3.AnimationId = "rbxassetid://105919095840646"
                loadAnimation3 = humanoid9:LoadAnimation(animation3)
                loadAnimation3.Looped =  true
                loadAnimation3:Play()
            end
            connect10 = runService.Heartbeat:Connect(function()
                if v19 and v27 and v27.Character and v27.Character:FindFirstChild("Head") then
                    local character13 = localPlayer.Character
                    if character13 and character13:FindFirstChild("HumanoidRootPart") and character13:FindFirstChildOfClass("Humanoid") then
                        character13.Humanoid.Sit =  true
                        character13.HumanoidRootPart.CFrame = v27.Character.Head.CFrame * CFrame.new(0, 1.8, 0)
                        character13.HumanoidRootPart.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
                    end
                else
                    v19 =  false
                    chocoBANGOFF.Text = "CHOCO BANG: OFF"
                    chocoBANGOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
                    if connect10 then
                        connect10:Disconnect()
                        connect10 =  nil
                    end
                    if loadAnimation3 then
                        loadAnimation3:Stop()
                        loadAnimation3 =  nil
                    end
                end
            end
)
        end
    end
)
    local connect11
    flingOFF.MouseButton1Click:Connect(function()
        local position2, fallenPartsDestroyHeight
        if f1(v27) then
            return
        elseif v22 then
            v22 =  false
            flingOFF.Text = "Fling: OFF"
            flingOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
            if connect11 then
                connect11:Disconnect()
                connect11 =  nil
            end
            return
        elseif not v27 or not f9(v27) then
            return
        else
            v22 =  true
            flingOFF.Text = "Fling: ON"
            flingOFF.BackgroundColor3 = Color3.fromRGB(0, 180, 120)
            local v29 = f9(localPlayer)
            position2 = v29 and v29.Position
            fallenPartsDestroyHeight = workspace.FallenPartsDestroyHeight
            workspace.FallenPartsDestroyHeight =(0 / 0)
            connect11 = runService.Heartbeat:Connect(function()
                if not v22 or not v27 or not f9(v27) or not f9(localPlayer) then
                    v22 =  false
                    flingOFF.Text = "Fling: OFF"
                    flingOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
                    if connect11 then
                        connect11:Disconnect()
                        connect11 =  nil
                    end
                    workspace.FallenPartsDestroyHeight = fallenPartsDestroyHeight
                    if position2 and f9(localPlayer) then
                        f9(localPlayer).CFrame = CFrame.new(position2 + Vector3.new(0, 5, 0))
                        f9(localPlayer).AssemblyLinearVelocity = Vector3.new(0, 0, 0)
                    end
                    return
                else
                    local v30 = f9(localPlayer)
                    v30.CFrame = f9(v27).CFrame
                    v30.AssemblyLinearVelocity = Vector3.new(math.random( - 200, 200),  - 30000, math.random( - 200, 200))
                    return
                end
            end
)
            task.delay(2.5, function()
                if v22 then
                    v22 =  false
                    flingOFF.Text = "Fling: OFF"
                    flingOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
                    if connect11 then
                        connect11:Disconnect()
                        connect11 =  nil
                    end
                    workspace.FallenPartsDestroyHeight = fallenPartsDestroyHeight
                    if position2 and f9(localPlayer) then
                        f9(localPlayer).CFrame = CFrame.new(position2 + Vector3.new(0, 5, 0))
                        f9(localPlayer).AssemblyLinearVelocity = Vector3.new(0, 0, 0)
                    end
                end
            end
)
            return
        end
    end
)
    local connect12
    busFlingOFF.MouseButton1Click:Connect(function()
        if f1(v27) then
            return
        end
        if v23 then
            v23 =  false
            busFlingOFF.Text = "Bus Fling: OFF"
            busFlingOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
            if connect12 then
                connect12:Disconnect()
                connect12 =  nil
            end
            return
        end
        if not v27 or not v27.Character then
            return
        end
        v23 =  true
        busFlingOFF.Text = "Bus Fling: ON"
        busFlingOFF.BackgroundColor3 = Color3.fromRGB(0, 180, 120)
        task.spawn(function()
            local rE = replicatedStorage:FindFirstChild("RE")
            local findFirstChild = rE and rE:FindFirstChild("1Ca1r")
            local v31 = f9(localPlayer)
            local findFirstChild2
            if not v31 then
                v23 =  false
                busFlingOFF.Text = "Bus Fling: OFF"
                busFlingOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
                return
            else
                local cframe2 = v31.CFrame
                v31.CFrame = CFrame.new(1118.81, 75.998,  - 1138.61)
                task.wait(0.4)
                if findFirstChild then
                    pcall(function()
                        findFirstChild:FireServer("PickingCar", "SchoolBus")
                    end
)
                end
                task.wait(1.4)
                local vehicles = workspace:FindFirstChild("Vehicles")
                findFirstChild2 =  nil
                if vehicles then
                    findFirstChild2 = vehicles:FindFirstChild(localPlayer.Name.. "Car")
                    if not findFirstChild2 then
                        for key, value6 in pairs(vehicles:GetChildren()) do
                            if string.find(value6.Name, localPlayer.Name) then
                                findFirstChild2 = value6
                                break
                            end
                        end
                    end
                end
                if not findFirstChild2 or not findFirstChild2.PrimaryPart then
                    v23 =  false
                    busFlingOFF.Text = "Bus Fling: OFF"
                    busFlingOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
                    v31.CFrame = cframe2
                    return
                end
                connect12 = runService.Heartbeat:Connect(function()
                    if not v23 or not v27 or not v27.Character then
                        v23 =  false
                        busFlingOFF.Text = "Bus Fling: OFF"
                        busFlingOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
                        if connect12 then
                            connect12:Disconnect()
                            connect12 =  nil
                        end
                        return
                    end
                    if not f9(v27) or not findFirstChild2.PrimaryPart then
                        return
                    else
                        local v32 = tick()
                        local v33 = math.sin(v32 * 40)
                        local v34 = tick()
                        local v35 = math.cos(v34 * 40)
                        CFrame.new(v33 * 12, 0, v35 * 25)
                        return
                    end
                end
)
                return
            end
        end
)
    end
)
    local connect13
    busBringOFF.MouseButton1Click:Connect(function()
        if f1(v27) then
            return
        end
        if v24 then
            v24 =  false
            busBringOFF.Text = "Bus Bring: OFF"
            busBringOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
            if connect13 then
                connect13:Disconnect()
                connect13 =  nil
            end
            return
        end
        if not v27 or not v27.Character then
            return
        end
        v24 =  true
        busBringOFF.Text = "Bus Bring: ON"
        busBringOFF.BackgroundColor3 = Color3.fromRGB(0, 180, 120)
        task.spawn(function()
            local re2 = replicatedStorage:FindFirstChild("RE")
            local findFirstChild3 = re2 and re2:FindFirstChild("1Ca1r")
            local v36 = f9(localPlayer)
            local findFirstChild4, v37
            if not v36 then
                v24 =  false
                busBringOFF.Text = "Bus Bring: OFF"
                busBringOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
                return
            else
                local cframe3 = v36.CFrame
                v36.CFrame = CFrame.new(1118.81, 75.998,  - 1138.61)
                task.wait(0.4)
                if findFirstChild3 then
                    pcall(function()
                        findFirstChild3:FireServer("PickingCar", "SchoolBus")
                    end
)
                end
                task.wait(1.4)
                local vehicles2 = workspace:FindFirstChild("Vehicles")
                findFirstChild4 = vehicles2 and vehicles2:FindFirstChild(localPlayer.Name.. "Car")
                if not findFirstChild4 or not findFirstChild4.PrimaryPart then
                    v24 =  false
                    busBringOFF.Text = "Bus Bring: OFF"
                    busBringOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
                    v36.CFrame = cframe3
                    return
                end
                v37 = 0
                connect13 = runService.Heartbeat:Connect(function()
                    if not v24 or not v27 or not v27.Character then
                        v24 =  false
                        busBringOFF.Text = "Bus Bring: OFF"
                        busBringOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
                        if connect13 then
                            connect13:Disconnect()
                            connect13 =  nil
                        end
                        return
                    end
                    local v38 = f9(v27)
                    if not v38 or not findFirstChild4.PrimaryPart then
                        return
                    end
                    v37 = v37 + 40
                    local cframe4 = CFrame.new(math.sin(tick() * 25) * 6, 0, math.cos(tick() * 25) * 16)
                    pcall(function()
                        findFirstChild4:SetPrimaryPartCFrame(v38.CFrame * cframe4 * CFrame.Angles(0, math.rad(v37), 0))
                    end
)
                end
)
                return
            end
        end
)
    end
)
    local connect14
    couchFlingOFF.MouseButton1Click:Connect(function()
        if f1(v27) then
            return
        end
        if v25 then
            v25 =  false
            couchFlingOFF.Text = "Couch Fling: OFF"
            couchFlingOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
            if connect14 then
                connect14:Disconnect()
                connect14 =  nil
            end
            local character14 = localPlayer.Character
            if character14 then
                local humanoid10 = character14:FindFirstChildOfClass("Humanoid")
                local humanoidRootPart4 = character14:FindFirstChild("HumanoidRootPart")
                if humanoid10 then
                    humanoid10:UnequipTools()
                    humanoid10.Sit =  false
                end
                if humanoidRootPart4 then
                    humanoidRootPart4.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
                    humanoidRootPart4.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
                end
            end
            return
        end
        if not v27 or not v27.Character then
            return
        end
        v25 =  true
        couchFlingOFF.Text = "Couch Fling: ON"
        couchFlingOFF.BackgroundColor3 = Color3.fromRGB(0, 180, 120)
        task.spawn(function()
            local re3 = replicatedStorage:FindFirstChild("RE")
            local findFirstChild5 = re3 and re3:FindFirstChild("1Too1l")
            local findFirstChild6 = re3 and re3:FindFirstChild("1Clea1rTool1s")
            local v39 = f9(localPlayer)
            local humanoid11 = localPlayer.Character and localPlayer.Character:FindFirstChildOfClass("Humanoid")
            local cframe5, fallenPartsDestroyHeight2, v40, v41
            if not v39 or not humanoid11 then
                v25 =  false
                couchFlingOFF.Text = "Couch Fling: OFF"
                couchFlingOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
                return
            else
                cframe5 = v39.CFrame
                fallenPartsDestroyHeight2 = workspace.FallenPartsDestroyHeight
                workspace.FallenPartsDestroyHeight =(0 / 0)
                if findFirstChild6 then
                    pcall(function()
                        findFirstChild6:FireServer("ClearAllTools")
                    end
)
                end
                task.wait(0.3)
                if findFirstChild5 then
                    pcall(function()
                        findFirstChild5:InvokeServer("PickingTools", "Couch")
                    end
)
                end
                task.wait(0.5)
                local couch = localPlayer.Backpack:FindFirstChild("Couch") or localPlayer.Character:FindFirstChild("Couch")
                if couch then
                    humanoid11:EquipTool(couch)
                end
                v40 = 0
                v41 = tick()
                connect14 = runService.Heartbeat:Connect(function()
                    if not v25 or not v27 or not v27.Character then
                        v25 =  false
                        couchFlingOFF.Text = "Couch Fling: OFF"
                        couchFlingOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
                        if connect14 then
                            connect14:Disconnect()
                            connect14 =  nil
                        end
                        workspace.FallenPartsDestroyHeight = fallenPartsDestroyHeight2
                        v39.CFrame = cframe5 + Vector3.new(0, 4, 0)
                        v39.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
                        return
                    else
                        local v42 = f9(v27)
                        if not v42 then
                            return
                        end
                        v40 = v40 + 140
                        v39.CFrame = v42.CFrame * CFrame.new(0, 0.1, 1) * CFrame.Angles(math.rad(v40), math.rad(v40 * 0.9), math.rad(v40 * 1.5))
                        v39.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
                        if tick() - v41 > 1.5 then
                            v42.AssemblyLinearVelocity = Vector3.new(math.random( - 100, 100),  - 99999, math.random( - 100, 100))
                            task.wait(0.12)
                            v39.CFrame = cframe5 + Vector3.new(0, 5, 0)
                            v39.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
                            v39.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
                            workspace.FallenPartsDestroyHeight = fallenPartsDestroyHeight2
                            v25 =  false
                            couchFlingOFF.Text = "Couch Fling: OFF"
                            couchFlingOFF.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
                            if connect14 then
                                connect14:Disconnect()
                                connect14 =  nil
                            end
                            local character15 = localPlayer.Character
                            local humanoid12 = character15
                            humanoid12 = character15 and localPlayer.Character:FindFirstChildOfClass("Humanoid")
                            if humanoid12 then
                                humanoid12:UnequipTools()
                            end
                        end
                        return
                    end
                end
)
                return
            end
        end
)
    end
)
    local protect = f3("Protect")
    local instance49 = Instance.new("Frame", protect)
    instance49.BackgroundColor3 = Color3.fromRGB(12, 22, 38)
    instance49.Size = UDim2.new(1, 0, 0, 90)
    Instance.new("UICorner", instance49).CornerRadius = UDim.new(0, 8)
    local instance50 = Instance.new("TextLabel", instance49)
    instance50.BackgroundTransparency = 1
    instance50.Position = UDim2.new(0, 12, 0, 8)
    instance50.Size = UDim2.new(1,  - 24, 0, 20)
    instance50.Font = Enum.Font.GothamBold
    instance50.Text = "Enter Password to Unlock Protect"
    instance50.TextColor3 = Color3.fromRGB(0, 195, 255)
    instance50.TextSize = 13
    instance50.TextXAlignment = Enum.TextXAlignment.Left
    local instance51 = Instance.new("TextBox", instance49)
    instance51.BackgroundColor3 = Color3.fromRGB(20, 35, 55)
    instance51.Position = UDim2.new(0, 12, 0, 35)
    instance51.Size = UDim2.new(1,  - 110, 0, 32)
    instance51.Font = Enum.Font.Gotham
    instance51.PlaceholderText = "Password..."
    instance51.Text = ""
    instance51.TextColor3 = Color3.fromRGB(255, 255, 255)
    instance51.TextSize = 13
    Instance.new("UICorner", instance51).CornerRadius = UDim.new(0, 6)
    local instance52 = Instance.new("TextButton", instance49)
    instance52.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
    instance52.Position = UDim2.new(1,  - 90, 0, 35)
    instance52.Size = UDim2.new(0, 78, 0, 32)
    instance52.Font = Enum.Font.GothamBold
    instance52.Text = "Unlock"
    instance52.TextColor3 = Color3.fromRGB(255, 255, 255)
    instance52.TextSize = 13
    Instance.new("UICorner", instance52).CornerRadius = UDim.new(0, 6)
    local instance53 = Instance.new("Frame", protect)
    instance53.BackgroundTransparency = 1
    instance53.Position = UDim2.new(0, 0, 0, 100)
    instance53.Size = UDim2.new(1, 0, 1,  - 100)
    instance53.Visible =  false
    local instance54 = Instance.new("TextButton", instance53)
    instance54.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
    instance54.Size = UDim2.new(1, 0, 0, 42)
    instance54.Font = Enum.Font.GothamBold
    instance54.Text = "PROTECT: OFF"
    instance54.TextColor3 = Color3.fromRGB(255, 255, 255)
    instance54.TextSize = 14
    Instance.new("UICorner", instance54).CornerRadius = UDim.new(0, 8)
    local instance55 = Instance.new("TextLabel", instance53)
    instance55.BackgroundTransparency = 1
    instance55.Position = UDim2.new(0, 0, 0, 55)
    instance55.Size = UDim2.new(1, 0, 0, 160)
    instance55.Font = Enum.Font.GothamMedium
    instance55.Text = "Protect ON karne pe:\n• Extreme Fling velocity cancel\n• Seated (Head Sit / Bang) block\n• Auto Nosit style protection\n• Normal walking + animation normal\n\n+ Protected Players system active"
    instance55.TextColor3 = Color3.fromRGB(160, 210, 255)
    instance55.TextSize = 13
    instance55.TextWrapped =  true
    instance55.TextXAlignment = Enum.TextXAlignment.Left
    instance55.TextYAlignment = Enum.TextYAlignment.Top
    local v43 =  false
    local v44 =  false
    instance52.MouseButton1Click:Connect(function()
        if instance51.Text == "summaryrinkazepanel" then
            v43 =  true
            instance53.Visible =  true
            instance49.Visible =  false
            instance51.Text = ""
        else
            instance51.Text = ""
            instance51.PlaceholderText = "Wrong Password!"
            task.delay(1.5, function()
                instance51.PlaceholderText = "Password..."
            end
)
        end
    end
)
    local connect15
    instance54.MouseButton1Click:Connect(function()
        if not v43 then
            return
        end
        v44 =  not v44
        if v44 then
            instance54.Text = "PROTECT: ON"
            instance54.BackgroundColor3 = Color3.fromRGB(0, 180, 120)
            if localPlayer.Character then
                local humanoid13 = localPlayer.Character:FindFirstChildOfClass("Humanoid")
                if humanoid13 then
                    humanoid13:SetStateEnabled(Enum.HumanoidStateType.Seated,  false)
                end
            end
            connect15 = runService.Heartbeat:Connect(function()
                local character16 = localPlayer.Character
                if not character16 then
                    return
                else
                    local humanoid14 = character16:FindFirstChildOfClass("Humanoid")
                    local v45 =  not humanoid14
                    local humanoidRootPart5 = character16:FindFirstChild("HumanoidRootPart")
                    if v45 or not humanoidRootPart5 then
                        return
                    end
                    humanoid14:SetStateEnabled(Enum.HumanoidStateType.Seated,  false)
                    if humanoid14.Sit then
                        humanoid14.Sit =  false
                    end
                    if humanoidRootPart5.AssemblyLinearVelocity.Magnitude > 130 then
                        humanoidRootPart5.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
                        humanoidRootPart5.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
                    end
                    return
                end
            end
)
        else
            instance54.Text = "PROTECT: OFF"
            instance54.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
            if connect15 then
                connect15:Disconnect()
                connect15 =  nil
            end
            if localPlayer.Character then
                local humanoid15 = localPlayer.Character:FindFirstChildOfClass("Humanoid")
                if humanoid15 then
                    humanoid15:SetStateEnabled(Enum.HumanoidStateType.Seated,  true)
                end
            end
        end
    end
)
    local idleEMOTE = f3("IDLE + EMOTE")
    local instance56 = Instance.new("ScrollingFrame", idleEMOTE)
    instance56.BackgroundTransparency = 1
    instance56.Size = UDim2.new(1, 0, 1, 0)
    instance56.CanvasSize = UDim2.new(0, 0, 0, 650)
    instance56.ScrollBarThickness = 4
    instance56.ScrollBarImageColor3 = Color3.fromRGB(0, 150, 255)
    local instance57 = Instance.new("TextLabel", instance56)
    instance57.BackgroundTransparency = 1
    instance57.Size = UDim2.new(1,  - 10, 0, 24)
    instance57.Font = Enum.Font.GothamBold
    instance57.Text = "── Idles ──"
    instance57.TextColor3 = Color3.fromRGB(0, 195, 255)
    instance57.TextSize = 13
    instance57.TextXAlignment = Enum.TextXAlignment.Left
    local instance58 = Instance.new("Frame", instance56)
    instance58.BackgroundTransparency = 1
    instance58.Position = UDim2.new(0, 0, 0, 28)
    instance58.Size = UDim2.new(1,  - 10, 0, 200)
    local instance59 = Instance.new("UIGridLayout", instance58)
    instance59.CellSize = UDim2.new(0.48, 0, 0, 32)
    instance59.CellPadding = UDim2.new(0.04, 0, 0, 6)
    local instance60 = Instance.new("TextLabel", instance56)
    instance60.BackgroundTransparency = 1
    instance60.Position = UDim2.new(0, 0, 0, 240)
    instance60.Size = UDim2.new(1,  - 10, 0, 24)
    instance60.Font = Enum.Font.GothamBold
    instance60.Text = "── Emotes ──"
    instance60.TextColor3 = Color3.fromRGB(0, 195, 255)
    instance60.TextSize = 13
    instance60.TextXAlignment = Enum.TextXAlignment.Left
    local instance61 = Instance.new("Frame", instance56)
    instance61.BackgroundTransparency = 1
    instance61.Position = UDim2.new(0, 0, 0, 268)
    instance61.Size = UDim2.new(1,  - 10, 0, 200)
    local instance62 = Instance.new("UIGridLayout", instance61)
    instance62.CellSize = UDim2.new(0.48, 0, 0, 32)
    instance62.CellPadding = UDim2.new(0.04, 0, 0, 6)
    local v46 = {
        {
            Name = "Jason Vorhess",
            Id = "105919095840646"
        },
        {
            Name = "I Want Money",
            Id = "104248876465825"
        },
        {
            Name = "Gangnam Dance",
            Id = "129764254213842"
        },
        {
            Name = "Moonwalk",
            Id = "134048087973127"
        },
        {
            Name = "Rat Dance",
            Id = "113375965758912"
        },
        {
            Name = "Hakari Dance",
            Id = "125832310160377"
        },
        {
            Name = "Yuji Jumping Edit",
            Id = "139982320267456"
        },
        {
            Name = "No Hands",
            Id = "80047459102891"
        },
        {
            Name = "Neck Roller",
            Id = "110855869390004"
        },
        {
            Name = "Michael Bounce",
            Id = "115033697333896"
        },
    }
    local instance63 = Instance.new("Frame", instance56)
    instance63.BackgroundColor3 = Color3.fromRGB(12, 22, 38)
    instance63.Position = UDim2.new(0, 0, 0, 480)
    instance63.Size = UDim2.new(1,  - 10, 0, 90)
    instance63.Visible =  false
    Instance.new("UICorner", instance63).CornerRadius = UDim.new(0, 8)
    local instance64 = Instance.new("TextLabel", instance63)
    instance64.BackgroundTransparency = 1
    instance64.Position = UDim2.new(0, 10, 0, 8)
    instance64.Size = UDim2.new(0, 110, 0, 24)
    instance64.Font = Enum.Font.GothamBold
    instance64.Text = "Speed: 1.0x"
    instance64.TextColor3 = Color3.fromRGB(160, 220, 255)
    instance64.TextSize = 13
    instance64.TextXAlignment = Enum.TextXAlignment.Left
    local instance65 = Instance.new("TextButton", instance63)
    instance65.BackgroundColor3 = Color3.fromRGB(0, 100, 180)
    instance65.Position = UDim2.new(0, 120, 0, 6)
    instance65.Size = UDim2.new(0, 32, 0, 28)
    instance65.Font = Enum.Font.GothamBold
    instance65.Text = "-"
    instance65.TextColor3 = Color3.fromRGB(255, 255, 255)
    instance65.TextSize = 16
    Instance.new("UICorner", instance65).CornerRadius = UDim.new(0, 6)
    local instance66 = Instance.new("TextButton", instance63)
    instance66.BackgroundColor3 = Color3.fromRGB(0, 100, 180)
    instance66.Position = UDim2.new(0, 158, 0, 6)
    instance66.Size = UDim2.new(0, 32, 0, 28)
    instance66.Font = Enum.Font.GothamBold
    instance66.Text = "+"
    instance66.TextColor3 = Color3.fromRGB(255, 255, 255)
    instance66.TextSize = 16
    Instance.new("UICorner", instance66).CornerRadius = UDim.new(0, 6)
    local instance67 = Instance.new("TextButton", instance63)
    instance67.BackgroundColor3 = Color3.fromRGB(180, 50, 50)
    instance67.Position = UDim2.new(0, 10, 0, 48)
    instance67.Size = UDim2.new(1,  - 20, 0, 30)
    instance67.Font = Enum.Font.GothamBold
    instance67.Text = "Stop Emote"
    instance67.TextColor3 = Color3.fromRGB(255, 255, 255)
    instance67.TextSize = 13
    Instance.new("UICorner", instance67).CornerRadius = UDim.new(0, 6)
    local v47 = 1
    local loadAnimation4, v48, v49
    local function f12()
        if loadAnimation4 then
            loadAnimation4:Stop(0.2)
            loadAnimation4 =  nil
        end
        if v49 then
            v49.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
            v49 =  nil
        end
        v48 =  nil
        instance63.Visible =  false
    end
    local function f13(p8, p9)
        if v48 == p8 then
            f12()
            return
        else
            f12()
            v48 = p8
            v49 = p9
            p9.BackgroundColor3 = Color3.fromRGB(0, 180, 120)
            instance63.Visible =  true
            local character17 = localPlayer.Character
            local humanoid16 = character17
            humanoid16 = character17 and character17:FindFirstChildOfClass("Humanoid")
            if humanoid16 then
                local animation4 = Instance.new("Animation")
                animation4.AnimationId = "rbxassetid://"..p8
                loadAnimation4 = humanoid16:LoadAnimation(animation4)
                loadAnimation4.Priority = Enum.AnimationPriority.Action
                loadAnimation4.Looped =  true
                loadAnimation4:Play(0.2)
                loadAnimation4:AdjustSpeed(v47)
            end
            return
        end
    end
    for index6, value7 in ipairs({
        {
            Name = "Effortless Floating",
            Id = "133418516499878"
        },
        {
            Name = "GODLY AURA",
            Id = "125378928773802"
        },
        {
            Name = "CLOUDS",
            Id = "131229429849319"
        },
        {
            Name = "EMPEROR",
            Id = "128335678445071"
        },
        {
            Name = "SPIDERMAN",
            Id = "117370624301002"
        },
        {
            Name = "FLOAT THINK",
            Id = "111671107675296"
        },
        {
            Name = "FLOAT SIT",
            Id = "81042504000817"
        },
        {
            Name = "LOVE FLOAT",
            Id = "118373301043265"
        },
        {
            Name = "Cute Diva Sit",
            Id = "119802987048033"
        },
        {
            Name = "Gojo Float",
            Id = "71814840518109"
        },
        {
            Name = "Thragg's Aura Pose",
            Id = "116157665289694"
        },
    }
) do
        local v50 = value7
        local instance68 = Instance.new("TextButton", instance58)
        instance68.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
        instance68.Font = Enum.Font.GothamBold
        instance68.Text = v50.Name
        instance68.TextColor3 = Color3.fromRGB(255, 255, 255)
        instance68.TextSize = 11
        Instance.new("UICorner", instance68).CornerRadius = UDim.new(0, 6)
        instance68.MouseButton1Click:Connect(function()
            f13(v50.Id, instance68)
        end
)
    end
    for index7, value8 in ipairs(v46) do
        local v51 = value8
        local instance69 = Instance.new("TextButton", instance61)
        instance69.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
        instance69.Font = Enum.Font.GothamBold
        instance69.Text = v51.Name
        instance69.TextColor3 = Color3.fromRGB(255, 255, 255)
        instance69.TextSize = 11
        Instance.new("UICorner", instance69).CornerRadius = UDim.new(0, 6)
        instance69.MouseButton1Click:Connect(function()
            f13(v51.Id, instance69)
        end
)
    end
    instance65.MouseButton1Click:Connect(function()
        v47 = math.clamp(v47 - 0.25, 0.25, 5)
        instance64.Text = "Speed: "..string.format("%.2f", v47).. "x"
        if loadAnimation4 then
            loadAnimation4:AdjustSpeed(v47)
        end
    end
)
    instance66.MouseButton1Click:Connect(function()
        v47 = math.clamp(v47 + 0.25, 0.25, 5)
        instance64.Text = "Speed: "..string.format("%.2f", v47).. "x"
        if loadAnimation4 then
            loadAnimation4:AdjustSpeed(v47)
        end
    end
)
    instance67.MouseButton1Click:Connect(function()
        f12()
    end
)
    local scripts = f3("Scripts")
    local instance70 = Instance.new("ScrollingFrame", scripts)
    instance70.BackgroundTransparency = 1
    instance70.Size = UDim2.new(1, 0, 1, 0)
    instance70.CanvasSize = UDim2.new(0, 0, 0, 280)
    instance70.ScrollBarThickness = 4
    instance70.ScrollBarImageColor3 = Color3.fromRGB(0, 150, 255)
    Instance.new("UIListLayout", instance70).Padding = UDim.new(0, 10)
    local function f14(text4)
        local instance71 = Instance.new("TextButton", instance70)
        instance71.BackgroundColor3 = Color3.fromRGB(0, 130, 230)
        instance71.Size = UDim2.new(1,  - 10, 0, 40)
        instance71.Font = Enum.Font.GothamBold
        instance71.Text = text4
        instance71.TextColor3 = Color3.fromRGB(255, 255, 255)
        instance71.TextSize = 13
        Instance.new("UICorner", instance71).CornerRadius = UDim.new(0, 8)
        return instance71
    end
    f14("RINKAZE COMMAND (IY)").MouseButton1Click:Connect(function()
        local v52, v53 = pcall(function()
            return game:HttpGet("https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source")
        end
)
        if v52 and v53 then
            local v54 = loadstring((v53:gsub("Infinite Yield", "RINKAZE"):gsub("InfiniteYield", "RINKAZE"):gsub("IY", "RINKAZE"):gsub("iy", "rinkaze")))
            if v54 then
                v54()
            end
        end
    end
)
    f14("Infinite Yield (Original)").MouseButton1Click:Connect(function()
        loadstring(game:HttpGet("https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source"))()
    end
)
    f14("RINKAZE SPAMMER").MouseButton1Click:Connect(function()
        loadstring(game:HttpGet("https://gist.githubusercontent.com/epicfire21/758d6e8d9e71ca9d5461831ec9c6d936/raw/430d7447190438a1ae02a9432ec74cf8d56fc472/GENONSPAMMER.lua"))()
    end
)
    f14("RINKAZE CHAT").MouseButton1Click:Connect(function()
        loadstring(game:HttpGet("https://gist.githubusercontent.com/falconxyash97/bda426b761d3b2834932437447aa687e/raw/8596f72c6ccb8aeeb3f53a317070b37317d1f03d/RINKAZE.lua"))()
    end
)
    local credits = f3("Credits")
    local instance72 = Instance.new("TextLabel", credits)
    instance72.BackgroundTransparency = 1
    instance72.Position = UDim2.new(0, 0, 0, 15)
    instance72.Size = UDim2.new(1, 0, 0, 30)
    instance72.Font = Enum.Font.GothamBold
    instance72.Text = "CREDITS: MADE BY YASH"
    instance72.TextColor3 = Color3.fromRGB(0, 195, 255)
    instance72.TextSize = 18
    instance72.TextXAlignment = Enum.TextXAlignment.Center
    local instance73 = Instance.new("TextLabel", credits)
    instance73.BackgroundTransparency = 1
    instance73.Position = UDim2.new(0, 12, 0, 55)
    instance73.Size = UDim2.new(1,  - 24, 0, 200)
    instance73.Font = Enum.Font.GothamMedium
    instance73.Text = "RINKAZE PANEL is a clean and powerful Brookhaven script made with love and hard work.\n\nFeatures include:\n• Smooth Fly with Speed Control\n• Advanced Target System + Target Tool\n• CHOCO BANG + OP Bang\n• Bus Fling / Bus Bring / Couch Fling\n• Protect + Protected Players System\n• Idles + Emotes with Speed Controller\n• Game Tab (Anti Fling, Anti AFK, Shaders)\n• And much more...\n\nThank you for using RINKAZE PANEL.\nEnjoy and stay safe!"
    instance73.TextColor3 = Color3.fromRGB(160, 210, 255)
    instance73.TextSize = 13
    instance73.TextWrapped =  true
    instance73.TextXAlignment = Enum.TextXAlignment.Left
    instance73.TextYAlignment = Enum.TextYAlignment.Top
    for index8, value9 in ipairs({
        "Home",
        "Game",
        "Character",
        "Target",
        "Protect",
        "IDLE + EMOTE",
        "Scripts",
        "Credits",
    }
) do
        local v55 = value9
        local instance74 = Instance.new("TextButton", instance8)
        instance74.Name = v55.. "Tab"
        instance74.Size = UDim2.new(1, 0, 0, 28)
        instance74.Font = Enum.Font.GothamMedium
        instance74.Text = v55
        instance74.TextSize = v55 == "IDLE + EMOTE" and 10 or 12
        Instance.new("UICorner", instance74).CornerRadius = UDim.new(0, 6)
        if index8 == 1 then
            instance74.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
            instance74.TextColor3 = Color3.fromRGB(255, 255, 255)
        else
            instance74.BackgroundColor3 = Color3.fromRGB(10, 18, 32)
            instance74.TextColor3 = Color3.fromRGB(100, 160, 210)
        end
        instance74.MouseButton1Click:Connect(function()
            for key2, value10 in pairs(v4) do
                value10.Visible = key2 == v55
            end
            for key3, value11 in pairs(instance8:GetChildren()) do
                if value11:IsA("TextButton") then
                    value11.BackgroundColor3 = Color3.fromRGB(10, 18, 32)
                    value11.TextColor3 = Color3.fromRGB(100, 160, 210)
                end
            end
            instance74.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
            instance74.TextColor3 = Color3.fromRGB(255, 255, 255)
        end
)
    end
    local rinkazeFloatingBall = Instance.new("TextButton", rinkazePanelGui)
    rinkazeFloatingBall.Name = "RinkazeFloatingBall"
    rinkazeFloatingBall.BackgroundColor3 = Color3.fromRGB(8, 16, 30)
    rinkazeFloatingBall.Position = UDim2.new(0.05, 0, 0.25, 0)
    rinkazeFloatingBall.Size = UDim2.new(0, 52, 0, 52)
    rinkazeFloatingBall.Font = Enum.Font.GothamBold
    rinkazeFloatingBall.Text = "RK"
    rinkazeFloatingBall.TextColor3 = Color3.fromRGB(0, 195, 255)
    rinkazeFloatingBall.TextSize = 18
    rinkazeFloatingBall.Active =  true
    rinkazeFloatingBall.Draggable =  true
    Instance.new("UICorner", rinkazeFloatingBall).CornerRadius = UDim.new(1, 0)
    local instance75 = Instance.new("UIStroke", rinkazeFloatingBall)
    instance75.Color = Color3.fromRGB(0, 150, 255)
    instance75.Thickness = 2
    local v56 =  false
    local function f15()
        v56 =  not v56
        if v56 then
            mainFrame.Size = UDim2.new(0, 0, 0, 0)
            mainFrame.Visible =  true
            sound:Play()
            tweenService:Create(mainFrame, TweenInfo.new(0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
                Size = UDim2.new(0,
                520,
                0,
                330)
            }
):Play()
        else
            sound2:Play()
            local create = tweenService:Create(mainFrame, TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
                Size = UDim2.new(0,
                0,
                0,
                0)
            }
)
            create:Play()
            create.Completed:Connect(function()
                if not v56 then
                    mainFrame.Visible =  false
                end
            end
)
        end
    end
    rinkazeFloatingBall.MouseButton1Click:Connect(f15)
    instance7.MouseButton1Click:Connect(f15)
    print("RINKAZE PANEL v4.5 Loaded Successfully!")
    game.StarterGui:SetCore("SendNotification", {
        Title = "RINKAZE PANEL",
        Text = "v4.5 Loaded! Click RK button",
        Duration = 5,
    }
)
end
)
if v1 then
    print("✅ Rinkaze Panel executed without errors")
else
    warn("❌ Rinkaze Error:", v2)
    print("Error Details:", v2)
end