-- Lynd Deobfuscator & Dumper | https://discord.gg/SRvRc2XF6s
-- Kamui X Lularphed
-- Deobf by lynd

local v8="v1.0"
local v9=loadstring(game:HttpGet("https://raw.githubusercontent.com/minhdepzai-v/LibraryRobloc/refs/heads/main/RedzLibrary.lua"))()
local v10=game:GetService("ReplicatedStorage")
local v11=game:GetService("Players")
local v12=game:GetService("RunService")
local v13=workspace.CurrentCamera
local v14=v11.LocalPlayer
local v15=game:GetService("TeleportService")
local v16=game:GetService("HttpService")
v14:SetAttribute("KamuiHubUser",true)
local v17={"testeeeeeeeepouraa_99391","teste_ofc9098764","teste_ofc90"}
local v18={7217546593}
local function v19(v30)
  local v32
  for v501,v502 in ipairs(v17) do
    if ((v30.Name==v502) or (v30.DisplayName==v502)) then
      return true
    end
  end
  for v503,v504 in ipairs(v18) do
    if (v30.UserId==v504) then
      return true
    end
  end
  return false
end
local v20=false
pcall(function()
  local v34
  local v35
  writefile("kamui_api_test.tmp","ok")
  v34=readfile("kamui_api_test.tmp")
  v35=isfile("kamui_api_test.tmp")
  pcall(function()
    delfile("kamui_api_test.tmp")
  end
  )
  if ((v34=="ok") and (v35==true)) then
    v20=true
  end
end
)
local v21={["pt"]={["hub_title"]="Kamui x hub (" .. v8 .. ")",["hub_subtitle"]="Brookhaven Troll + Gamepass + Extras",["credits_tab"]="Créditos",["creator_label"]="Criador",["creator_name"]="testeeeeeeeepouraa_99391",["discord_desc"]="Entre no nosso servidor Discord",["troll_tab"]="Troll",["target_dropdown"]="Alvo",["target_desc"]="Selecione o jogador (ou All)",["loading"]="Carregando...",["no_players"]="Nenhum jogador",["all_option"]="All",["refresh_btn"]="Atualizar",["view_toggle"]="View Alvo",["teleport_btn"]="Teleportar",["fling_selector"]="Fling",["method_selector"]="Método",["execute_btn"]="Executar Fling",["touch_fling_toggle"]="Touch Fling ball",["gamepass_tab"]="Gamepass",["gamepass_warn"]="Só funciona com anúncios.",["vip_btn"]="VIP NameColor",["mansion_btn"]="Mansão",["disaster_btn"]="Pacote do Desastre",["music_btn"]="Música",["house043_btn"]="Casa 043",["music_tab"]="Música",["music_id_placeholder"]="ID da música",["music_send_btn"]="Enviar ID de Música",["music_saved_dropdown"]="Músicas Salvas",["music_save_name"]="Nome para salvar",["music_save_btn"]="Salvar Música",["music_delete_btn"]="Deletar Música",["music_play_saved_btn"]="Tocar Música Salva",["extras_tab"]="Extras",["color_dropdown"]="Cor do Hub",["color_blue"]="Azul",["color_red"]="Vermelho",["color_black"]="Preto",["color_purple"]="Roxo",["auto_rejoin"]="Auto Rejoin",["protection_tab"]="Proteção",["anti_sit"]="Anti Sit",["noclip"]="Noclip",["anti_void"]="Anti Void",["anti_fling"]="Anti-Fling",["test_tab"]="Teste",["key_placeholder"]="Digite a chave",["access_granted"]="Acesso concedido",["access_denied"]="Chave incorreta",["avatar_tab"]="Avatar",["copy_avatar_btn"]="Copy Avatar (completo)",["remove_avatar_btn"]="Remover Meu Avatar",["avatar_target_dropdown"]="Selecionar Jogador",["refresh_list_btn"]="Atualizar Lista",["admin_tab"]="Admin",["admin_warn"]="Acesso Restrito",["admin_btn"]="Executar Admin Hub",["changelog"]=[[
@ 2004 - v1.0
+ Admin Hub integrado ao script
+ Tag [HUB] para usuários do
  script
  + Sistema de Kick via Raid Warning
  @ Copy Avatar corrigido (Shirt, Pants, Body)
  @ Sistema de música salva em memória
  ]]},["en"]={["hub_title"]="Kamui x hub (" .. v8 .. ")",["hub_subtitle"]="Brookhaven Troll + Gamepass + Extras",["credits_tab"]="Credits",["creator_label"]="Creator",["creator_name"]="testeeeeeeeepouraa_99391",["discord_desc"]="Join our Discord server",["troll_tab"]="Troll",["target_dropdown"]="Target",["target_desc"]="Select player (or All)",["loading"]="Loading...",["no_players"]="No players",["all_option"]="All",["refresh_btn"]="Refresh",["view_toggle"]="View Target",["teleport_btn"]="Teleport",["fling_selector"]="Fling",["method_selector"]="Method",["execute_btn"]="Execute Fling",["touch_fling_toggle"]="Touch Fling ball",["gamepass_tab"]="Gamepass",["gamepass_warn"]="Only works with ads.",["vip_btn"]="VIP NameColor",["mansion_btn"]="Mansion",["disaster_btn"]="Disaster Package",["music_btn"]="Music",["house043_btn"]="House 043",["music_tab"]="Music",["music_id_placeholder"]="Music ID",["music_send_btn"]="Send Music ID",["music_saved_dropdown"]="Saved Songs",["music_save_name"]="Name to save",["music_save_btn"]="Save Song",["music_delete_btn"]="Delete Song",["music_play_saved_btn"]="Play Saved Song",["extras_tab"]="Extras",["color_dropdown"]="Hub Color",["color_blue"]="Blue",["color_red"]="Red",["color_black"]="Black",["color_purple"]="Purple",["auto_rejoin"]="Auto Rejoin",["protection_tab"]="Protection",["anti_sit"]="Anti Sit",["noclip"]="Noclip",["anti_void"]="Anti Void",["anti_fling"]="Anti-Fling",["test_tab"]="Test",["key_placeholder"]="Enter key",["access_granted"]="Access granted",["access_denied"]="Wrong key",["avatar_tab"]="Avatar",["copy_avatar_btn"]="Copy Avatar (full)",["remove_avatar_btn"]="Remove My Avatar",["avatar_target_dropdown"]="Select Player",["refresh_list_btn"]="Refresh List",["admin_tab"]="Admin",["admin_warn"]="Restricted Access",["admin_btn"]="Execute Admin Hub",["changelog"]="\n@ 2026-09-13 - v1.0\n+ Admin Hub integrated into script\n+ [HUB] tag for script users\n+ Kick system via Raid Warning\n@ Copy Avatar fixed (Shirt, Pants, Body)\n@ Music save system in memory\n"}}
  local v22="kamui_saved_music.json"
  local v23={}
  if v20 then
    pcall(function()
      if isfile(v22) then
        local v380
        v380=readfile(v22)
        if (v380 and (v380~="")) then
          local v543
          v543=v16:JSONDecode(v380)
          if (type(v543)=="table") then
            for v608,v609 in pairs(v543) do
              v23[v608]=v609
            end
          end
        end
      end
    end
    )
  end
  local function v24()
    if not v20 then
      return false
    end
    return pcall(function()
      writefile(v22,v16:JSONEncode(v23))
    end
    )
  end
  local function v25()
    local v38
    local v39
    local v40
    local v41
    local v42
    local v43
    local v44
    local v45
    local v46
    local v47
    local v48
    v38=v14:WaitForChild("PlayerGui")
    v39=v38:FindFirstChild("KamuiLanguageScreen")
    if v39 then
      v39:Destroy()
    end
    v40=Instance.new("ScreenGui")
    v40.Name="KamuiLanguageScreen"
    v40.Parent=v38
    v40.ResetOnSpawn=false
    v40.IgnoreGuiInset=true
    v40.ZIndexBehavior=Enum.ZIndexBehavior.Sibling
    v41=Instance.new("Frame")
    v41.Parent=v40
    v41.AnchorPoint=Vector2.new(0.5,0.5)
    v41.Position=UDim2.new(0.5,0,0.5,0)
    v41.Size=UDim2.new(1,0,1,0)
    v41.BackgroundColor3=Color3.new(0,0,0)
    v41.BorderSizePixel=0
    v42=Instance.new("TextLabel")
    v42.Parent=v41
    v42.AnchorPoint=Vector2.new(0.5,0)
    v42.Position=UDim2.new(0.5,0,0.2,0)
    v42.Size=UDim2.new(0.8,0,0.1,0)
    v42.BackgroundTransparency=1
    v42.Text="Kamui x hub (" .. v8 .. ")"
    v42.TextColor3=Color3.new(1,1,1)
    v42.TextScaled=true
    v42.Font=Enum.Font.SourceSansBold
    v43=Instance.new("TextLabel")
    v43.Parent=v41
    v43.AnchorPoint=Vector2.new(0.5,0)
    v43.Position=UDim2.new(0.5,0,0.3,0)
    v43.Size=UDim2.new(0.8,0,0.08,0)
    v43.BackgroundTransparency=1
    v43.Text="Escolha o idioma / Choose your language"
    v43.TextColor3=Color3.fromRGB(200,200,200)
    v43.TextScaled=true
    v43.Font=Enum.Font.SourceSans
    v44=Instance.new("TextButton")
    v44.Parent=v41
    v44.AnchorPoint=Vector2.new(0.5,0.5)
    v44.Position=UDim2.new(0.35,0,0.45,0)
    v44.Size=UDim2.new(0.2,0,0.1,0)
    v44.BackgroundColor3=Color3.fromRGB(0,255,0)
    v44.BorderSizePixel=0
    v44.Text="Português 🇧🇷"
    v44.TextColor3=Color3.new(0,0,0)
    v44.TextScaled=true
    v44.Font=Enum.Font.SourceSansBold
    v45=Instance.new("TextButton")
    v45.Parent=v41
    v45.AnchorPoint=Vector2.new(0.5,0.5)
    v45.Position=UDim2.new(0.65,0,0.45,0)
    v45.Size=UDim2.new(0.2,0,0.1,0)
    v45.BackgroundColor3=Color3.fromRGB(255,0,0)
    v45.BorderSizePixel=0
    v45.Text="English 🇺🇸"
    v45.TextColor3=Color3.new(1,1,1)
    v45.TextScaled=true
    v45.Font=Enum.Font.SourceSansBold
    v46=Instance.new("TextButton")
    v46.Parent=v41
    v46.AnchorPoint=Vector2.new(0.5,0.5)
    v46.Position=UDim2.new(0.5,0,0.65,0)
    v46.Size=UDim2.new(0.3,0,0.1,0)
    v46.BackgroundColor3=Color3.fromRGB(50,50,50)
    v46.BorderSizePixel=0
    v46.Text="Executar"
    v46.TextColor3=Color3.new(1,1,1)
    v46.TextScaled=true
    v46.Font=Enum.Font.SourceSansBold
    v47=Instance.new("TextLabel")
    v47.Parent=v41
    v47.AnchorPoint=Vector2.new(0.5,0)
    v47.Position=UDim2.new(0.5,0,0.78,0)
    v47.Size=UDim2.new(0.8,0,0.1,0)
    v47.BackgroundTransparency=1
    v47.Text="Selecione o idioma e clique em Executar"
    v47.TextColor3=Color3.new(1,1,1)
    v47.TextScaled=true
    v47.Font=Enum.Font.SourceSans
    v48="pt"
    v44.MouseButton1Click:Connect(function()
      v48="pt"
      v47.Text="Idioma selecionado: Português"
    end
    )
    v45.MouseButton1Click:Connect(function()
      v48="en"
      v47.Text="Idioma selecionado: English"
    end
    )
    v46.MouseButton1Click:Connect(function()
      v40:Destroy()
      buildHub(v48)
    end
    )
  end
  local function v26(v49)
    local v50=v21[v49]
    for v126,v127 in ipairs(v11:GetPlayers()) do
      if (v127:GetAttribute("KamuiHubUser")==nil) then
      end
    end
    local v51=v9:MakeWindow({["Title"]="Kamui Admin Hub (" .. v8 .. ")",["SubTitle"]="Painel de Administração",["SaveFolder"]="kamui_admin"})
    v51:AddMinimizeButton({["Button"]={["Image"]="rbxassetid://71014873973869",["BackgroundTransparency"]=0},["Corner"]={["CornerRadius"]=UDim.new(35,1)}})
    local v52=nil
    local v53
    local function v54()
      local v128={}
      for v261,v262 in ipairs(v11:GetPlayers()) do
        if (v262~=v14) then
          local v383=((v262:GetAttribute("KamuiHubUser")==true) and " [HUB]") or ""
          table.insert(v128,v262.Name .. v383)
        end
      end
      if (#v128==0) then
        table.insert(v128,"Nenhum jogador")
      end
      return v128
    end
    local function v55(v129)
      return (v129:gsub(" %[HUB%]",""))
    end
    local function v56()
      if not v52 then
        return nil
      end
      return v11:FindFirstChild(v55(v52))
    end
    local v57=v51:MakeTab({"Troll","rbxassetid://6026568198"})
    v53=v57:AddDropdown({["Name"]="Alvo",["Description"]="Selecione o jogador (HUB = usuário do script)",["Options"]=v54(),["Default"]="",["Callback"]=function(v130)
      if (v130 and (v130~="Nenhum jogador") and (v130~="")) then
        v52=v130
      else
        v52=nil
      end
    end
    })
    v57:AddButton({"Atualizar Lista",function()
      if v53 then
        pcall(function()
          v53:Set(v54())
        end
        )
      end
    end
    })
    v57:AddButton({"Kick Player",function()
      local v131=v56()
      if not v131 then
        return
      end
      local v132=v10.RE and v10.RE:FindFirstChild("1Ki1ck")
      if v132 then
        pcall(function()
          v132:FireServer(v131)
        end
        )
      end
      local v133=v131.Character and v131.Character:FindFirstChild("HumanoidRootPart")
      if v133 then
        v133.CFrame=CFrame.new(0, -1000000,0)
      end
    end
    })
    v57:AddButton({"Kill Player",function()
      local v135
      local v136
      local v137
      v135=v56()
      if (not v135 or not v135.Character) then
        return
      end
      v136=v135.Character:FindFirstChildOfClass("Humanoid")
      if v136 then
        v136.Health=0
      end
      v137=v135.Character:FindFirstChild("HumanoidRootPart")
      if v137 then
        v137.CFrame=CFrame.new(0, -1000000,0)
      end
    end
    })
    local v58=""
    v57:AddTextBox({["Name"]="Mensagem (Say)",["PlaceholderText"]="Digite a mensagem que o alvo vai falar",["Callback"]=function(v138)
      v58=v138
    end
    })
    v57:AddButton({"Say (Alvo Fala)",function()
      local v139=v56()
      if (not v139 or (v58=="")) then
        return
      end
      local v140=v10.RE and v10.RE:FindFirstChild("1Cha1t")
      if v140 then
        pcall(function()
          v140:FireServer(v139,v58)
        end
        )
      end
      local v141=v139.Character and v139.Character:FindFirstChild("Head")
      if v141 then
        local v356
        local v357
        v356=Instance.new("BillboardGui",v141)
        v356.Size=UDim2.new(0,200,0,50)
        v356.StudsOffset=Vector3.new(0,3,0)
        v357=Instance.new("TextLabel",v356)
        v357.Size=UDim2.new(1,0,1,0)
        v357.BackgroundTransparency=1
        v357.Text=v58
        v357.TextScaled=true
        v357.TextColor3=Color3.new(1,1,1)
        task.delay(5,function()
          if v356 then
            v356:Destroy()
          end
        end
        )
      end
    end
    })
    v57:AddButton({"Levar para Backrooms",function()
      local v143
      local v144
      v143=v56()
      if (not v143 or not v143.Character) then
        return
      end
      v144=v143.Character:FindFirstChild("HumanoidRootPart")
      if not v144 then
        return
      end
      v144.CFrame=CFrame.new(0, -500,0)
      v144.Anchored=true
      task.delay(3,function()
        if (v144 and v144.Parent) then
          v144.Anchored=false
        end
      end
      )
    end
    })
    local v59=false
    local v60=nil
    v57:AddButton({"Lag Player (ON)",function()
      local v146
      v146=v56()
      if (not v146 or not v146.Character) then
        return
      end
      v59=true
      if v60 then
        v60:Disconnect()
      end
      v60=v12.Heartbeat:Connect(function()
        local v411
        local v412
        local v413
        if not v59 then
          return
        end
        v411=v56()
        if (not v411 or not v411.Character) then
          return
        end
        v412=v411.Character:FindFirstChildOfClass("Humanoid")
        v413=v411.Character:FindFirstChild("HumanoidRootPart")
        if (v412 and v413) then
          v412.WalkSpeed=0
          v412.JumpPower=0
          v412.JumpHeight=0
          if not v413:FindFirstChild("KamuiLagAnchor") then
            local v612
            v612=Instance.new("BodyPosition")
            v612.Name="KamuiLagAnchor"
            v612.MaxForce=Vector3.new(math.huge,math.huge,math.huge)
            v612.Position=v413.Position
            v612.Parent=v413
          end
          for v604=1,20 do
            local v606
            v606=Instance.new("Part")
            v606.Size=Vector3.new(1,1,1)
            v606.CFrame=v413.CFrame
            v606.Anchored=false
            v606.CanCollide=true
            v606.Transparency=1
            v606.Parent=workspace
            pcall(function()
              v606:SetNetworkOwner(v14)
            end
            )
            task.delay(0.1,function()
              if v606 then
                v606:Destroy()
              end
            end
            )
          end
        end
      end
      )
    end
    })
    v57:AddButton({"Lag Player (OFF)",function()
      local v148
      local v149
      local v150
      v59=false
      if v60 then
        v60:Disconnect()
        v60=nil
      end
      v148=v56()
      if (not v148 or not v148.Character) then
        return
      end
      v149=v148.Character:FindFirstChildOfClass("Humanoid")
      if v149 then
        v149.WalkSpeed=16
        v149.JumpPower=50
      end
      v150=v148.Character:FindFirstChild("HumanoidRootPart")
      if (v150 and v150:FindFirstChild("KamuiLagAnchor")) then
        v150.KamuiLagAnchor:Destroy()
      end
    end
    })
    local v61=v51:MakeTab({"Tools","rbxassetid://7733964579"})
    v61:AddButton({"Dar Speed (Alvo)",function()
      local v152
      local v153
      v152=v56()
      if (not v152 or not v152.Character) then
        return
      end
      v153=v152.Character:FindFirstChildOfClass("Humanoid")
      if v153 then
        v153.WalkSpeed=100
      end
    end
    })
    v61:AddButton({"Dar Fly (Alvo)",function()
      local v155
      local v156
      local v157
      v155=v56()
      if (not v155 or not v155.Character) then
        return
      end
      v156=v155.Character:FindFirstChild("HumanoidRootPart")
      if not v156 then
        return
      end
      v157=Instance.new("BodyVelocity")
      v157.Name="KamuiFly"
      v157.MaxForce=Vector3.new(math.huge,math.huge,math.huge)
      v157.Velocity=Vector3.new(0,50,0)
      v157.Parent=v156
      task.delay(3,function()
        if v157 then
          v157:Destroy()
        end
      end
      )
    end
    })
    v61:AddButton({"Dar Invisibilidade (Alvo)",function()
      local v159
      v159=v56()
      if (not v159 or not v159.Character) then
        return
      end
      for v414,v415 in ipairs(v159.Character:GetDescendants()) do
        if v415:IsA("BasePart") then
          v415.Transparency=1
        end
      end
    end
    })
    v61:AddButton({"Restaurar Visibilidade (Alvo)",function()
      local v161
      v161=v56()
      if (not v161 or not v161.Character) then
        return
      end
      for v416,v417 in ipairs(v161.Character:GetDescendants()) do
        if (v417:IsA("BasePart") and (v417.Name~="HumanoidRootPart")) then
          v417.Transparency=0
        end
      end
    end
    })
    local v62=v51:MakeTab({"Misc","rbxassetid://7733964579"})
    v62:AddButton({"Atualizar Tags [HUB]",function()
      for v263,v264 in ipairs(v11:GetPlayers()) do
        if (v264.Character and v264.Character:FindFirstChild("Head")) then
          local v392
          local v393
          v392=v264.Character.Head
          v393=v392:FindFirstChild("KamuiTag")
          if v393 then
            v393:Destroy()
          end
          if (v264:GetAttribute("KamuiHubUser")==true) then
            local v547=Instance.new("BillboardGui",v392)
            v547.Name="KamuiTag"
            v547.Size=UDim2.new(0,100,0,30)
            v547.StudsOffset=Vector3.new(0,2.5,0)
            v547.AlwaysOnTop=true
            local v552=Instance.new("TextLabel",v547)
            v552.Size=UDim2.new(1,0,1,0)
            v552.BackgroundTransparency=1
            v552.Text="[HUB]"
            v552.TextColor3=Color3.fromRGB(0,255,0)
            v552.TextScaled=true
            v552.Font=Enum.Font.SourceSansBold
          end
        end
      end
    end
    })
    v62:AddButton({"Remover Todas Tags",function()
      for v265,v266 in ipairs(v11:GetPlayers()) do
        if (v266.Character and v266.Character:FindFirstChild("Head")) then
          local v394=v266.Character.Head:FindFirstChild("KamuiTag")
          if v394 then
            v394:Destroy()
          end
        end
      end
    end
    })
    v62:AddButton({"Listar Usuários do Hub",function()
      local v163
      v163={}
      for v418,v419 in ipairs(v11:GetPlayers()) do
        if (v419:GetAttribute("KamuiHubUser")==true) then
          table.insert(v163,v419.Name)
        end
      end
      if (#v163==0) then
        v163={"Ninguém"}
      end
      v51:Dialog({["Title"]="Usuários do Hub",["Text"]=table.concat(v163,"\n"),["Options"]={{"OK",function()
      end
      }}})
    end
    })
    local v63=v51:MakeTab({"Credit","rbxassetid://7733955669"})
    v63:AddParagraph({"Kamui Admin Hub",v8})
    v63:AddParagraph({"Criador","testeeeeeeeepouraa_99391"})
    v63:AddDiscordInvite({["Name"]="Kamui x Hub",["Description"]="Entre no nosso Discord",["Logo"]="https://chatgpt.com/s/m_6a7794b41a248191a43ee4614aabf65e",["Invite"]="https://discord.gg/stMFbDGYut"})
    v51:SelectTab(v57)
  end
  function buildHub(v64)
    local v65=v21[v64]
    local v66=v9:MakeWindow({["Title"]=v65.hub_title,["SubTitle"]=v65.hub_subtitle,["SaveFolder"]="kamui_hub_main"})
    v66:AddMinimizeButton({["Button"]={["Image"]="rbxassetid://71014873973869",["BackgroundTransparency"]=0},["Corner"]={["CornerRadius"]=UDim.new(35,1)}})
    local v67=v10.RE and v10.RE:FindFirstChild("1RPNam1eTex1t")
    if v67 then
      pcall(function()
        v67:FireServer("RolePlayName",v65.hub_title)
        v67:FireServer("RolePlayBio","new era")
      end
      )
    end
    task.defer(function()
      local v165
      task.wait(1)
      pcall(function()
        v66:Dialog({["Title"]="Update " .. v8,["Text"]=v65.changelog,["Options"]={{"OK",function()
        end
        }}})
      end
      )
    end
    )
    local v68=v66:MakeTab({v65.credits_tab,"rbxassetid://7733955669"})
    v68:AddParagraph({v65.creator_label,v65.creator_name})
    v68:AddParagraph({"Versão / Version",v8})
    v68:AddDiscordInvite({["Name"]="Kamui x Hub",["Description"]=v65.discord_desc,["Logo"]="https://chatgpt.com/s/m_6a7794b41a248191a43ee4614aabf65e",["Invite"]="https://discord.gg/stMFbDGYut"})
    local v69=nil
    local v70=nil
    local v71=nil
    local v72=false
    local v73=nil
    local v74=false
    local v75=nil
    local v76=false
    local v77=nil
    local v78=false
    local v79=nil
    local v80=false
    local v81=nil
    local v82=false
    local v83=nil
    local v84=false
    local v85=nil
    local v86=false
    local v87=nil
    local v88=false
    local v89,v90
    local function v91()
      local v166={v65.all_option}
      for v267,v268 in ipairs(v11:GetPlayers()) do
        if (v268~=v14) then
          table.insert(v166,v268.Name)
        end
      end
      if (#v166==1) then
        table.insert(v166,v65.no_players)
      end
      return v166
    end
    local function v92()
      local v168
      v168=v91()
      if v89 then
        pcall(function()
          v89:Set(v168)
        end
        )
      end
      if v90 then
        pcall(function()
          v90:Set(v168)
        end
        )
      end
    end
    local function v93()
      local v169=v10.RE and v10.RE:FindFirstChild("1Clea1rTool1s")
      if v169 then
        pcall(function()
          v169:FireServer("ClearAllTools")
        end
        )
      end
    end
    local function v94()
      local v171
      local v172
      local v173
      local v174
      local v175
      v171=workspace:FindFirstChild("WorkspaceCom")
      if not v171 then
        return nil
      end
      v172=v171:FindFirstChild("001_SoccerBalls")
      if not v172 then
        return nil
      end
      v173=v14.Backpack
      if not v173:FindFirstChild("SoccerBall") then
        local v560=v10.RE and v10.RE:FindFirstChild("1Too1l")
        if v560 then
          pcall(function()
            v560:InvokeServer("PickingTools","SoccerBall")
          end
          )
        end
      end
      v174=0
      while not v173:FindFirstChild("SoccerBall") and (v174<5) do
        task.wait(0.1)
        v174=v174 + 0.1
      end
      if not v173:FindFirstChild("SoccerBall") then
        return nil
      end
      v173.SoccerBall.Parent=v14.Character
      v174=0
      while not v172:FindFirstChild("Soccer" .. v14.Name) and (v174<5) do
        task.wait(0.1)
        v174=v174 + 0.1
      end
      v175=v172:FindFirstChild("Soccer" .. v14.Name)
      if not v175 then
        return nil
      end
      v175.CanCollide=false
      v175.Massless=true
      v175.CustomPhysicalProperties=PhysicalProperties.new(0.001,0,0,0,0)
      return v175
    end
    local function v95()
      local v177
      local v178
      local v179
      v177=0
      v178=nil
      v179=nil
      v178=v14.Character
      if not v178 then
        return
      end
      v179=v178:FindFirstChild("HumanoidRootPart")
      if not v179 then
        return
      end
      for v527,v528 in ipairs(v179:GetChildren()) do
        if (v528:IsA("BodyVelocity") or v528:IsA("BodyPosition") or v528:IsA("BodyGyro") or v528:IsA("AlignPosition") or v528:IsA("AlignOrientation") or v528:IsA("Torque")) then
          if (v528.Name~="KamuiKeepAlive") then
            pcall(function()
              v528:Destroy()
            end
            )
          end
        end
      end
      if (v179.Position.Y< -50) then
        v179.CFrame=CFrame.new(v179.Position.X,50,v179.Position.Z)
      end
    end
    local v96=v66:MakeTab({v65.troll_tab,"rbxassetid://6026568198"})
    v89=v96:AddDropdown({["Name"]=v65.target_dropdown,["Description"]=v65.target_desc,["Options"]=v91(),["Default"]="",["Callback"]=function(v180)
      if (v180 and (v180~=v65.no_players) and (v180~="") and (v180~=v65.loading)) then
        v69=v180
        getgenv().Target=v180
      else
        v69=nil
        getgenv().Target=nil
      end
    end
    })
    v96:AddButton({v65.refresh_btn,function()
      v92()
    end
    })
    v96:AddToggle({["Name"]=v65.view_toggle,["Default"]=false,["Callback"]=function(v181)
      v72=v181
      if v181 then
        local v361
        if v73 then
          v73:Disconnect()
        end
        v73=v12.RenderStepped:Connect(function()
          local v569
          if not v72 then
            return
          end
          if (v69==v65.all_option) then
            return
          end
          v569=v69 and v11:FindFirstChild(v69)
          if (not v569 or not v569.Character or not v569.Character:FindFirstChild("HumanoidRootPart")) then
            v72=false
            if v73 then
              v73:Disconnect()
              v73=nil
            end
            return
          end
          v13.CFrame=CFrame.lookAt(v13.CFrame.Position,v569.Character.HumanoidRootPart.Position)
        end
        )
      elseif v73 then
        v73:Disconnect()
        v73=nil
      end
    end
    })
    v96:AddButton({v65.teleport_btn,function()
      local v183
      if (v69==v65.all_option) then
        return
      end
      v183=v69 and v11:FindFirstChild(v69)
      if (v183 and v183.Character and v183.Character:FindFirstChild("HumanoidRootPart")) then
        local v451
        v451=v14.Character and v14.Character:FindFirstChild("HumanoidRootPart")
        if v451 then
          v451.CFrame=v183.Character.HumanoidRootPart.CFrame
        end
      end
    end
    })
    local v97
    local v98={["Fling Ball"]={"Rápido"},["Boat"]={"Pirata"}}
    v96:AddDropdown({["Name"]=v65.fling_selector,["Description"]="Escolha qual Fling vai ser usado",["Options"]={"Fling Ball","Boat"},["Default"]="",["Callback"]=function(v184)
      local v186
      v70=v184
      v186=v98[v184] or {}
      if v97 then
        pcall(function()
          v97:Set(v186)
        end
        )
      end
      v71=nil
    end
    })
    v97=v96:AddDropdown({["Name"]=v65.method_selector,["Description"]="Método de execução",["Options"]={},["Default"]="",["Callback"]=function(v187)
      v71=v187
    end
    })
    local function v99()
      if not v69 then
        return
      end
      local v188=v94()
      if not v188 then
        return
      end
      local v189=Instance.new("BodyVelocity")
      v189.Name="KamuiBallForce"
      v189.Velocity=Vector3.new(900000000,900000000,900000000)
      v189.MaxForce=Vector3.new(math.huge,math.huge,math.huge)
      v189.Parent=v188
      local v194=0
      if (v69==v65.all_option) then
        v75=v12.Heartbeat:Connect(function()
          if not v74 then
            return
          end
          v95()
          local v401={}
          for v421,v422 in ipairs(v11:GetPlayers()) do
            if ((v422~=v14) and v422.Character and v422.Character:FindFirstChild("HumanoidRootPart")) then
              table.insert(v401,v422)
            end
          end
          if (#v401==0) then
            return
          end
          local v402=math.floor((tick()%1) * #v401) + 1
          local v403=v401[v402]
          if (v403 and v403.Character and v403.Character:FindFirstChild("HumanoidRootPart")) then
            local v452=v403.Character.HumanoidRootPart
            v194=v194 + math.rad(35)
            v188.CFrame=v452.CFrame * CFrame.Angles(0,v194,0)
          end
        end
        )
      else
        local v363
        v363=v11:FindFirstChild(v69)
        if (not v363 or not v363.Character) then
          if v189 then
            v189:Destroy()
          end
          return
        end
        v75=v12.Heartbeat:Connect(function()
          local v515
          local v516
          local v517
          local v518
          if not v74 then
            return
          end
          v95()
          if (not v363 or not v363.Character or not v363.Character:FindFirstChild("HumanoidRootPart")) then
            v74=false
            if v75 then
              v75:Disconnect()
              v75=nil
            end
            if v189 then
              v189:Destroy()
            end
            v93()
            return
          end
          v515=v363.Character.HumanoidRootPart
          v516=math.sin(tick() * 35) * 5
          v517=v515.Position + (v515.Velocity/1.5)
          v518=Vector3.new(v517.X,v517.Y + v516,v517.Z)
          v194=v194 + math.rad(35)
          v188.CFrame=CFrame.new(v518) * CFrame.Angles(0,v194,0)
        end
        )
      end
    end
    local function v100()
      local v196
      v74=false
      if v75 then
        v75:Disconnect()
        v75=nil
      end
      v95()
      v93()
    end
    local v101=CFrame.new(1651.26318,27.0053825, -149.221039, -0.156708777, -0.957552075,0.241942972,1.9227e-8,0.244969606,0.969530761, -0.987644851,0.241942972, -0.156708777)
    local v102=CFrame.new(1649.99866,17.6373997, -148.948349,0.997544229, -0.000512517348, -0.0700377747, -0.000286260241,0.999935091, -0.0700377747,0.0700377747,0.000512517348,0.997544229)
    local function v103()
      local v198
      v198=workspace:FindFirstChild("Vehicles")
      if not v198 then
        return nil
      end
      return v198:FindFirstChild(v14.Name .. "Boat") or v198:FindFirstChild(v14.Name .. "Car") or v198:FindFirstChild("PirateBoat")
    end
    local function v104(v199)
      local v201
      local v202
      local v203
      local v204
      local v405
      v201=v14.Character
      if not v201 then
        return false
      end
      v202=v201:FindFirstChildOfClass("Humanoid")
      v203=v201:FindFirstChild("HumanoidRootPart")
      if (not v202 or not v203) then
        return false
      end
      v204=v199:FindFirstChild("VehicleSeat") or (v199:FindFirstChild("Body") and v199.Body:FindFirstChild("VehicleSeat")) or v199:FindFirstChildWhichIsA("VehicleSeat")
      if not v204 then
        return false
      end
      for v423=1,40 do
        if not v76 then
          return false
        end
        v201=v14.Character
        if not v201 then
          return false
        end
        v203=v201:FindFirstChild("HumanoidRootPart")
        v202=v201:FindFirstChildOfClass("Humanoid")
        if (not v203 or not v202) then
          return false
        end
        v203.CFrame=v204.CFrame * CFrame.new(0,3,0)
        task.wait(0.08)
        if v202.Sit then
          return true
        end
      end
      return v202.Sit
    end
    local function v105()
      if (v71~="Pirata") then
        return
      end
      v76=true
      v77=task.spawn(function()
        local v270=v10.RE and v10.RE:FindFirstChild("1Ca1r")
        while v76 do
          v95()
          local v364=v14.Character
          if (not v364 or not v364:FindFirstChild("HumanoidRootPart")) then
            break
          end
          local v365=v364.HumanoidRootPart
          if v270 then
            pcall(function()
              v270:FireServer("PickingBoat","PirateFree","Boat")
            end
            )
          end
          task.wait(1)
          if not v76 then
            break
          end
          v365.CFrame=v101
          task.wait(1)
          if not v76 then
            break
          end
          local v367=v103()
          if v367 then
            v104(v367)
          end
          task.wait(1)
          if not v76 then
            break
          end
          v365.CFrame=v102
          task.wait(4)
          if not v76 then
            break
          end
          v367=v103()
          if (v367 and v69 and (v69~=v65.all_option)) then
            local v427
            v427=v11:FindFirstChild(v69)
            if (v427 and v427.Character and v427.Character:FindFirstChild("HumanoidRootPart")) then
              local v573=0
              local v574=tick()
              while v76 and ((tick() -v574)<8) do
                v95()
                v367=v103()
                if not v367 then
                end
                if (not v427.Character or not v427.Character:FindFirstChild("HumanoidRootPart")) then
                end
                local v586=v427.Character.HumanoidRootPart
                v573=v573 + math.rad(39)
                pcall(function()
                  v367:SetPrimaryPartCFrame(v586.CFrame * CFrame.Angles(0,v573,0))
                end
                )
                task.wait()
              end
            end
          elseif (v367 and (v69==v65.all_option)) then
            local v519={}
            for v529,v530 in ipairs(v11:GetPlayers()) do
              if ((v530~=v14) and v530.Character and v530.Character:FindFirstChild("HumanoidRootPart")) then
                table.insert(v519,v530)
              end
            end
            for v531,v532 in ipairs(v519) do
              if not v76 then
                break
              end
              local v533=0
              local v534=tick()
              while v76 and ((tick() -v534)<1.5) do
                v95()
                v367=v103()
                if not v367 then
                  break
                end
                if (not v532.Character or not v532.Character:FindFirstChild("HumanoidRootPart")) then
                  break
                end
                local v563=v532.Character.HumanoidRootPart
                v533=v533 + math.rad(39)
                pcall(function()
                  v367:SetPrimaryPartCFrame(v563.CFrame * CFrame.Angles(0,v533,0))
                end
                )
                task.wait()
              end
            end
          end
          task.wait(0.5)
        end
      end
      )
    end
    local function v106()
      v76=false
      if v77 then
        pcall(function()
          task.cancel(v77)
        end
        )
        v77=nil
      end
      v95()
      v93()
    end
    v96:AddToggle({["Name"]=v65.execute_btn,["Description"]="Ativa/desativa o Fling selecionado",["Default"]=false,["Callback"]=function(v206)
      if not v70 then
        return
      end
      if (v70=="Fling Ball") then
        v74=v206
        if v206 then
          v99()
        else
          v100()
        end
      elseif (v70=="Boat") then
        if v206 then
          if (v71~="Pirata") then
            return
          end
          v105()
        else
          v106()
        end
      end
    end
    })
    local function v107()
      local v209
      local v210
      if not v14.Character then
        return
      end
      v209=v94()
      if not v209 then
        return
      end
      if v209:FindFirstChildOfClass("BodyVelocity") then
        v209:FindFirstChildOfClass("BodyVelocity"):Destroy()
      end
      v210=0
      v79=v12.Heartbeat:Connect(function()
        local v429
        local v430
        if not v78 then
          return
        end
        v95()
        v429=v14.Character
        if (not v429 or not v429:FindFirstChild("HumanoidRootPart")) then
          v78=false
          if v79 then
            v79:Disconnect()
            v79=nil
          end
          v93()
          return
        end
        v430=v429:FindFirstChild("HumanoidRootPart")
        if (v430 and v209 and v209.Parent) then
          v210=v210 + math.rad(35)
          v209.CFrame=v430.CFrame * CFrame.Angles(0,v210,0)
        end
      end
      )
    end
    local function v108()
      v78=false
      if v79 then
        local v456
        v79:Disconnect()
        v79=nil
      end
      v95()
      v93()
    end
    v96:AddToggle({["Name"]=v65.touch_fling_toggle,["Description"]="Bola gira presa no seu tronco",["Default"]=false,["Callback"]=function(v212)
      v78=v212
      if v212 then
        v107()
      else
        v108()
      end
    end
    })
    local function v109(v213)
      local v214={}
      if not v213 then
        return v214
      end
      local v215=v213:GetAppliedDescription()
      if not v215 then
        return v214
      end
      local v216={v215.BackAccessory,v215.FaceAccessory,v215.FrontAccessory,v215.NeckAccessory,v215.HatAccessory,v215.HairAccessory,v215.ShouldersAccessory,v215.WaistAccessory,v215.Shirt,v215.Pants,v215.GraphicTShirt}
      for v271,v272 in ipairs(v216) do
        if (v272 and (v272~="")) then
          local v407
          v407=tonumber(string.match(tostring(v272),"%d+"))
          if (v407 and (v407>0)) then
            table.insert(v214,v407)
          end
        end
      end
      return v214
    end
    local function v110()
      local v217=v14.Character
      if not v217 then
        return false
      end
      local v218=v217:FindFirstChildOfClass("Humanoid")
      if not v218 then
        return false
      end
      local v219=v10:WaitForChild("Remotes")
      local v220=v219:WaitForChild("Wear")
      if not v220 then
        return false
      end
      local v221=v109(v218)
      for v273,v274 in ipairs(v221) do
        pcall(function()
          v220:InvokeServer(v274)
        end
        )
        task.wait(0.3)
      end
      return true
    end
    local v111=v66:MakeTab({v65.avatar_tab,"rbxassetid://7733955669"})
    v111:AddParagraph({"Copy Avatar","Remove itens antigos e copia todos os itens do alvo"})
    v90=v111:AddDropdown({["Name"]=v65.avatar_target_dropdown,["Description"]="Selecione o jogador para copiar",["Options"]=v91(),["Default"]="",["Callback"]=function(v222)
      if (v222 and (v222~=v65.no_players) and (v222~="") and (v222~=v65.loading) and (v222~=v65.all_option)) then
        _G.AvatarTargetName=v222
        v69=v222
        getgenv().Target=v222
        if v89 then
          pcall(function()
            v89:Set({v222})
          end
          )
        end
      else
        _G.AvatarTargetName=nil
      end
    end
    })
    v111:AddButton({v65.refresh_list_btn,function()
      v92()
    end
    })
    v111:AddButton({v65.remove_avatar_btn,function()
      v110()
    end
    })
    v111:AddButton({v65.copy_avatar_btn,function()
      local v224
      local v225
      local v226
      local v227
      local v228
      local v229
      local v230
      local v231
      local v232
      v224=_G.AvatarTargetName or v69
      if (not v224 or (v224=="") or (v224==v65.all_option)) then
        return
      end
      v225=v11:FindFirstChild(v224)
      if (not v225 or not v225.Character) then
        return
      end
      v226=v225.Character:FindFirstChildOfClass("Humanoid")
      v227=v14.Character and v14.Character:FindFirstChildOfClass("Humanoid")
      if (not v226 or not v227) then
        return
      end
      v228=v10:WaitForChild("Remotes")
      v229=v228:WaitForChild("Wear")
      v230=v228:WaitForChild("WearBundle")
      v231=v109(v227)
      for v434,v435 in ipairs(v231) do
        pcall(function()
          v229:InvokeServer(v435)
        end
        )
        task.wait(0.3)
      end
      task.wait(0.5)
      v232=v109(v226)
      for v431,v432 in ipairs(v232) do
        pcall(function()
          v229:InvokeServer(v432)
        end
        )
        task.wait(0.35)
      end
      task.wait(0.5)
      pcall(function()
        v230:InvokeServer(43761506463462)
      end
      )
      task.wait(0.5)
      pcall(function()
        v230:InvokeServer(266739612157984)
      end
      )
    end
    })
    local v112=v66:MakeTab({v65.admin_tab,"rbxassetid://7733964579"})
    v112:AddParagraph({v65.admin_warn,"Somente jogadores autorizados."})
    v112:AddButton({v65.admin_btn,function()
      if v19(v14) then
        v26(v64)
      else
        local v370
        local v371
        local v372
        local v373
        local v374
        local v375
        local v376
        v370=v14:WaitForChild("PlayerGui")
        v371=Instance.new("ScreenGui",v370)
        v371.Name="RaidWarningGui"
        v371.ResetOnSpawn=false
        v372=Instance.new("Frame",v371)
        v372.AnchorPoint=Vector2.new(0.5,0.5)
        v372.Position=UDim2.new(0.5,0,0.5,0)
        v372.Size=UDim2.new(0,400,0,200)
        v372.BackgroundColor3=Color3.fromRGB(40,40,40)
        v372.BorderSizePixel=0
        Instance.new("UICorner",v372).CornerRadius=UDim.new(0,8)
        v373=Instance.new("TextLabel",v372)
        v373.Size=UDim2.new(1,0,0.25,0)
        v373.BackgroundTransparency=1
        v373.Text="Possible Raid Warning"
        v373.TextColor3=Color3.new(1,1,1)
        v373.TextScaled=true
        v373.Font=Enum.Font.SourceSansBold
        v374=Instance.new("TextLabel",v372)
        v374.Size=UDim2.new(0.9,0,0.4,0)
        v374.Position=UDim2.new(0.05,0,0.3,0)
        v374.BackgroundTransparency=1
        v374.Text="We have detected another Device in your house, in case you are alone, call 911 quickly\n(Error Code:1001)"
        v374.TextColor3=Color3.fromRGB(200,200,200)
        v374.TextScaled=true
        v374.TextWrapped=true
        v375=Instance.new("TextButton",v372)
        v375.Size=UDim2.new(0.4,0,0.2,0)
        v375.Position=UDim2.new(0.05,0,0.75,0)
        v375.BackgroundColor3=Color3.fromRGB(60,60,60)
        v375.Text="Keep Playing"
        v375.TextColor3=Color3.new(1,1,1)
        v375.TextScaled=true
        v376=Instance.new("TextButton",v372)
        v376.Size=UDim2.new(0.4,0,0.2,0)
        v376.Position=UDim2.new(0.55,0,0.75,0)
        v376.BackgroundColor3=Color3.new(1,1,1)
        v376.Text="Leave"
        v376.TextColor3=Color3.new(0,0,0)
        v376.TextScaled=true
        v376.Font=Enum.Font.SourceSansBold
        v375.MouseButton1Click:Connect(function()
          v371:Destroy()
        end
        )
        v376.MouseButton1Click:Connect(function()
          v14:Kick("Error Code:1001")
        end
        )
      end
    end
    })
    local v113=v66:MakeTab({v65.gamepass_tab,"rbxassetid://7077452289"})
    v113:AddParagraph({"Aviso",v65.gamepass_warn})
    local v114=v10.Remotes and v10.Remotes:FindFirstChild("Advertisements:Video:Request")
    if v114 then
      v113:AddButton({v65.vip_btn,function()
        v114:FireServer("VIPNameColor1")
      end
      })
      v113:AddButton({v65.mansion_btn,function()
        v114:FireServer("001_Mansion")
      end
      })
      v113:AddButton({v65.disaster_btn,function()
        v114:FireServer("Feature_DISASTER_PASS")
      end
      })
      v113:AddButton({v65.music_btn,function()
        v114:FireServer("ToolMusic")
      end
      })
      v113:AddButton({v65.house043_btn,function()
        v114:FireServer("043_House")
      end
      })
    else
      v113:AddParagraph({"Erro","Remote não encontrado"})
    end
    local v115=v66:MakeTab({v65.music_tab,"rbxassetid://7733964579"})
    local v116=""
    local v117=""
    local v118=nil
    v115:AddTextBox({["Name"]=v65.music_id_placeholder,["PlaceholderText"]="1847506405",["Callback"]=function(v233)
      v116=v233
    end
    })
    v115:AddButton({v65.music_send_btn,function()
      local v235
      local v236
      local v237
      v235=((v116~="") and v116) or "1847506405"
      v236={[1 ]="ToolMusicText",[2]=v235,[4]=true}
      v237=v10.RE and v10.RE:FindFirstChild("PlayerToolEvent")
      if v237 then
        v237:FireServer(unpack(v236))
      end
    end
    })
    v115:AddSection({"Salvar Músicas"})
    v115:AddTextBox({["Name"]=v65.music_save_name,["PlaceholderText"]="Ex: Minha Musica",["Callback"]=function(v238)
      v117=v238
    end
    })
    local function v119()
      local v239={}
      for v276,v277 in pairs(v23) do
        table.insert(v239,v276)
      end
      if (#v239==0) then
        table.insert(v239,v65.music_saved_none)
      end
      return v239
    end
    local v120
    v120=v115:AddDropdown({["Name"]=v65.music_saved_dropdown,["Description"]="Selecione uma música salva",["Options"]=v119(),["Default"]="",["Callback"]=function(v240)
      if (v240 and v23[v240]) then
        v118=v240
      else
        v118=nil
      end
    end
    })
    v115:AddButton({v65.music_save_btn,function()
      if ((v117=="") or (v116=="")) then
        return
      end
      v23[v117]=v116
      local v242=v24()
      if (not v242 and not v20) then
        pcall(function()
          v66:Dialog({["Title"]="Aviso",["Text"]="Executor sem file API. Música salva apenas na sessão atual.",["Options"]={{"OK",function()
          end
          }}})
        end
        )
      end
      pcall(function()
        v120:Set(v119())
      end
      )
    end
    })
    v115:AddButton({v65.music_delete_btn,function()
      if (v117=="") then
        return
      end
      if v23[v117] then
        v23[v117]=nil
        v24()
        pcall(function()
          v120:Set(v119())
        end
        )
      end
    end
    })
    v115:AddButton({v65.music_play_saved_btn,function()
      local v245
      local v246
      local v247
      if (not v118 or not v23[v118]) then
        return
      end
      v245=tostring(v23[v118])
      v246={[1]="ToolMusicText",[2 ]=v245,[4]=true}
      v247=v10.RE and v10.RE:FindFirstChild("PlayerToolEvent")
      if v247 then
        v247:FireServer(unpack(v246))
      end
    end
    })
    local v121=v66:MakeTab({v65.extras_tab,"rbxassetid://7733963541"})
    local v122={[v65.color_blue]=Color3.fromRGB(0,120,255),[v65.color_red]=Color3.fromRGB(255,50,50),[v65.color_black]=Color3.fromRGB(30,30,30),[v65.color_purple]=Color3.fromRGB(140,0,255)}
    v121:AddDropdown({["Name"]=v65.color_dropdown,["Options"]={v65.color_blue,v65.color_red,v65.color_black,v65.color_purple},["Default"]=v65.color_black,["Callback"]=function(v248)
      local v249=v122[v248]
      if v249 then
        pcall(function()
          v9:SetColor(v249)
        end
        )
        pcall(function()
          local v409
          v409=v66.Main and v66.Main.Parent
          if (v409 and v409:IsA("ScreenGui")) then
            for v577,v578 in ipairs(v409:GetDescendants()) do
              if (v578:IsA("Frame") or v578:IsA("TextLabel") or v578:IsA("TextButton")) then
                if (v578.Name:lower():find("back") or v578.Name:lower():find("main")) then
                  v578.BackgroundColor3=v249
                end
              end
            end
          end
        end
        )
      end
    end
    })
    v121:AddToggle({["Name"]=v65.auto_rejoin,["Default"]=false,["Callback"]=function(v250)
      v88=v250
    end
    })
    v11.PlayerRemoving:Connect(function(v251)
      if ((v251==v14) and v88) then
        v15:Teleport(game.PlaceId)
      end
    end
    )
    local v123=v66:MakeTab({v65.protection_tab,"rbxassetid://6023426923"})
    v123:AddToggle({["Name"]=v65.anti_sit,["Default"]=false,["Callback"]=function(v252)
      local v254
      v80=v252
      v254=v14.Character and v14.Character:FindFirstChildOfClass("Humanoid")
      if v252 then
        local v496
        if v254 then
          v254:SetStateEnabled(Enum.HumanoidStateType.Seated,false)
          if v254.Sit then
            v254.Sit=false
          end
        end
        if v81 then
          v81:Disconnect()
        end
        v81=v12.Heartbeat:Connect(function()
          local v599
          v599=v14.Character and v14.Character:FindFirstChildOfClass("Humanoid")
          if v599 then
            local v633
            v599:SetStateEnabled(Enum.HumanoidStateType.Seated,false)
            if v599.Sit then
              v599.Sit=false
            end
          end
        end
        )
      else
        if v81 then
          local v588
          v81:Disconnect()
          v81=nil
        end
        if v254 then
          v254:SetStateEnabled(Enum.HumanoidStateType.Seated,true)
        end
      end
    end
    })
    v123:AddToggle({["Name"]=v65.noclip,["Default"]=false,["Callback"]=function(v255)
      v82=v255
      if v255 then
        if v83 then
          v83:Disconnect()
        end
        v83=v12.Stepped:Connect(function()
          local v580
          if not v82 then
            return
          end
          v580=v14.Character
          if v580 then
            for v617,v618 in ipairs(v580:GetDescendants()) do
              if v618:IsA("BasePart") then
                v618.CanCollide=false
              end
            end
          end
        end
        )
      else
        if v83 then
          v83:Disconnect()
          v83=nil
        end
        local v499=v14.Character
        if v499 then
          for v565,v566 in ipairs(v499:GetDescendants()) do
            if v566:IsA("BasePart") then
              v566.CanCollide=true
            end
          end
        end
      end
    end
    })
    v123:AddToggle({["Name"]=v65.anti_void,["Default"]=false,["Callback"]=function(v257)
      v84=v257
      if v257 then
        workspace.FallenPartsDestroyHeight= -math.huge
        if v85 then
          v85:Disconnect()
        end
        v85=v12.Heartbeat:Connect(function()
          local v521
          local v522
          local v523
          v521=0
          v522=nil
          v523=nil
          if not v84 then
            return
          end
          v522=v14.Character
          v523=v522 and v522:FindFirstChild("HumanoidRootPart")
          if (v523 and (v523.Position.Y< -500)) then
            local v615
            v615=v522:GetAttribute("SafePos")
            if v615 then
              v523.CFrame=v615
            else
              v523.CFrame=CFrame.new(0,50,0)
            end
          end
        end
        )
        spawn(function()
          while v84 do
            local v538
            local v539
            task.wait(2)
            v538=v14.Character
            v539=v538 and v538:FindFirstChild("HumanoidRootPart")
            if (v538 and v539 and (v539.Position.Y>0)) then
              v538:SetAttribute("SafePos",v539.CFrame)
            end
          end
        end
        )
      else
        workspace.FallenPartsDestroyHeight=0
        if v85 then
          v85:Disconnect()
          v85=nil
        end
      end
    end
    })
    v123:AddToggle({["Name"]=v65.anti_fling,["Description"]="Imune a bola no personagem",["Default"]=false,["Callback"]=function(v258)
      v86=v258
      if v258 then
        if v87 then
          v87:Disconnect()
        end
        v87=v12.Heartbeat:Connect(function()
          if not v86 then
            return
          end
          local v524=v14.Character
          if not v524 then
            return
          end
          local v525=v524:FindFirstChild("HumanoidRootPart")
          if v525 then
            for v581,v582 in ipairs(v525:GetChildren()) do
              if (v582:IsA("BodyVelocity") or v582:IsA("AlignPosition") or v582:IsA("Torque")) then
                pcall(function()
                  if (v582.Velocity and (v582.Velocity.Magnitude>1000000)) then
                    v582:Destroy()
                  end
                end
                )
                if ((v582.Name=="FlingForce") or (v582.Name=="FlingPower") or (v582.Name=="KamuiBallForce")) then
                  v582:Destroy()
                end
              end
            end
          end
          for v540,v541 in ipairs(v524:GetChildren()) do
            if ((v541.Name=="SoccerBall") and v541:FindFirstChildOfClass("BodyVelocity")) then
              v541:FindFirstChildOfClass("BodyVelocity"):Destroy()
              v541.Parent=v14.Backpack
            end
          end
        end
        )
      elseif v87 then
        v87:Disconnect()
        v87=nil
      end
    end
    })
    local v124=v66:MakeTab({v65.test_tab,"rbxassetid://7733964579"})
    v124:AddParagraph({"Acesso Restrito","Digite a chave para liberar."})
    v124:AddTextBox({["Name"]=v65.key_placeholder,["PlaceholderText"]=v65.key_placeholder,["Callback"]=function(v260)
      if (v260=="kamui-x-hub-testxml") then
        v124:AddParagraph({v65.access_granted,"Acesso liberado."})
      else
        v124:AddParagraph({v65.access_denied,"Chave incorreta."})
      end
    end
    })
    v66:SelectTab(v68)
  end
  v25()
