using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace RealApp
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainWindow());
        }
    }

    public class EmbeddedHttpServer : IDisposable
    {
        private readonly HttpListener _listener;
        private readonly string _rootDir;
        private readonly int _port;
        private CancellationTokenSource _cts;
        private Task _listenTask;

        private static readonly Dictionary<string, string> MimeTypes = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { ".html", "text/html; charset=utf-8" },
            { ".htm", "text/html; charset=utf-8" },
            { ".js", "application/javascript; charset=utf-8" },
            { ".mjs", "application/javascript; charset=utf-8" },
            { ".css", "text/css; charset=utf-8" },
            { ".json", "application/json; charset=utf-8" },
            { ".svg", "image/svg+xml" },
            { ".png", "image/png" },
            { ".jpg", "image/jpeg" },
            { ".jpeg", "image/jpeg" },
            { ".ico", "image/x-icon" },
            { ".woff", "font/woff" },
            { ".woff2", "font/woff2" },
            { ".ttf", "font/ttf" },
            { ".wasm", "application/wasm" },
            { ".txt", "text/plain; charset=utf-8" }
        };

        public EmbeddedHttpServer(string rootDir, int port = 1421)
        {
            _rootDir = Path.GetFullPath(rootDir);
            _port = port;
            _listener = new HttpListener();
            _listener.Prefixes.Add($"http://localhost:{port}/");
            _listener.Prefixes.Add($"http://127.0.0.1:{port}/");
        }

        public void Start()
        {
            try
            {
                _listener.Start();
                _cts = new CancellationTokenSource();
                _listenTask = Task.Run(() => ListenLoop(_cts.Token));
            }
            catch (Exception ex)
            {
                MainWindow.LogDebug($"[EmbeddedHttpServer] Start error: {ex.Message}");
            }
        }

        private async Task ListenLoop(CancellationToken ct)
        {
            while (!ct.IsCancellationRequested && _listener.IsListening)
            {
                try
                {
                    var ctx = await _listener.GetContextAsync();
                    _ = Task.Run(() => HandleRequest(ctx));
                }
                catch (Exception)
                {
                    if (ct.IsCancellationRequested) break;
                }
            }
        }

        private void HandleRequest(HttpListenerContext ctx)
        {
            try
            {
                var req = ctx.Request;
                var res = ctx.Response;

                res.AddHeader("Access-Control-Allow-Origin", "*");
                res.AddHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
                res.AddHeader("Access-Control-Allow-Headers", "*");

                if (req.HttpMethod == "OPTIONS")
                {
                    res.StatusCode = 204;
                    res.Close();
                    return;
                }

                string urlPath = req.Url.AbsolutePath;
                if (urlPath == "/" || string.IsNullOrEmpty(urlPath))
                    urlPath = "/index.html";

                string relPath = urlPath.TrimStart('/').Replace('/', Path.DirectorySeparatorChar);
                string filePath = Path.Combine(_rootDir, relPath);

                if (!File.Exists(filePath))
                {
                    filePath = Path.Combine(_rootDir, "index.html");
                }

                if (File.Exists(filePath))
                {
                    byte[] bytes = File.ReadAllBytes(filePath);
                    string ext = Path.GetExtension(filePath);
                    if (MimeTypes.TryGetValue(ext, out string mime))
                        res.ContentType = mime;
                    else
                        res.ContentType = "application/octet-stream";

                    res.ContentLength64 = bytes.Length;
                    res.StatusCode = 200;
                    res.OutputStream.Write(bytes, 0, bytes.Length);
                }
                else
                {
                    res.StatusCode = 404;
                }
                res.Close();
            }
            catch (Exception ex)
            {
                MainWindow.LogDebug($"[EmbeddedHttpServer] Request error: {ex.Message}");
            }
        }

        public void Dispose()
        {
            _cts?.Cancel();
            try { _listener?.Stop(); } catch { }
            try { _listener?.Close(); } catch { }
        }
    }

    public class MainWindow : Form
    {
        private WebView2 _webView;
        private EmbeddedHttpServer _server;
        private bool _isFullscreen;
        private FormWindowState _previousWindowState = FormWindowState.Normal;

        [DllImport("user32.dll")]
        private static extern bool ReleaseCapture();

        [DllImport("user32.dll")]
        private static extern IntPtr SendMessage(IntPtr hWnd, int Msg, IntPtr wParam, IntPtr lParam);

        [DllImport("dwmapi.dll")]
        private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int attrValue, int attrSize);

        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(int nLeftRect, int nTopRect, int nRightRect, int nBottomRect, int nWidthEllipse, int nHeightEllipse);

        private const int WM_NCLBUTTONDOWN = 0xA1;
        private const int HTCAPTION = 0x2;

        private const int WM_NCHITTEST = 0x84;
        private const int HTCLIENT = 1;
        private const int HTLEFT = 10;
        private const int HTRIGHT = 11;
        private const int HTTOP = 12;
        private const int HTTOPLEFT = 13;
        private const int HTTOPRIGHT = 14;
        private const int HTBOTTOM = 15;
        private const int HTBOTTOMLEFT = 16;
        private const int HTBOTTOMRIGHT = 17;

        private const int RESIZE_HANDLE_SIZE = 8;

        public MainWindow()
        {
            Text = "constraintt.ez";
            Width = 1150;
            Height = 750;
            MinimumSize = new Size(800, 500);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(13, 13, 13);
            ForeColor = Color.White;
            FormBorderStyle = FormBorderStyle.None;
            DoubleBuffered = true;
            SetStyle(ControlStyles.ResizeRedraw, true);

            LoadAppIcon();
            ApplyDwmAttributes();
            InitUI();
        }

        private void LoadAppIcon()
        {
            try
            {
                string icoPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "app.ico");
                if (File.Exists(icoPath))
                {
                    Icon = new Icon(icoPath);
                }
                else
                {
                    Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
                }
            }
            catch { }
        }

        private void ApplyDwmAttributes()
        {
            try
            {
                int darkMode = 1;
                DwmSetWindowAttribute(Handle, 20, ref darkMode, sizeof(int));

                int cornerPreference = 2; // DWMWCP_ROUND
                DwmSetWindowAttribute(Handle, 33, ref cornerPreference, sizeof(int));
            }
            catch { }
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            if (WindowState == FormWindowState.Normal)
            {
                try
                {
                    Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 16, 16));
                }
                catch { }
            }
            else
            {
                Region = null;
            }
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_NCHITTEST && WindowState == FormWindowState.Normal)
            {
                base.WndProc(ref m);
                if ((int)m.Result == HTCLIENT)
                {
                    Point cursor = PointToClient(Cursor.Position);

                    bool left = cursor.X <= RESIZE_HANDLE_SIZE;
                    bool right = cursor.X >= ClientSize.Width - RESIZE_HANDLE_SIZE;
                    bool top = cursor.Y <= RESIZE_HANDLE_SIZE;
                    bool bottom = cursor.Y >= ClientSize.Height - RESIZE_HANDLE_SIZE;

                    if (top && left) m.Result = (IntPtr)HTTOPLEFT;
                    else if (top && right) m.Result = (IntPtr)HTTOPRIGHT;
                    else if (bottom && left) m.Result = (IntPtr)HTBOTTOMLEFT;
                    else if (bottom && right) m.Result = (IntPtr)HTBOTTOMRIGHT;
                    else if (left) m.Result = (IntPtr)HTLEFT;
                    else if (right) m.Result = (IntPtr)HTRIGHT;
                    else if (top) m.Result = (IntPtr)HTTOP;
                    else if (bottom) m.Result = (IntPtr)HTBOTTOM;
                }
                return;
            }
            base.WndProc(ref m);
        }

        public static void LogDebug(string msg)
        {
            try
            {
                string logPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "real_debug.log");
                File.AppendAllText(logPath, $"[{DateTime.Now:HH:mm:ss.fff}] {msg}\n");
            }
            catch { }
        }

        private async void InitUI()
        {
            try
            {
                string uiPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ui");
                if (!Directory.Exists(uiPath))
                {
                    string altUi = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\..\ui"));
                    if (Directory.Exists(altUi)) uiPath = altUi;
                }

                _server = new EmbeddedHttpServer(uiPath, 1421);
                _server.Start();

                _webView = new WebView2
                {
                    Dock = DockStyle.Fill,
                    BackColor = Color.FromArgb(13, 13, 13),
                    DefaultBackgroundColor = Color.FromArgb(13, 13, 13)
                };
                Controls.Add(_webView);

                string userData = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "RealWebView2");
                var env = await CoreWebView2Environment.CreateAsync(null, userData);
                await _webView.EnsureCoreWebView2Async(env);

                _webView.DefaultBackgroundColor = Color.FromArgb(13, 13, 13);

                _webView.CoreWebView2.Settings.IsWebMessageEnabled = true;
                _webView.CoreWebView2.Settings.AreDevToolsEnabled = true;
                _webView.CoreWebView2.Settings.IsScriptEnabled = true;
                _webView.CoreWebView2.Settings.IsStatusBarEnabled = false;

                _webView.CoreWebView2.WebMessageReceived += OnWebMessageReceived;
                _webView.CoreWebView2.NavigationCompleted += (s, e) =>
                {
                    LogDebug($"NavigationCompleted: Success={e.IsSuccess}, ErrorStatus={e.WebErrorStatus}");
                    DumpRenderedDom();
                };

                _webView.CoreWebView2.Navigate("http://localhost:1421/");
            }
            catch (Exception ex)
            {
                LogDebug("InitUI Error: " + ex.Message);
                MessageBox.Show("WebView2 Init Error: " + ex.Message, "constraintt.ez", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void DumpRenderedDom()
        {
            try
            {
                await Task.Delay(2500);
                string probeScript = @"(function() {
                    return JSON.stringify({
                        elementsCount: document.querySelectorAll('*').length,
                        appShellFound: !!document.querySelector('.app-shell, .settings-root, .welcome-root'),
                        splashFound: !!document.querySelector('.splash')
                    });
                })()";
                string probeRes = await _webView.CoreWebView2.ExecuteScriptAsync(probeScript);
                LogDebug("REAL_DOM_PROBE: " + probeRes);

                string dom = await _webView.CoreWebView2.ExecuteScriptAsync("document.documentElement.outerHTML");
                string unescaped = RegexUnescape(dom);
                string domPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "real_rendered_dom.html");
                File.WriteAllText(domPath, unescaped);
                LogDebug($"Dumped Real rendered DOM ({unescaped.Length} chars) to real_rendered_dom.html");
            }
            catch (Exception ex)
            {
                LogDebug("DumpRenderedDom Error: " + ex.Message);
            }
        }

        private static string RegexUnescape(string str)
        {
            if (string.IsNullOrEmpty(str)) return "";
            if (str.StartsWith("\"") && str.EndsWith("\""))
                str = str.Substring(1, str.Length - 2);
            return System.Text.RegularExpressions.Regex.Unescape(str);
        }

        private void OnWebMessageReceived(object sender, CoreWebView2WebMessageReceivedEventArgs e)
        {
            try
            {
                string raw = null;
                try { raw = e.TryGetWebMessageAsString(); } catch { }
                if (string.IsNullOrEmpty(raw))
                {
                    try { raw = e.WebMessageAsJson; } catch { }
                }
                if (string.IsNullOrEmpty(raw)) return;

                var obj = JObject.Parse(raw);
                string msgType = obj["type"]?.ToString();

                if (msgType == "tauri_invoke")
                {
                    string cmd = obj["cmd"]?.ToString();
                    var args = obj["args"] as JObject ?? new JObject();
                    string callbackId = obj["callbackId"]?.ToString();

                    object result = HandleTauriCommand(cmd, args);
                    ResolveCallback(callbackId, result);
                }
            }
            catch (Exception ex)
            {
                LogDebug($"WebMessage Error: {ex.Message}");
            }
        }

        private object HandleTauriCommand(string cmd, JObject args)
        {
            switch (cmd)
            {
                case "plugin:window|start_dragging":
                case "start_dragging":
                    BeginDrag();
                    return true;

                case "plugin:window|minimize":
                case "minimize":
                    Invoke((Action)(() => WindowState = FormWindowState.Minimized));
                    return true;

                case "plugin:window|maximize":
                case "maximize":
                case "plugin:window|toggle_maximize":
                case "toggle_maximize":
                    Invoke((Action)(() =>
                    {
                        WindowState = (WindowState == FormWindowState.Maximized) ? FormWindowState.Normal : FormWindowState.Maximized;
                    }));
                    return true;

                case "plugin:window|close":
                case "close":
                case "close_app":
                case "exit_app":
                    Invoke((Action)(() => Close()));
                    return true;

                case "plugin:window|is_maximized":
                    return WindowState == FormWindowState.Maximized;

                case "plugin:window|is_fullscreen":
                    return _isFullscreen;

                case "plugin:window|set_fullscreen":
                    bool fs = args["value"]?.Value<bool>() ?? false;
                    Invoke((Action)(() => SetFullscreen(fs)));
                    return true;

                case "plugin:window|inner_size":
                case "plugin:window|outer_size":
                    return new { width = ClientSize.Width, height = ClientSize.Height };

                case "plugin:window|scale_factor":
                    return CreateGraphics().DpiX / 96.0f;

                case "get_roblox_version":
                case "get_latest_roblox_version":
                case "get_previous_roblox_version":
                    return "version-4a5e1e0b0e5b4c9e";

                case "get_real_version":
                    return "2.1.2";

                case "check_license":
                case "redeem_key":
                case "get_me":
                    return new { account_id = "1", username = "constraintt.ez", plan = "pro", plan_tier = "pro", effective_tier = "pro", plan_active = true, balance_active = true, expires_at = (string)null };

                case "get_accounts":
                case "get_roblox_clients":
                case "get_installed_launchers":
                case "list_installed_versions":
                case "get_installed_versions":
                case "get_roblox_instances":
                case "cloud_scripts_list":
                case "get_folder_tree":
                case "get_folder_scripts":
                case "list_explorer_custom_roots":
                case "get_autoexec_game_bindings":
                case "get_saved_servers":
                case "get_recent_games":
                case "get_favorite_games":
                case "get_continue_games":
                case "get_home_sorts":
                case "get_charts":
                case "openf":
                    return new JArray();

                case "get_encryption_status":
                    return new { enabled = false, locked = false };

                case "load_settings":
                    return "{}";

                case "save_settings":
                case "save_editor_session_files":
                case "save_editor_session_index":
                case "delete_editor_session_files":
                case "clear_editor_session_files":
                case "clear_editor_session_index":
                case "real_is_foreground":
                case "send_os_notification":
                case "validate_roblox_version":
                    return true;

                case "read_editor_session_index":
                case "read_editor_session_file":
                case "read_vscode_from_sync":
                    return "";

                case "check_vscode_extension":
                case "streamer_capture_running":
                case "streamer_software_changed":
                    return false;

                case "detect_roblox_install":
                    return new { installed = true, path = "" };

                default:
                    return true;
            }
        }

        private void SetFullscreen(bool fs)
        {
            _isFullscreen = fs;
            if (fs)
            {
                _previousWindowState = WindowState;
                WindowState = FormWindowState.Maximized;
            }
            else
            {
                WindowState = _previousWindowState;
            }
        }

        private void BeginDrag()
        {
            Invoke((Action)(() =>
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, (IntPtr)HTCAPTION, IntPtr.Zero);
            }));
        }

        private void ResolveCallback(string callbackId, object result)
        {
            if (string.IsNullOrEmpty(callbackId)) return;
            string jsonResult = JsonConvert.SerializeObject(result);
            string script = $"if (window.__TAURI_INTERNALS__ && window.__TAURI_INTERNALS__.callbacks && window.__TAURI_INTERNALS__.callbacks['{callbackId}']) {{ window.__TAURI_INTERNALS__.callbacks['{callbackId}'].resolve({jsonResult}); delete window.__TAURI_INTERNALS__.callbacks['{callbackId}']; }}";
            _webView.CoreWebView2.ExecuteScriptAsync(script);
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            _server?.Dispose();
            base.OnFormClosing(e);
        }
    }
}
